import axios from 'axios';

export const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3000';

// Backend memakai session cookie (express-session + passport).
// Di React Native, cookie disimpan & dikirim otomatis oleh jaringan native,
// jadi cukup withCredentials: true seperti di web.
export const api = axios.create({
    baseURL: API_URL,
    withCredentials: true,
    timeout: 20000
});

// ==== Auth ====
export const registerUser = (data) => api.post('/auth/register', data);
export const loginUser = (data) => api.post('/auth/login', data);
export const logoutUser = () => api.post('/auth/logout');
export const sendOtp = (email) => api.post('/auth/send-otp', { email });
export const verifyOtp = (data) => api.post('/auth/verify-otp', data);
export const getMe = () => api.get('/auth/me');

// ==== Events ====
export const getEvents = () => api.get('/api/events');
export const getEventById = (id) => api.get(`/api/events/${id}`);

// ==== Orders ====
export const createOrder = (data) => api.post('/api/orders', data);
export const getMyOrders = () => api.get('/api/orders/my-orders');
export const syncOrder = (orderId) => api.post(`/api/orders/${orderId}/sync`);

// ==== Vouchers ====
export const validateVoucher = (data) => api.post('/api/vouchers/validate', data);

// ==== Organizer / admin ====
export const getManagedEvents = () => api.get('/api/events/my-events/list');
export const updateEvent = (id, data) => api.put(`/api/events/${id}`, data);
export const getDashboardSummary = () => api.get('/api/dashboard/summary');

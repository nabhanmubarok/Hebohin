// Warna disamakan dengan tailwind.config.js di web HebohIn
export const colors = {
    ink: '#0A0A12',
    panel: '#12121F',
    panel2: '#181828',
    line: 'rgba(255,255,255,0.08)',
    flare: '#FF3D7A',
    flare2: '#FF6FA0',
    pulse: '#2FE6D0',
    muted: '#9C9CB8',
    white: '#FFFFFF',
    danger: '#F87171',
    warn: '#FACC15'
};

export const radius = { sm: 10, md: 16, lg: 24, pill: 999 };

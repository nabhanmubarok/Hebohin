import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { getMe, loginUser, logoutUser } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    const refreshUser = useCallback(async () => {
        try {
            const res = await getMe();
            setUser(res.data);
            return res.data;
        } catch {
            setUser(null);
            return null;
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { refreshUser(); }, [refreshUser]);

    async function login(form) {
        await loginUser(form);
        return refreshUser();
    }

    async function logout() {
        try { await logoutUser(); } catch { /* sesi sudah habis, abaikan */ }
        setUser(null);
    }

    return (
        <AuthContext.Provider value={{ user, loading, login, logout, refreshUser }}>
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => useContext(AuthContext);

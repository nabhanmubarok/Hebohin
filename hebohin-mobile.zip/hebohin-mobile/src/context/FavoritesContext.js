import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from './AuthContext';

const FavoritesContext = createContext(null);

// Sama seperti web: favorit disimpan lokal di perangkat, per user.
export function FavoritesProvider({ children }) {
    const { user } = useAuth();
    const storageKey = user?.id ? `hebohin_favorites_${user.id}` : null;
    const [favoriteIds, setFavoriteIds] = useState([]);

    useEffect(() => {
        let cancelled = false;
        if (!storageKey) { setFavoriteIds([]); return; }
        AsyncStorage.getItem(storageKey)
            .then(raw => { if (!cancelled) setFavoriteIds(raw ? JSON.parse(raw) : []); })
            .catch(() => { if (!cancelled) setFavoriteIds([]); });
        return () => { cancelled = true; };
    }, [storageKey]);

    const toggleFavorite = useCallback((eventId) => {
        if (!storageKey) return false; // belum login
        setFavoriteIds(prev => {
            const next = prev.includes(eventId) ? prev.filter(id => id !== eventId) : [...prev, eventId];
            AsyncStorage.setItem(storageKey, JSON.stringify(next)).catch(() => {});
            return next;
        });
        return true;
    }, [storageKey]);

    return (
        <FavoritesContext.Provider value={{ favoriteIds, toggleFavorite }}>
            {children}
        </FavoritesContext.Provider>
    );
}

export const useFavorites = () => useContext(FavoritesContext);

// Format manual (tanpa Intl) supaya hasilnya konsisten di semua HP Android/iOS.
const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const BULAN_PANJANG = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const HARI = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

export function formatRupiah(n) {
    const num = Math.round(Number(n) || 0);
    const sign = num < 0 ? '-' : '';
    return `${sign}Rp${String(Math.abs(num)).replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
}

export function formatDate(value) {
    if (!value) return '';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return '';
    return `${d.getDate()} ${BULAN[d.getMonth()]} ${d.getFullYear()}`;
}

export function formatDateLong(value) {
    if (!value) return '-';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return '-';
    const jam = String(d.getHours()).padStart(2, '0');
    const menit = String(d.getMinutes()).padStart(2, '0');
    return `${HARI[d.getDay()]}, ${d.getDate()} ${BULAN_PANJANG[d.getMonth()]} ${d.getFullYear()} · ${jam}.${menit}`;
}

export function lowestPrice(ticketTypes) {
    if (!ticketTypes || ticketTypes.length === 0) return null;
    return Math.min(...ticketTypes.map(t => t.price));
}

export function errorMessage(err, fallback) {
    if (err?.response?.data?.message) return err.response.data.message;
    if (err?.message === 'Network Error') return 'Tidak bisa terhubung ke server. Cek koneksi dan alamat API.';
    return fallback;
}

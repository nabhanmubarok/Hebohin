import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius } from '../theme';

export function Button({ title, onPress, loading, disabled, variant = 'primary', style }) {
    const isPrimary = variant === 'primary';
    return (
        <Pressable
            onPress={onPress}
            disabled={disabled || loading}
            style={({ pressed }) => [
                s.btn,
                isPrimary ? s.btnPrimary : s.btnGhost,
                (disabled || loading) && { opacity: 0.5 },
                pressed && { opacity: 0.8 },
                style
            ]}
        >
            {loading ? <ActivityIndicator color={colors.white} /> : (
                <Text style={s.btnText}>{title}</Text>
            )}
        </Pressable>
    );
}

export function Input({ label, error, style, ...props }) {
    return (
        <View style={{ marginBottom: 14 }}>
            {label ? <Text style={s.label}>{label}</Text> : null}
            <TextInput
                placeholderTextColor={colors.muted}
                autoCapitalize="none"
                {...props}
                style={[s.input, error && { borderColor: colors.danger }, style]}
            />
            {error ? <Text style={s.error}>{error}</Text> : null}
        </View>
    );
}

export function Loading({ text = 'Memuat...' }) {
    return (
        <View style={s.center}>
            <ActivityIndicator color={colors.flare} />
            <Text style={[s.muted, { marginTop: 10 }]}>{text}</Text>
        </View>
    );
}

export function Empty({ text, children }) {
    return (
        <View style={s.empty}>
            <Text style={[s.muted, { textAlign: 'center' }]}>{text}</Text>
            {children}
        </View>
    );
}

export function Chip({ label, active, onPress }) {
    return (
        <Pressable onPress={onPress} style={[s.chip, active && s.chipActive]}>
            <Text style={[s.chipText, active && { color: colors.white }]}>{label}</Text>
        </Pressable>
    );
}

export const s = StyleSheet.create({
    btn: { borderRadius: radius.pill, paddingVertical: 14, paddingHorizontal: 20, alignItems: 'center', justifyContent: 'center' },
    btnPrimary: { backgroundColor: colors.flare },
    btnGhost: { borderWidth: 1, borderColor: colors.line },
    btnText: { color: colors.white, fontWeight: '700', fontSize: 15 },
    label: { color: colors.muted, fontSize: 12, marginBottom: 6 },
    input: {
        backgroundColor: colors.panel2, borderWidth: 1, borderColor: colors.line,
        borderRadius: radius.md, paddingHorizontal: 14, paddingVertical: 12,
        color: colors.white, fontSize: 15
    },
    error: { color: colors.flare2, fontSize: 12, marginTop: 4 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
    muted: { color: colors.muted, fontSize: 13 },
    empty: {
        borderWidth: 1, borderStyle: 'dashed', borderColor: colors.line,
        borderRadius: radius.lg, padding: 32, alignItems: 'center', gap: 14
    },
    chip: {
        paddingHorizontal: 16, paddingVertical: 8, borderRadius: radius.pill,
        borderWidth: 1, borderColor: colors.line, marginRight: 8
    },
    chipActive: { backgroundColor: colors.flare, borderColor: colors.flare },
    chipText: { color: colors.muted, fontSize: 12, fontWeight: '700' }
});

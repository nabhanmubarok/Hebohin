import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { colors, radius } from '../theme';
import { formatDate, formatRupiah, lowestPrice } from '../utils/format';
import { useAuth } from '../context/AuthContext';
import { useFavorites } from '../context/FavoritesContext';

export function Poster({ event, height, style }) {
    return (
        <View style={[{ height, backgroundColor: colors.panel2, overflow: 'hidden' }, style]}>
            {event.poster_url ? (
                <Image source={{ uri: event.poster_url }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
            ) : (
                <View style={s.posterFallback}>
                    <Text style={s.posterLetter}>{event.name?.[0] ?? '?'}</Text>
                </View>
            )}
        </View>
    );
}

export function FavoriteButton({ eventId, style }) {
    const router = useRouter();
    const { user } = useAuth();
    const { favoriteIds, toggleFavorite } = useFavorites();
    const isFav = favoriteIds.includes(eventId);

    return (
        <Pressable
            hitSlop={8}
            onPress={() => { if (!user) router.push('/login'); else toggleFavorite(eventId); }}
            style={[s.fav, isFav && { backgroundColor: colors.flare }, style]}
        >
            <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={18} color={colors.white} />
        </Pressable>
    );
}

// variant "wide" = kartu besar untuk carousel unggulan, default = kartu daftar
export default function EventCard({ event, variant = 'list', width }) {
    const router = useRouter();
    const price = lowestPrice(event.ticket_types);
    const open = () => router.push(`/event/${event.id}`);

    if (variant === 'wide') {
        return (
            <Pressable onPress={open} style={[s.wide, { width }]}>
                <Poster event={event} height={190} />
                <View style={{ padding: 14 }}>
                    <Text style={s.genre}>{event.genre || 'Konser'}</Text>
                    <Text style={s.wideTitle} numberOfLines={2}>{event.name}</Text>
                    <Text style={s.meta} numberOfLines={1}>{event.venue} · {formatDate(event.event_date)}</Text>
                </View>
                <FavoriteButton eventId={event.id} style={{ position: 'absolute', top: 12, right: 12 }} />
            </Pressable>
        );
    }

    return (
        <Pressable onPress={open} style={s.card}>
            <View>
                <Poster event={event} height={150} />
                <View style={s.genrePill}><Text style={s.genre}>{event.genre || 'Konser'}</Text></View>
                <FavoriteButton eventId={event.id} style={{ position: 'absolute', top: 12, right: 12 }} />
            </View>
            <View style={{ padding: 14 }}>
                <Text style={s.title} numberOfLines={2}>{event.name}</Text>
                <Text style={s.meta} numberOfLines={1}>{event.venue} · {event.city}</Text>
                <View style={s.row}>
                    <Text style={s.meta}>{formatDate(event.event_date)}</Text>
                    {price !== null && <Text style={s.price}>mulai {formatRupiah(price)}</Text>}
                </View>
            </View>
        </Pressable>
    );
}

const s = StyleSheet.create({
    card: { backgroundColor: colors.panel, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, overflow: 'hidden', marginBottom: 16 },
    wide: { backgroundColor: colors.panel, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.line, overflow: 'hidden', marginRight: 14 },
    posterFallback: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,61,122,0.12)' },
    posterLetter: { fontSize: 56, fontWeight: '800', color: 'rgba(255,255,255,0.12)' },
    genrePill: { position: 'absolute', top: 12, left: 12, backgroundColor: 'rgba(10,10,18,0.75)', borderRadius: radius.pill, paddingHorizontal: 12, paddingVertical: 5 },
    genre: { color: colors.pulse, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
    title: { color: colors.white, fontSize: 16, fontWeight: '700', marginBottom: 4 },
    wideTitle: { color: colors.white, fontSize: 18, fontWeight: '800', marginTop: 6, marginBottom: 4 },
    meta: { color: colors.muted, fontSize: 12 },
    row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 },
    price: { color: colors.pulse, fontSize: 14, fontWeight: '700' },
    fav: { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(10,10,18,0.65)', alignItems: 'center', justifyContent: 'center' }
});

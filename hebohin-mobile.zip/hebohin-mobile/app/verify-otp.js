import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { sendOtp, verifyOtp } from '../src/api/client';
import { Button, Input } from '../src/components/ui';
import { colors } from '../src/theme';
import { errorMessage } from '../src/utils/format';

export default function VerifyOtp() {
    const params = useLocalSearchParams();
    const router = useRouter();
    const [email, setEmail] = useState(params.email ? String(params.email) : '');
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');
    const [info, setInfo] = useState('');
    const [loading, setLoading] = useState(false);

    async function submit() {
        if (!email.trim() || otp.length < 6) { setError('Isi email dan 6 digit kode OTP'); return; }
        setLoading(true);
        setError('');
        setInfo('');
        try {
            await verifyOtp({ email: email.trim(), otp });
            router.replace('/login');
        } catch (err) {
            setError(errorMessage(err, 'Verifikasi gagal'));
        } finally {
            setLoading(false);
        }
    }

    async function resend() {
        setError('');
        setInfo('');
        if (!email.trim()) { setError('Isi email dulu'); return; }
        try {
            await sendOtp(email.trim());
            setInfo('Kode OTP baru sudah dikirim ke emailmu.');
        } catch (err) {
            setError(errorMessage(err, 'Gagal kirim ulang OTP'));
        }
    }

    return (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <ScrollView contentContainerStyle={s.wrap} keyboardShouldPersistTaps="handled">
                <Text style={s.title}>Masukkan kode OTP</Text>
                <Text style={s.sub}>Kode 6 digit dikirim ke emailmu dan berlaku 5 menit.</Text>

                <Input label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" style={{ marginTop: 24 }} />
                <Input label="Kode OTP" value={otp} onChangeText={(v) => setOtp(v.replace(/\D/g, '').slice(0, 6))}
                    keyboardType="number-pad" maxLength={6} placeholder="123456"
                    style={{ fontSize: 24, letterSpacing: 8, textAlign: 'center' }} />

                {error ? <Text style={s.error}>{error}</Text> : null}
                {info ? <Text style={s.info}>{info}</Text> : null}

                <Button title="Verifikasi" onPress={submit} loading={loading} style={{ marginTop: 6 }} />
                <Pressable onPress={resend} style={{ marginTop: 22, alignSelf: 'center' }}>
                    <Text style={s.link}>Kirim ulang kode</Text>
                </Pressable>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const s = StyleSheet.create({
    wrap: { padding: 24, paddingTop: 28 },
    title: { color: colors.white, fontSize: 24, fontWeight: '800' },
    sub: { color: colors.muted, fontSize: 14, marginTop: 6 },
    error: { color: colors.flare2, fontSize: 13, marginBottom: 8 },
    info: { color: colors.pulse, fontSize: 13, marginBottom: 8 },
    link: { color: colors.pulse, fontWeight: '700', fontSize: 14 }
});

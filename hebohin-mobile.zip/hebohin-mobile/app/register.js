import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { registerUser } from '../src/api/client';
import { Button, Input } from '../src/components/ui';
import { colors } from '../src/theme';
import { errorMessage } from '../src/utils/format';

export default function Register() {
    const router = useRouter();
    const [form, setForm] = useState({ name: '', email: '', password: '' });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const set = (k) => (v) => setForm(f => ({ ...f, [k]: v }));

    async function submit() {
        if (!form.name.trim() || !form.email.trim() || !form.password) { setError('Nama, email, dan password wajib diisi'); return; }
        if (form.password.length < 6) { setError('Password minimal 6 karakter'); return; }
        setLoading(true);
        setError('');
        try {
            await registerUser({ name: form.name.trim(), email: form.email.trim(), password: form.password });
            router.replace({ pathname: '/verify-otp', params: { email: form.email.trim() } });
        } catch (err) {
            setError(errorMessage(err, 'Gagal registrasi'));
        } finally {
            setLoading(false);
        }
    }

    return (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <ScrollView contentContainerStyle={s.wrap} keyboardShouldPersistTaps="handled">
                <Text style={s.title}>Buat akun HebohIn</Text>
                <Text style={s.sub}>Kami kirim kode OTP ke emailmu untuk verifikasi.</Text>

                <View style={{ marginTop: 24 }}>
                    <Input label="Nama lengkap" value={form.name} onChangeText={set('name')} autoCapitalize="words" placeholder="Nama kamu" />
                    <Input label="Email" value={form.email} onChangeText={set('email')} keyboardType="email-address" placeholder="kamu@email.com" />
                    <Input label="Password" value={form.password} onChangeText={set('password')} secureTextEntry placeholder="Minimal 6 karakter" />
                </View>

                {error ? <Text style={s.error}>{error}</Text> : null}
                <Button title="Daftar" onPress={submit} loading={loading} style={{ marginTop: 10 }} />

                <View style={s.foot}>
                    <Text style={{ color: colors.muted }}>Sudah punya akun? </Text>
                    <Pressable onPress={() => router.replace('/login')}><Text style={s.link}>Masuk</Text></Pressable>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const s = StyleSheet.create({
    wrap: { padding: 24, paddingTop: 28 },
    title: { color: colors.white, fontSize: 24, fontWeight: '800' },
    sub: { color: colors.muted, fontSize: 14, marginTop: 6 },
    error: { color: colors.flare2, fontSize: 13, marginBottom: 8 },
    link: { color: colors.pulse, fontWeight: '700', fontSize: 14 },
    foot: { flexDirection: 'row', justifyContent: 'center', marginTop: 26 }
});

import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../src/context/AuthContext';
import { Button, Input } from '../src/components/ui';
import { colors } from '../src/theme';
import { errorMessage } from '../src/utils/format';

export default function Login() {
    const router = useRouter();
    const { login } = useAuth();
    const [form, setForm] = useState({ email: '', password: '' });
    const [error, setError] = useState('');
    const [needsVerify, setNeedsVerify] = useState(false);
    const [loading, setLoading] = useState(false);

    async function submit() {
        if (!form.email.trim() || !form.password) { setError('Email dan password wajib diisi'); return; }
        setLoading(true);
        setError('');
        setNeedsVerify(false);
        try {
            await login({ email: form.email.trim(), password: form.password });
            // Balik ke halaman sebelumnya kalau ada (mis. detail event), kalau tidak ke beranda
            if (router.canGoBack()) router.back(); else router.replace('/');
        } catch (err) {
            if (err?.response?.status === 403) setNeedsVerify(true);
            setError(errorMessage(err, 'Gagal login'));
        } finally {
            setLoading(false);
        }
    }

    return (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <ScrollView contentContainerStyle={s.wrap} keyboardShouldPersistTaps="handled">
                <Text style={s.brand}>Heboh<Text style={{ color: colors.flare }}>In</Text></Text>
                <Text style={s.title}>Selamat datang kembali</Text>
                <Text style={s.sub}>Masuk untuk beli tiket dan lihat e-tiketmu.</Text>

                <View style={{ marginTop: 28 }}>
                    <Input label="Email" value={form.email} onChangeText={(v) => setForm(f => ({ ...f, email: v }))}
                        keyboardType="email-address" autoComplete="email" placeholder="kamu@email.com" />
                    <Input label="Password" value={form.password} onChangeText={(v) => setForm(f => ({ ...f, password: v }))}
                        secureTextEntry autoComplete="password" placeholder="••••••••" />
                </View>

                {error ? <Text style={s.error}>{error}</Text> : null}
                {needsVerify && (
                    <Pressable onPress={() => router.push({ pathname: '/verify-otp', params: { email: form.email.trim() } })}>
                        <Text style={s.link}>Verifikasi email sekarang →</Text>
                    </Pressable>
                )}

                <Button title="Masuk" onPress={submit} loading={loading} style={{ marginTop: 18 }} />

                <View style={s.foot}>
                    <Text style={{ color: colors.muted }}>Belum punya akun? </Text>
                    <Pressable onPress={() => router.replace('/register')}><Text style={s.link}>Daftar</Text></Pressable>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const s = StyleSheet.create({
    wrap: { padding: 24, paddingTop: 36 },
    brand: { color: colors.white, fontSize: 30, fontWeight: '800' },
    title: { color: colors.white, fontSize: 22, fontWeight: '800', marginTop: 24 },
    sub: { color: colors.muted, fontSize: 14, marginTop: 6 },
    error: { color: colors.flare2, fontSize: 13, marginBottom: 8 },
    link: { color: colors.pulse, fontWeight: '700', fontSize: 14 },
    foot: { flexDirection: 'row', justifyContent: 'center', marginTop: 26 }
});

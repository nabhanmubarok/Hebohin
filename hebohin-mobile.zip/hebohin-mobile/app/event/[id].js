import { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { createOrder, getEventById, validateVoucher } from '../../src/api/client';
import { useAuth } from '../../src/context/AuthContext';
import { FavoriteButton, Poster } from '../../src/components/EventCard';
import { Button, Input, Loading } from '../../src/components/ui';
import { colors, radius } from '../../src/theme';
import { errorMessage, formatDateLong, formatRupiah } from '../../src/utils/format';

export default function EventDetail() {
    const { id } = useLocalSearchParams();
    const router = useRouter();
    const insets = useSafeAreaInsets();
    const { user } = useAuth();

    const [event, setEvent] = useState(null);
    const [notFound, setNotFound] = useState(false);
    const [selected, setSelected] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const [voucherCode, setVoucherCode] = useState('');
    const [voucherInfo, setVoucherInfo] = useState(null);
    const [voucherError, setVoucherError] = useState('');
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        getEventById(id)
            .then(res => {
                setEvent(res.data);
                const types = res.data.ticket_types || [];
                setSelected(types.find(t => t.stock - (t.sold || 0) > 0) || types[0] || null);
            })
            .catch(() => setNotFound(true));
    }, [id]);

    if (notFound) return <Loading text="Event tidak ditemukan." />;
    if (!event) return <Loading text="Memuat detail event..." />;

    const remaining = (t) => (t ? t.stock - (t.sold || 0) : 0);
    const subtotal = selected ? selected.price * quantity : 0;
    const discount = voucherInfo?.valid ? voucherInfo.discountAmount : 0;
    const total = Math.max(0, subtotal - discount);

    function selectType(t) {
        setSelected(t);
        setQuantity(1);
        setVoucherInfo(null); // total berubah, voucher perlu dicek ulang
    }

    function changeQty(delta) {
        const max = Math.max(1, remaining(selected));
        setQuantity(q => Math.min(max, Math.max(1, q + delta)));
        setVoucherInfo(null);
    }

    async function applyVoucher() {
        setVoucherError('');
        setVoucherInfo(null);
        if (!voucherCode.trim()) return;
        if (!user) { router.push('/login'); return; }
        try {
            const res = await validateVoucher({ code: voucherCode.trim(), totalAmount: subtotal });
            setVoucherInfo(res.data);
        } catch (err) {
            setVoucherError(errorMessage(err, 'Voucher tidak valid'));
        }
    }

    async function checkout() {
        if (!user) { router.push('/login'); return; }
        setSubmitting(true);
        setError('');
        try {
            const res = await createOrder({
                eventId: event.id,
                items: [{
                    ticketTypeId: selected.id,
                    category: selected.category,
                    quantity,
                    pricePerItem: selected.price
                }],
                voucherCode: voucherInfo?.valid ? voucherCode.trim() : undefined
            });
            router.push({ pathname: '/checkout', params: { url: res.data.redirectUrl, orderId: res.data.orderId } });
        } catch (err) {
            setError(errorMessage(err, 'Gagal membuat order'));
        } finally {
            setSubmitting(false);
        }
    }

    function openMaps() {
        const hasCoords = Number.isFinite(Number(event.latitude)) && Number.isFinite(Number(event.longitude))
            && event.latitude !== null && event.longitude !== null && event.latitude !== '';
        const raw = event.address || '';
        const query = hasCoords
            ? `${event.latitude},${event.longitude}`
            : [/^https?:\/\//i.test(raw) ? '' : raw, event.venue, event.city].filter(Boolean).join(', ');
        const url = /^https?:\/\//i.test(raw) && !hasCoords
            ? raw
            : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
        Linking.openURL(url).catch(() => {});
    }

    const soldOut = !selected || remaining(selected) <= 0;

    return (
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
            <ScrollView contentContainerStyle={{ paddingBottom: 130 }} keyboardShouldPersistTaps="handled">
                <View>
                    <Poster event={event} height={230} />
                    <FavoriteButton eventId={event.id} style={{ position: 'absolute', top: 14, right: 14 }} />
                </View>

                <View style={{ padding: 20 }}>
                    <View style={s.genre}><Text style={s.genreText}>{event.genre || 'Konser'}</Text></View>
                    <Text style={s.title}>{event.name}</Text>
                    {event.artist ? <Text style={s.artist}>{event.artist}</Text> : null}

                    <View style={s.infoBox}>
                        <View style={s.infoRow}>
                            <Ionicons name="calendar-outline" size={18} color={colors.pulse} />
                            <Text style={s.infoText}>{formatDateLong(event.event_date)}</Text>
                        </View>
                        <View style={s.infoRow}>
                            <Ionicons name="location-outline" size={18} color={colors.pulse} />
                            <Text style={s.infoText}>{event.venue}, {event.city}</Text>
                        </View>
                        <Pressable onPress={openMaps} style={s.mapBtn}>
                            <Ionicons name="map-outline" size={16} color={colors.white} />
                            <Text style={s.mapBtnText}>Buka di Google Maps</Text>
                        </Pressable>
                    </View>

                    {event.description ? <Text style={s.desc}>{event.description}</Text> : null}

                    <Text style={s.section}>Pilih Tiket</Text>
                    {(event.ticket_types || []).map(tt => {
                        const left = remaining(tt);
                        const active = selected?.id === tt.id;
                        return (
                            <Pressable
                                key={tt.id}
                                onPress={() => left > 0 && selectType(tt)}
                                style={[s.type, active && s.typeActive, left <= 0 && { opacity: 0.45 }]}
                            >
                                <View style={{ flex: 1 }}>
                                    <Text style={s.typeName}>{tt.category}</Text>
                                    <Text style={s.typeLeft}>{left > 0 ? `Sisa ${left} tiket` : 'Habis'}</Text>
                                </View>
                                <Text style={s.typePrice}>{formatRupiah(tt.price)}</Text>
                            </Pressable>
                        );
                    })}

                    <View style={s.qtyRow}>
                        <Text style={s.infoText}>Jumlah</Text>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
                            <Pressable onPress={() => changeQty(-1)} style={s.qtyBtn}><Ionicons name="remove" size={18} color={colors.white} /></Pressable>
                            <Text style={s.qty}>{quantity}</Text>
                            <Pressable onPress={() => changeQty(1)} style={s.qtyBtn}><Ionicons name="add" size={18} color={colors.white} /></Pressable>
                        </View>
                    </View>

                    <Text style={[s.section, { marginTop: 22 }]}>Kode Voucher</Text>
                    <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}>
                        <View style={{ flex: 1 }}>
                            <Input
                                value={voucherCode}
                                onChangeText={(v) => { setVoucherCode(v.toUpperCase()); setVoucherInfo(null); }}
                                placeholder="Contoh: HEMAT10"
                                autoCapitalize="characters"
                                error={voucherError}
                            />
                        </View>
                        <Button title="Terapkan" variant="ghost" onPress={applyVoucher} style={{ paddingVertical: 12 }} />
                    </View>
                    {voucherInfo?.valid && <Text style={s.voucherOk}>Diskon {formatRupiah(voucherInfo.discountAmount)} diterapkan</Text>}
                </View>
            </ScrollView>

            {/* Bar checkout menempel di bawah */}
            <View style={[s.bar, { paddingBottom: Math.max(insets.bottom, 14) }]}>
                <View style={{ flex: 1 }}>
                    <Text style={s.barLabel}>{discount > 0 ? `Hemat ${formatRupiah(discount)}` : 'Total'}</Text>
                    <Text style={s.barTotal}>{formatRupiah(total)}</Text>
                    {error ? <Text style={[s.voucherOk, { color: colors.flare2 }]} numberOfLines={2}>{error}</Text> : null}
                </View>
                <Button
                    title={soldOut ? 'Habis' : user ? 'Beli Tiket' : 'Masuk untuk Beli'}
                    onPress={checkout}
                    loading={submitting}
                    disabled={soldOut}
                    style={{ minWidth: 150 }}
                />
            </View>
        </KeyboardAvoidingView>
    );
}

const s = StyleSheet.create({
    genre: { alignSelf: 'flex-start', backgroundColor: 'rgba(47,230,208,0.15)', borderRadius: radius.pill, paddingHorizontal: 12, paddingVertical: 4 },
    genreText: { color: colors.pulse, fontSize: 11, fontWeight: '800', textTransform: 'uppercase' },
    title: { color: colors.white, fontSize: 26, fontWeight: '800', marginTop: 12 },
    artist: { color: colors.muted, fontSize: 14, marginTop: 4 },
    infoBox: { marginTop: 18, backgroundColor: colors.panel, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, padding: 16, gap: 12 },
    infoRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    infoText: { color: colors.white, fontSize: 14, fontWeight: '500', flexShrink: 1 },
    mapBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, alignSelf: 'flex-start', borderWidth: 1, borderColor: colors.line, borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 8 },
    mapBtnText: { color: colors.white, fontSize: 12, fontWeight: '700' },
    desc: { color: colors.muted, fontSize: 14, lineHeight: 22, marginTop: 18 },
    section: { color: colors.white, fontSize: 18, fontWeight: '800', marginTop: 26, marginBottom: 12 },
    type: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: colors.line, backgroundColor: colors.panel, borderRadius: radius.md, padding: 14, marginBottom: 10 },
    typeActive: { borderColor: colors.flare, backgroundColor: 'rgba(255,61,122,0.1)' },
    typeName: { color: colors.white, fontSize: 15, fontWeight: '700' },
    typeLeft: { color: colors.muted, fontSize: 12, marginTop: 2 },
    typePrice: { color: colors.pulse, fontSize: 15, fontWeight: '800' },
    qtyRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
    qtyBtn: { width: 34, height: 34, borderRadius: 17, borderWidth: 1, borderColor: colors.line, alignItems: 'center', justifyContent: 'center' },
    qty: { color: colors.white, fontSize: 16, fontWeight: '700', minWidth: 20, textAlign: 'center' },
    voucherOk: { color: colors.pulse, fontSize: 12, marginTop: 2 },
    bar: { position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: colors.panel, borderTopWidth: 1, borderTopColor: colors.line, paddingHorizontal: 20, paddingTop: 14 },
    barLabel: { color: colors.muted, fontSize: 12 },
    barTotal: { color: colors.white, fontSize: 20, fontWeight: '800' }
});

import { useCallback, useRef, useState } from 'react';
import { FlatList, Modal, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import QRCode from 'react-native-qrcode-svg';
import { Ionicons } from '@expo/vector-icons';
import { getMyOrders, syncOrder } from '../../src/api/client';
import { useAuth } from '../../src/context/AuthContext';
import { Button, Empty, Loading } from '../../src/components/ui';
import { colors, radius } from '../../src/theme';
import { formatDate, formatDateLong, formatRupiah } from '../../src/utils/format';

const STATUS = {
    paid: { label: 'Lunas', color: colors.pulse, bg: 'rgba(47,230,208,0.15)' },
    pending: { label: 'Menunggu Pembayaran', color: colors.warn, bg: 'rgba(250,204,21,0.15)' },
    cancelled: { label: 'Dibatalkan', color: colors.danger, bg: 'rgba(248,113,113,0.15)' },
    expired: { label: 'Kadaluarsa', color: colors.danger, bg: 'rgba(248,113,113,0.15)' }
};

function TicketModal({ selected, onClose }) {
    if (!selected) return null;
    const { order, ticket } = selected;
    const Row = ({ k, v, mono }) => (
        <View style={s.dRow}>
            <Text style={s.dKey}>{k}</Text>
            <Text style={[s.dVal, mono && { fontFamily: 'monospace', fontSize: 11 }]}>{v}</Text>
        </View>
    );

    return (
        <Modal visible animationType="slide" transparent onRequestClose={onClose}>
            <View style={s.backdrop}>
                <View style={s.sheet}>
                    <ScrollView>
                        <LinearGradient colors={[colors.flare, colors.flare2, colors.pulse]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.sheetHead}>
                            <Pressable onPress={onClose} hitSlop={10} style={s.close}>
                                <Ionicons name="close" size={20} color={colors.white} />
                            </Pressable>
                            <Text style={s.eyebrow}>E-TIKET HEBOHIN</Text>
                            <Text style={s.sheetTitle}>{order.events?.name || 'Event'}</Text>
                            <Text style={s.sheetSub}>{order.events?.venue || ''}</Text>
                        </LinearGradient>

                        <View style={{ padding: 20, alignItems: 'center' }}>
                            <View style={s.qrBox}>
                                <QRCode value={ticket.ticket_code} size={210} />
                            </View>
                            <Text style={s.code}>{ticket.ticket_code}</Text>
                            <Text style={s.hint}>Tunjukkan QR ini ke petugas di pintu masuk. Jangan bagikan ke orang lain.</Text>
                            <View style={[s.pill, { backgroundColor: ticket.is_used ? 'rgba(248,113,113,0.15)' : 'rgba(47,230,208,0.15)' }]}>
                                <Text style={{ color: ticket.is_used ? colors.danger : colors.pulse, fontSize: 11, fontWeight: '800' }}>
                                    {ticket.is_used ? 'SUDAH DIPAKAI' : 'BELUM DIPAKAI'}
                                </Text>
                            </View>

                            <View style={s.details}>
                                <Row k="Kategori" v={ticket.category} />
                                {ticket.seat_label ? <Row k="Nomor Kursi" v={ticket.seat_label} /> : null}
                                <Row k="Tanggal" v={formatDateLong(order.events?.event_date)} />
                                <Row k="Venue" v={order.events?.venue || '-'} />
                                <Row k="Order ID" v={order.order_id} mono />
                                <Row k="Status Bayar" v={STATUS[order.status]?.label || order.status} />
                            </View>
                            <Button title="Tutup" onPress={onClose} style={{ alignSelf: 'stretch', marginTop: 20 }} />
                        </View>
                    </ScrollView>
                </View>
            </View>
        </Modal>
    );
}

export default function Tickets() {
    const router = useRouter();
    const { orderId } = useLocalSearchParams();
    const { user, loading: authLoading } = useAuth();
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [selected, setSelected] = useState(null);
    const autoOpened = useRef(null);

    const load = useCallback(async () => {
        if (!user) { setLoading(false); return; }
        try {
            let res = await getMyOrders();
            setOrders(res.data);

            // Order yang masih pending: tanya status terbaru ke Midtrans lewat backend
            const pending = res.data.filter(o => o.status === 'pending');
            if (pending.length > 0) {
                await Promise.allSettled(pending.map(o => syncOrder(o.order_id)));
                res = await getMyOrders();
                setOrders(res.data);
            }

            // Habis bayar: langsung buka tiket pertama dari order tersebut
            if (orderId && autoOpened.current !== orderId) {
                const match = res.data.find(o => o.order_id === orderId);
                if (match?.status === 'paid' && match.tickets?.length > 0) {
                    autoOpened.current = orderId;
                    setSelected({ order: match, ticket: match.tickets[0] });
                }
            }
        } catch (err) {
            console.warn('[tickets] gagal memuat', err?.message);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, [user, orderId]);

    useFocusEffect(useCallback(() => { load(); }, [load]));

    const renderOrder = ({ item: order }) => {
        const st = STATUS[order.status] || { label: order.status, color: colors.muted, bg: 'rgba(255,255,255,0.08)' };
        return (
            <View style={s.card}>
                <View style={{ padding: 16 }}>
                    <View style={[s.pill, { backgroundColor: st.bg, alignSelf: 'flex-start' }]}>
                        <Text style={{ color: st.color, fontSize: 11, fontWeight: '800' }}>{st.label.toUpperCase()}</Text>
                    </View>
                    <Text style={s.eventName}>{order.events?.name || 'Event'}</Text>
                    <Text style={s.meta}>
                        {order.events?.venue}{order.events?.event_date ? ` · ${formatDate(order.events.event_date)}` : ''}
                    </Text>
                    <Text style={[s.meta, { marginTop: 4 }]}>Order ID: {order.order_id}</Text>
                    <View style={s.totalRow}>
                        <Text style={s.meta}>Total Bayar</Text>
                        <Text style={s.total}>{formatRupiah(order.total_amount)}</Text>
                    </View>
                </View>

                {order.status === 'paid' && order.tickets?.length > 0 && (
                    <View style={s.ticketsBox}>
                        <Text style={s.ticketsLabel}>{order.tickets.length} E-TIKET — KETUK UNTUK LIHAT QR</Text>
                        {order.tickets.map(t => (
                            <Pressable key={t.id} style={s.ticketRow} onPress={() => setSelected({ order, ticket: t })}>
                                <View style={s.qrMini}><QRCode value={t.ticket_code} size={52} /></View>
                                <View style={{ flex: 1, marginLeft: 12 }}>
                                    <Text style={s.tCat} numberOfLines={1}>{t.category}{t.seat_label ? ` · Kursi ${t.seat_label}` : ''}</Text>
                                    <Text style={s.tCode} numberOfLines={1}>{t.ticket_code}</Text>
                                    <Text style={{ color: t.is_used ? colors.danger : colors.pulse, fontSize: 11, fontWeight: '700', marginTop: 3 }}>
                                        {t.is_used ? 'Sudah dipakai' : 'Belum dipakai'}
                                    </Text>
                                </View>
                                <Ionicons name="chevron-forward" size={18} color={colors.muted} />
                            </Pressable>
                        ))}
                    </View>
                )}
            </View>
        );
    };

    return (
        <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={{ paddingHorizontal: 20, paddingTop: 12 }}>
                <Text style={s.title}>Tiket Saya</Text>
                <Text style={s.sub}>Semua tiket dan riwayat pesananmu.</Text>
            </View>

            {authLoading || loading ? <Loading /> : !user ? (
                <View style={{ padding: 20 }}>
                    <Empty text="Masuk untuk melihat tiket dan riwayat pesananmu.">
                        <Button title="Masuk" onPress={() => router.push('/login')} />
                    </Empty>
                </View>
            ) : (
                <FlatList
                    data={orders}
                    keyExtractor={(o) => o.id}
                    renderItem={renderOrder}
                    contentContainerStyle={{ padding: 20 }}
                    ListEmptyComponent={<Empty text="Kamu belum punya tiket. Yuk jelajahi event yang tersedia.">
                        <Button title="Jelajahi Event" variant="ghost" onPress={() => router.push('/explore')} />
                    </Empty>}
                    refreshControl={<RefreshControl refreshing={refreshing} tintColor={colors.flare} onRefresh={() => { setRefreshing(true); load(); }} />}
                />
            )}

            <TicketModal selected={selected} onClose={() => setSelected(null)} />
        </SafeAreaView>
    );
}

const s = StyleSheet.create({
    title: { color: colors.white, fontSize: 26, fontWeight: '800' },
    sub: { color: colors.muted, fontSize: 13, marginTop: 4 },
    card: { backgroundColor: colors.panel, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, marginBottom: 16, overflow: 'hidden' },
    pill: { borderRadius: radius.pill, paddingHorizontal: 12, paddingVertical: 5 },
    eventName: { color: colors.white, fontSize: 17, fontWeight: '700', marginTop: 10 },
    meta: { color: colors.muted, fontSize: 12, marginTop: 2 },
    totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 },
    total: { color: colors.pulse, fontSize: 17, fontWeight: '800' },
    ticketsBox: { borderTopWidth: 1, borderStyle: 'dashed', borderColor: colors.line, backgroundColor: colors.panel2, padding: 14 },
    ticketsLabel: { color: colors.muted, fontSize: 11, fontWeight: '700', marginBottom: 10, letterSpacing: 0.4 },
    ticketRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.ink, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.line, padding: 10, marginBottom: 8 },
    qrMini: { backgroundColor: colors.white, padding: 4, borderRadius: 6 },
    tCat: { color: colors.white, fontSize: 13, fontWeight: '700' },
    tCode: { color: colors.muted, fontSize: 11, marginTop: 2 },
    backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
    sheet: { backgroundColor: colors.panel, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg, maxHeight: '92%', overflow: 'hidden' },
    sheetHead: { padding: 20 },
    close: { position: 'absolute', right: 14, top: 14, width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(10,10,18,0.35)', alignItems: 'center', justifyContent: 'center', zIndex: 2 },
    eyebrow: { color: colors.white, fontSize: 11, fontWeight: '800', letterSpacing: 2, opacity: 0.9 },
    sheetTitle: { color: colors.white, fontSize: 22, fontWeight: '800', marginTop: 8, paddingRight: 36 },
    sheetSub: { color: colors.white, fontSize: 12, opacity: 0.9, marginTop: 4 },
    qrBox: { backgroundColor: colors.white, padding: 14, borderRadius: radius.md },
    code: { color: colors.white, fontSize: 13, fontWeight: '800', letterSpacing: 1.5, marginTop: 14, textAlign: 'center' },
    hint: { color: colors.muted, fontSize: 11, textAlign: 'center', marginTop: 6, marginBottom: 12 },
    details: { alignSelf: 'stretch', marginTop: 18, backgroundColor: colors.panel2, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, padding: 14, gap: 10 },
    dRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 16 },
    dKey: { color: colors.muted, fontSize: 13 },
    dVal: { color: colors.white, fontSize: 13, fontWeight: '600', flexShrink: 1, textAlign: 'right' }
});

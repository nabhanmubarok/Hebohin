import { useCallback, useState } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getEvents } from '../../src/api/client';
import { useAuth } from '../../src/context/AuthContext';
import { useFavorites } from '../../src/context/FavoritesContext';
import EventCard from '../../src/components/EventCard';
import { Button, Empty, Loading } from '../../src/components/ui';
import { colors } from '../../src/theme';

export default function Favorites() {
    const router = useRouter();
    const { user, loading: authLoading } = useAuth();
    const { favoriteIds } = useFavorites();
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);

    useFocusEffect(useCallback(() => {
        getEvents().then(r => setEvents(r.data)).catch(() => {}).finally(() => setLoading(false));
    }, []));

    const favs = events.filter(e => favoriteIds.includes(e.id));

    return (
        <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={s.head}>
                <Text style={s.title}>Event Favorit</Text>
                <Text style={s.sub}>Event yang kamu tandai akan muncul di sini.</Text>
            </View>

            {authLoading || loading ? <Loading /> : !user ? (
                <View style={{ padding: 20 }}>
                    <Empty text="Masuk dulu untuk menyimpan event favoritmu.">
                        <Button title="Masuk" onPress={() => router.push('/login')} />
                    </Empty>
                </View>
            ) : (
                <FlatList
                    data={favs}
                    keyExtractor={(e) => e.id}
                    contentContainerStyle={{ padding: 20, paddingTop: 8 }}
                    renderItem={({ item }) => <EventCard event={item} />}
                    ListEmptyComponent={<Empty text="Belum ada event favorit. Tandai event dengan ikon hati." />}
                />
            )}
        </SafeAreaView>
    );
}

const s = StyleSheet.create({
    head: { paddingHorizontal: 20, paddingTop: 12 },
    title: { color: colors.white, fontSize: 26, fontWeight: '800' },
    sub: { color: colors.muted, fontSize: 13, marginTop: 4 }
});

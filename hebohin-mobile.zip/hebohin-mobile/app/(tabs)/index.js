import { useCallback, useState } from 'react';
import { FlatList, Pressable, RefreshControl, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getEvents } from '../../src/api/client';
import { useAuth } from '../../src/context/AuthContext';
import EventCard from '../../src/components/EventCard';
import { Empty, Loading } from '../../src/components/ui';
import { colors, radius } from '../../src/theme';

export default function Home() {
    const router = useRouter();
    const { user } = useAuth();
    const { width } = useWindowDimensions();
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState('');

    const load = useCallback(async () => {
        try {
            const res = await getEvents();
            setEvents(res.data);
            setError('');
        } catch {
            setError('Gagal memuat event. Tarik layar ke bawah untuk coba lagi.');
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    useFocusEffect(useCallback(() => { load(); }, [load]));

    const firstName = user?.name?.split(' ')[0];
    const featured = events.slice(0, 5);

    const header = (
        <View>
            <View style={s.top}>
                <Text style={s.brand}>Heboh<Text style={{ color: colors.flare }}>In</Text></Text>
                <Text style={s.hello}>
                    Siap untuk beat berikutnya{firstName ? ', ' : ''}
                    {firstName ? <Text style={{ color: colors.flare2 }}>{firstName}</Text> : null}?
                </Text>
                <Pressable style={s.search} onPress={() => router.push('/explore')}>
                    <Ionicons name="search" size={18} color={colors.muted} />
                    <Text style={{ color: colors.muted, marginLeft: 10 }}>Cari event atau artis...</Text>
                </Pressable>
            </View>

            {featured.length > 0 && (
                <View style={{ marginTop: 24 }}>
                    <Text style={s.section}>Unggulan</Text>
                    <FlatList
                        horizontal
                        data={featured}
                        keyExtractor={(e) => e.id}
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={{ paddingHorizontal: 20 }}
                        renderItem={({ item }) => <EventCard event={item} variant="wide" width={Math.min(width * 0.78, 320)} />}
                    />
                </View>
            )}

            <Text style={[s.section, { marginTop: 24 }]}>Sedang Tayang</Text>
        </View>
    );

    return (
        <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            {loading ? <Loading text="Memuat event..." /> : (
                <FlatList
                    data={events}
                    keyExtractor={(e) => e.id}
                    ListHeaderComponent={header}
                    renderItem={({ item }) => <View style={{ paddingHorizontal: 20 }}><EventCard event={item} /></View>}
                    ListEmptyComponent={<View style={{ paddingHorizontal: 20 }}><Empty text={error || 'Belum ada event yang tayang.'} /></View>}
                    refreshControl={<RefreshControl refreshing={refreshing} tintColor={colors.flare} onRefresh={() => { setRefreshing(true); load(); }} />}
                    contentContainerStyle={{ paddingBottom: 24 }}
                />
            )}
        </SafeAreaView>
    );
}

const s = StyleSheet.create({
    top: { paddingHorizontal: 20, paddingTop: 12 },
    brand: { color: colors.white, fontSize: 26, fontWeight: '800' },
    hello: { color: colors.white, fontSize: 20, fontWeight: '700', marginTop: 14, lineHeight: 28 },
    search: {
        flexDirection: 'row', alignItems: 'center', marginTop: 16,
        backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.line,
        borderRadius: radius.pill, paddingHorizontal: 16, paddingVertical: 13
    },
    section: { color: colors.white, fontSize: 18, fontWeight: '800', paddingHorizontal: 20, marginBottom: 12 }
});

import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/context/AuthContext';
import { Button, Loading } from '../../src/components/ui';
import { colors, radius } from '../../src/theme';

const ROLE_LABEL = { customer: 'Pelanggan', organizer: 'Organizer', admin: 'Admin', super_admin: 'Super Admin' };

function MenuItem({ icon, label, onPress, danger }) {
    return (
        <Pressable onPress={onPress} style={s.item}>
            <Ionicons name={icon} size={20} color={danger ? colors.danger : colors.white} />
            <Text style={[s.itemText, danger && { color: colors.danger }]}>{label}</Text>
            {!danger && <Ionicons name="chevron-forward" size={18} color={colors.muted} />}
        </Pressable>
    );
}

export default function Account() {
    const router = useRouter();
    const { user, loading, logout } = useAuth();

    if (loading) return <Loading />;

    if (!user) {
        return (
            <SafeAreaView style={{ flex: 1 }} edges={['top']}>
                <View style={s.guest}>
                    <Text style={s.brand}>Heboh<Text style={{ color: colors.flare }}>In</Text></Text>
                    <Text style={s.guestText}>Masuk untuk beli tiket, simpan favorit, dan lihat e-tiketmu.</Text>
                    <Button title="Masuk" onPress={() => router.push('/login')} style={{ alignSelf: 'stretch' }} />
                    <Button title="Daftar Akun Baru" variant="ghost" onPress={() => router.push('/register')} style={{ alignSelf: 'stretch' }} />
                </View>
            </SafeAreaView>
        );
    }

    const canManage = ['organizer', 'admin', 'super_admin'].includes(user.role);

    function confirmLogout() {
        Alert.alert('Keluar', 'Yakin ingin keluar dari akunmu?', [
            { text: 'Batal', style: 'cancel' },
            { text: 'Keluar', style: 'destructive', onPress: async () => { await logout(); } }
        ]);
    }

    return (
        <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <ScrollView contentContainerStyle={{ padding: 20 }}>
                <Text style={s.title}>Akun</Text>

                <View style={s.profile}>
                    <View style={s.avatar}><Text style={s.avatarText}>{user.name?.[0]?.toUpperCase() || '?'}</Text></View>
                    <View style={{ flex: 1 }}>
                        <Text style={s.name} numberOfLines={1}>{user.name}</Text>
                        <Text style={s.email} numberOfLines={1}>{user.email}</Text>
                        <View style={s.role}><Text style={s.roleText}>{(ROLE_LABEL[user.role] || user.role).toUpperCase()}</Text></View>
                    </View>
                </View>

                <View style={s.menu}>
                    <MenuItem icon="ticket-outline" label="Tiket Saya" onPress={() => router.push('/tickets')} />
                    <MenuItem icon="heart-outline" label="Event Favorit" onPress={() => router.push('/favorites')} />
                    {canManage && <MenuItem icon="stats-chart-outline" label="Kelola Event" onPress={() => router.push('/organizer')} />}
                </View>

                <View style={[s.menu, { marginTop: 16 }]}>
                    <MenuItem icon="log-out-outline" label="Keluar" danger onPress={confirmLogout} />
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

const s = StyleSheet.create({
    title: { color: colors.white, fontSize: 26, fontWeight: '800', marginBottom: 18 },
    guest: { flex: 1, justifyContent: 'center', padding: 28, gap: 14 },
    brand: { color: colors.white, fontSize: 32, fontWeight: '800', textAlign: 'center' },
    guestText: { color: colors.muted, fontSize: 14, textAlign: 'center', marginBottom: 10 },
    profile: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: colors.panel, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.line, padding: 16 },
    avatar: { width: 56, height: 56, borderRadius: 28, backgroundColor: colors.flare, alignItems: 'center', justifyContent: 'center' },
    avatarText: { color: colors.white, fontSize: 22, fontWeight: '800' },
    name: { color: colors.white, fontSize: 17, fontWeight: '700' },
    email: { color: colors.muted, fontSize: 13, marginTop: 2 },
    role: { alignSelf: 'flex-start', marginTop: 8, backgroundColor: 'rgba(47,230,208,0.15)', borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 3 },
    roleText: { color: colors.pulse, fontSize: 10, fontWeight: '800', letterSpacing: 0.5 },
    menu: { marginTop: 20, backgroundColor: colors.panel, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, overflow: 'hidden' },
    item: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.line },
    itemText: { flex: 1, color: colors.white, fontSize: 15, fontWeight: '600' }
});

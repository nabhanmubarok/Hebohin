import { useCallback, useMemo, useState } from 'react';
import { FlatList, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { getEvents } from '../../src/api/client';
import EventCard from '../../src/components/EventCard';
import { Chip, Empty, Loading } from '../../src/components/ui';
import { colors, radius } from '../../src/theme';

export default function Explore() {
    const [events, setEvents] = useState([]);
    const [search, setSearch] = useState('');
    const [genre, setGenre] = useState('Semua');
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const load = useCallback(async () => {
        try {
            const res = await getEvents();
            setEvents(res.data);
        } catch { /* biarkan daftar lama */ } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    useFocusEffect(useCallback(() => { load(); }, [load]));

    const genres = useMemo(() => ['Semua', ...new Set(events.map(e => e.genre).filter(Boolean))], [events]);

    const filtered = events.filter(e => {
        const q = search.toLowerCase();
        const matchSearch = e.name?.toLowerCase().includes(q) || e.artist?.toLowerCase().includes(q);
        return matchSearch && (genre === 'Semua' || e.genre === genre);
    });

    return (
        <SafeAreaView style={{ flex: 1 }} edges={['top']}>
            <View style={s.head}>
                <Text style={s.title}>Jelajahi Konser</Text>
                <View style={s.search}>
                    <Ionicons name="search" size={18} color={colors.muted} />
                    <TextInput
                        value={search}
                        onChangeText={setSearch}
                        placeholder="Cari nama event atau artis..."
                        placeholderTextColor={colors.muted}
                        style={s.input}
                        returnKeyType="search"
                    />
                </View>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 14 }}>
                    {genres.map(g => <Chip key={g} label={g} active={genre === g} onPress={() => setGenre(g)} />)}
                </ScrollView>
            </View>

            {loading ? <Loading text="Memuat event..." /> : (
                <FlatList
                    data={filtered}
                    keyExtractor={(e) => e.id}
                    keyboardShouldPersistTaps="handled"
                    contentContainerStyle={{ padding: 20, paddingTop: 8 }}
                    renderItem={({ item }) => <EventCard event={item} />}
                    ListEmptyComponent={<Empty text="Tidak ada event yang cocok dengan pencarianmu." />}
                    refreshControl={<RefreshControl refreshing={refreshing} tintColor={colors.flare} onRefresh={() => { setRefreshing(true); load(); }} />}
                />
            )}
        </SafeAreaView>
    );
}

const s = StyleSheet.create({
    head: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 8 },
    title: { color: colors.white, fontSize: 26, fontWeight: '800' },
    search: {
        flexDirection: 'row', alignItems: 'center', marginTop: 14,
        backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.line,
        borderRadius: radius.pill, paddingHorizontal: 16
    },
    input: { flex: 1, color: colors.white, paddingVertical: 12, marginLeft: 10, fontSize: 14 }
});

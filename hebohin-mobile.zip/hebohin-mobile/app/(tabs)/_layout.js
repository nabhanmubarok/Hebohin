import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../src/theme';

const icon = (name, nameOutline) => ({ color, focused, size }) => (
    <Ionicons name={focused ? name : nameOutline} size={size} color={color} />
);

export default function TabsLayout() {
    return (
        <Tabs
            screenOptions={{
                headerShown: false,
                tabBarActiveTintColor: colors.flare,
                tabBarInactiveTintColor: colors.muted,
                tabBarStyle: { backgroundColor: colors.panel, borderTopColor: colors.line },
                tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
                sceneStyle: { backgroundColor: colors.ink }
            }}
        >
            <Tabs.Screen name="index" options={{ title: 'Beranda', tabBarIcon: icon('home', 'home-outline') }} />
            <Tabs.Screen name="explore" options={{ title: 'Jelajahi', tabBarIcon: icon('search', 'search-outline') }} />
            <Tabs.Screen name="tickets" options={{ title: 'Tiket', tabBarIcon: icon('ticket', 'ticket-outline') }} />
            <Tabs.Screen name="favorites" options={{ title: 'Favorit', tabBarIcon: icon('heart', 'heart-outline') }} />
            <Tabs.Screen name="account" options={{ title: 'Akun', tabBarIcon: icon('person', 'person-outline') }} />
        </Tabs>
    );
}

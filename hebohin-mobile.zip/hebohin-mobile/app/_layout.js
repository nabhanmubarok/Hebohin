import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from '../src/context/AuthContext';
import { FavoritesProvider } from '../src/context/FavoritesContext';
import { colors } from '../src/theme';

export default function RootLayout() {
    return (
        <SafeAreaProvider>
            <AuthProvider>
                <FavoritesProvider>
                    <StatusBar style="light" />
                    <Stack
                        screenOptions={{
                            headerStyle: { backgroundColor: colors.ink },
                            headerTintColor: colors.white,
                            headerTitleStyle: { fontWeight: '700' },
                            headerShadowVisible: false,
                            contentStyle: { backgroundColor: colors.ink }
                        }}
                    >
                        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
                        <Stack.Screen name="event/[id]" options={{ title: 'Detail Event' }} />
                        <Stack.Screen name="login" options={{ title: 'Masuk' }} />
                        <Stack.Screen name="register" options={{ title: 'Daftar' }} />
                        <Stack.Screen name="verify-otp" options={{ title: 'Verifikasi Email' }} />
                        <Stack.Screen name="checkout" options={{ title: 'Pembayaran', gestureEnabled: false }} />
                        <Stack.Screen name="organizer" options={{ title: 'Kelola Event' }} />
                    </Stack>
                </FavoritesProvider>
            </AuthProvider>
        </SafeAreaProvider>
    );
}

import { useRef, useState } from 'react';
import { ActivityIndicator, Alert, BackHandler, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect } from 'react';
import { WebView } from 'react-native-webview';
import { syncOrder } from '../src/api/client';
import { colors } from '../src/theme';

// Halaman pembayaran Midtrans Snap di dalam WebView.
// Setelah bayar, Midtrans mengarahkan ke FRONTEND_URL/my-tickets?order_id=... (URL web).
// Kita cegat redirect itu, jangan dimuat, lalu sinkronkan status & buka tab Tiket.
const isFinishUrl = (u) => /order_id=/.test(u) && /my-tickets/.test(u);

export default function Checkout() {
    const { url, orderId } = useLocalSearchParams();
    const router = useRouter();
    const [finishing, setFinishing] = useState(false);
    const done = useRef(false);

    async function finish() {
        if (done.current) return;
        done.current = true;
        setFinishing(true);
        try { await syncOrder(orderId); } catch { /* tab Tiket akan sinkron ulang */ }
        router.replace({ pathname: '/tickets', params: { orderId } });
    }

    function confirmClose() {
        Alert.alert(
            'Tutup pembayaran?',
            'Kalau kamu sudah membayar, tiket akan muncul di tab Tiket setelah dikonfirmasi.',
            [
                { text: 'Lanjut Bayar', style: 'cancel' },
                { text: 'Tutup', onPress: finish }
            ]
        );
    }

    // Tombol back Android = konfirmasi tutup, bukan keluar diam-diam
    useEffect(() => {
        const sub = BackHandler.addEventListener('hardwareBackPress', () => { confirmClose(); return true; });
        return () => sub.remove();
    }, []);

    function onShouldStart(req) {
        const u = req.url || '';
        if (isFinishUrl(u)) { finish(); return false; }
        // Deep link e-wallet (gopay://, shopeepay://, intent://, ...) dibuka aplikasinya
        if (!/^(https?:|about:|data:|blob:)/i.test(u)) {
            Linking.openURL(u).catch(() => Alert.alert('Aplikasi tidak ditemukan', 'Pilih metode pembayaran lain atau pasang aplikasinya dulu.'));
            return false;
        }
        return true;
    }

    if (!url) return <View style={s.center}><Text style={{ color: colors.muted }}>Link pembayaran tidak ditemukan.</Text></View>;

    return (
        <View style={{ flex: 1, backgroundColor: colors.ink }}>
            <Stack.Screen
                options={{
                    title: 'Pembayaran',
                    headerBackVisible: false,
                    headerRight: () => (
                        <Pressable onPress={confirmClose} hitSlop={10}>
                            <Text style={{ color: colors.flare2, fontWeight: '700' }}>Tutup</Text>
                        </Pressable>
                    )
                }}
            />
            <WebView
                source={{ uri: String(url) }}
                onShouldStartLoadWithRequest={onShouldStart}
                onNavigationStateChange={(nav) => { if (isFinishUrl(nav.url || '')) finish(); }}
                startInLoadingState
                renderLoading={() => <View style={s.center}><ActivityIndicator color={colors.flare} /></View>}
                setSupportMultipleWindows={false}
                domStorageEnabled
                javaScriptEnabled
            />
            {finishing && (
                <View style={[s.center, StyleSheet.absoluteFill, { backgroundColor: 'rgba(10,10,18,0.9)' }]}>
                    <ActivityIndicator color={colors.flare} />
                    <Text style={{ color: colors.white, marginTop: 12 }}>Memeriksa status pembayaran...</Text>
                </View>
            )}
        </View>
    );
}

const s = StyleSheet.create({
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' }
});

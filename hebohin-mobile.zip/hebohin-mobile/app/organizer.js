import { useCallback, useState } from 'react';
import { FlatList, RefreshControl, StyleSheet, Switch, Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { getDashboardSummary, getManagedEvents, updateEvent } from '../src/api/client';
import { useAuth } from '../src/context/AuthContext';
import { Empty, Loading } from '../src/components/ui';
import { colors, radius } from '../src/theme';
import { errorMessage, formatDate, formatRupiah } from '../src/utils/format';

const MANAGER_ROLES = ['organizer', 'admin', 'super_admin'];

function Stat({ label, value, accent }) {
    return (
        <View style={s.stat}>
            <Text style={s.statLabel}>{label}</Text>
            <Text style={[s.statValue, accent && { color: accent }]} numberOfLines={1} adjustsFontSizeToFit>{value}</Text>
        </View>
    );
}

export default function Organizer() {
    const { user, loading: authLoading } = useAuth();
    const [events, setEvents] = useState([]);
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState('');

    const allowed = user && MANAGER_ROLES.includes(user.role);

    const load = useCallback(async () => {
        if (!allowed) { setLoading(false); return; }
        try {
            const [ev, sum] = await Promise.all([getManagedEvents(), getDashboardSummary()]);
            setEvents(ev.data);
            setStats(sum.data);
            setError('');
        } catch (err) {
            setError(errorMessage(err, 'Gagal memuat data'));
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, [allowed]);

    useFocusEffect(useCallback(() => { load(); }, [load]));

    async function toggleActive(event, value) {
        // Optimistik: ubah dulu di layar, balikin kalau gagal
        setEvents(list => list.map(e => e.id === event.id ? { ...e, is_active: value } : e));
        try {
            await updateEvent(event.id, { isActive: value });
        } catch (err) {
            setEvents(list => list.map(e => e.id === event.id ? { ...e, is_active: !value } : e));
            setError(errorMessage(err, 'Gagal mengubah status event'));
        }
    }

    if (authLoading || loading) return <Loading />;
    if (!allowed) return <View style={{ padding: 20 }}><Empty text="Halaman ini khusus organizer dan admin." /></View>;

    const header = (
        <View>
            {stats && (
                <View style={s.grid}>
                    <Stat label="Pendapatan" value={formatRupiah(stats.totalRevenue)} accent={colors.pulse} />
                    <Stat label="Pesanan Lunas" value={String(stats.totalOrders)} accent={colors.flare2} />
                    <Stat label="Tiket Terjual" value={String(stats.totalTicketsSold)} />
                    <Stat label="Total Event" value={String(stats.totalEvents)} />
                </View>
            )}
            {error ? <Text style={s.error}>{error}</Text> : null}
            <Text style={s.section}>{user.role === 'organizer' ? 'Event Milikmu' : 'Semua Event'}</Text>
        </View>
    );

    return (
        <FlatList
            data={events}
            keyExtractor={(e) => e.id}
            ListHeaderComponent={header}
            contentContainerStyle={{ padding: 20 }}
            refreshControl={<RefreshControl refreshing={refreshing} tintColor={colors.flare} onRefresh={() => { setRefreshing(true); load(); }} />}
            ListEmptyComponent={<Empty text="Belum ada event. Buat event baru lewat dashboard web HebohIn." />}
            renderItem={({ item }) => {
                const types = item.ticket_types || [];
                const sold = types.reduce((n, t) => n + (t.sold || 0), 0);
                const stock = types.reduce((n, t) => n + (t.stock || 0), 0);
                return (
                    <View style={s.card}>
                        <View style={{ flex: 1 }}>
                            <Text style={s.name} numberOfLines={2}>{item.name}</Text>
                            <Text style={s.meta}>{item.venue} · {formatDate(item.event_date)}</Text>
                            <Text style={s.meta}>Terjual {sold} / {stock} tiket</Text>
                            <Text style={[s.badge, { color: item.is_active ? colors.pulse : colors.muted }]}>
                                {item.is_active ? 'TAYANG' : 'NONAKTIF'}
                            </Text>
                        </View>
                        <Switch
                            value={Boolean(item.is_active)}
                            onValueChange={(v) => toggleActive(item, v)}
                            trackColor={{ false: colors.panel2, true: colors.flare }}
                            thumbColor={colors.white}
                        />
                    </View>
                );
            }}
        />
    );
}

const s = StyleSheet.create({
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
    stat: { width: '47.5%', backgroundColor: colors.panel, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, padding: 14 },
    statLabel: { color: colors.muted, fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 },
    statValue: { color: colors.white, fontSize: 20, fontWeight: '800', marginTop: 6 },
    section: { color: colors.white, fontSize: 18, fontWeight: '800', marginTop: 24, marginBottom: 12 },
    error: { color: colors.flare2, fontSize: 13, marginTop: 12 },
    card: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.panel, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, padding: 14, marginBottom: 12 },
    name: { color: colors.white, fontSize: 15, fontWeight: '700' },
    meta: { color: colors.muted, fontSize: 12, marginTop: 3 },
    badge: { fontSize: 10, fontWeight: '800', letterSpacing: 0.6, marginTop: 8 }
});

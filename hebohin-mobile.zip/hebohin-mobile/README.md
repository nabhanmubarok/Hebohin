# HebohIn Mobile (Expo)

Aplikasi mobile HebohIn untuk pembeli tiket, memakai backend Express yang sama dengan web.

## Fitur
- Beranda (carousel unggulan), Jelajahi (cari + filter genre), Favorit (tersimpan lokal per user)
- Detail event: zona tiket, jumlah, voucher, tombol Google Maps
- Checkout lewat Midtrans Snap di dalam WebView, status disinkronkan otomatis setelah bayar
- Tiket Saya: daftar pesanan + e-tiket dengan QR code
- Login, registrasi, verifikasi OTP email
- Kelola Event (khusus organizer/admin/super admin): ringkasan angka + aktif/nonaktifkan event miliknya

## Cara pasang

Project ini dibuat di atas template Expo terbaru supaya versi SDK-nya cocok dengan aplikasi Expo Go di HP kamu.

```bash
# 1. Buat project kosong dengan SDK terbaru
npx create-expo-app@latest hebohin-mobile --template blank
cd hebohin-mobile

# 2. Pasang dependency (expo install otomatis memilih versi yang cocok dengan SDK)
npx expo install expo-router expo-linking expo-constants expo-status-bar expo-linear-gradient \
  react-native-safe-area-context react-native-screens react-native-webview \
  react-native-svg @react-native-async-storage/async-storage
npm install axios react-native-qrcode-svg

# 3. Hapus file bawaan template, lalu salin isi folder ini
rm -f App.js index.js App.tsx index.ts
#    salin ke root project: folder app/ dan src/, plus .env.example dan .gitignore
#    (kalau template-mu punya folder app/ atau src/app bawaan, hapus dulu)
```

4. Edit `package.json`, ubah/tambah baris `main`:

```json
"main": "expo-router/entry"
```

5. Edit `app.json`, tambahkan `scheme` dan plugin router di dalam `"expo"`:

```json
"scheme": "hebohin",
"plugins": ["expo-router"]
```

6. Salin `.env.example` jadi `.env`, isi `EXPO_PUBLIC_API_URL` dengan IP laptop kamu di WiFi yang sama
   (bukan `localhost`, karena HP tidak bisa mengakses localhost laptop), misalnya `http://192.168.1.10:3000`.

7. Jalankan backend (`npm run dev`), lalu:

```bash
npx expo start -c
```

Scan QR dengan Expo Go (Android) atau kamera iPhone.

## Catatan penting
- **Login Google belum ada di mobile.** Alur OAuth backend mengembalikan sesi ke browser, bukan ke aplikasi. Login memakai email + password + OTP.
- **Sesi memakai cookie** (sama seperti web). Berjalan otomatis di React Native. Kalau backend sudah di HTTPS produksi, cookie `secure` tetap aman.
- **Build produksi (APK/IPA)** butuh backend HTTPS. Untuk HTTP biasa, Android memblokir cleartext di build rilis.
- **Midtrans**: setelah bayar, Midtrans mengarahkan ke `FRONTEND_URL/my-tickets?order_id=...`. Aplikasi mencegat URL itu, jadi `FRONTEND_URL` di backend tidak perlu diubah.
- Membuat/mengedit event lengkap (poster, kategori tiket, denah kursi) tetap lewat dashboard web.

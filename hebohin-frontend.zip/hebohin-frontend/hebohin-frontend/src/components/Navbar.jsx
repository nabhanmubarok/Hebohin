import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { logoutUser } from '../api/client';

export default function Navbar() {
    const { user, setUser } = useAuth();
    const navigate = useNavigate();

    async function handleLogout() {
        await logoutUser();
        setUser(null);
        navigate('/login');
    }

    const linkClass = ({ isActive }) =>
        `text-sm font-medium transition-colors ${isActive ? 'text-white' : 'text-muted hover:text-white'}`;

    return (
        <header className="sticky top-0 z-40 border-b border-line bg-ink/80 backdrop-blur-md">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
                <Link to="/" className="font-display text-xl font-bold tracking-tight">
                    Heboh<span className="text-flare">In</span>
                </Link>

                <nav className="hidden items-center gap-8 md:flex">
                    <NavLink to="/" end className={linkClass}>Beranda</NavLink>
                    <NavLink to="/explore" className={linkClass}>Jelajahi</NavLink>
                    <NavLink to="/my-tickets" className={linkClass}>Tiket Saya</NavLink>
                    <NavLink to="/favorites" className={linkClass}>Favorit</NavLink>
                    {(user?.role === 'admin' || user?.role === 'super_admin') && (
                        <NavLink to="/admin" className={linkClass}>Panel Admin</NavLink>
                    )}
                    {user?.role === 'customer' && (
                        <NavLink to="/become-organizer" className={linkClass}>Jadi Organizer</NavLink>
                    )}
                    {user?.role === 'organizer' && (
                        <NavLink to="/admin" className={linkClass}>Panel Organizer</NavLink>
                    )}
                </nav>

                <div className="flex items-center gap-4">
                    {user ? (
                        <div className="flex items-center gap-3">
                            <div className="hidden text-right sm:block">
                                <p className="text-xs text-muted">Halo,</p>
                                <p className="text-sm font-semibold leading-none">{user.name?.split(' ')[0]}</p>
                            </div>
                            <button
                                onClick={handleLogout}
                                className="rounded-full border border-line px-4 py-2 text-xs font-semibold text-muted transition hover:border-flare/60 hover:text-white"
                            >
                                Keluar
                            </button>
                        </div>
                    ) : (
                        <Link
                            to="/login"
                            className="rounded-full bg-flare px-5 py-2 text-sm font-semibold text-white shadow-glow transition hover:bg-flare2"
                        >
                            Masuk
                        </Link>
                    )}
                </div>
            </div>
        </header>
    );
}

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function HeroBanner({ events }) {
    const [index, setIndex] = useState(0);
    const withPoster = events.filter(e => e.poster_url);

    useEffect(() => {
        if (withPoster.length <= 1) return;
        const timer = setInterval(() => {
            setIndex(prev => (prev + 1) % withPoster.length);
        }, 6000);
        return () => clearInterval(timer);
    }, [withPoster.length]);

    if (withPoster.length === 0) return null;

    const event = withPoster[index];

    function prev() {
        setIndex(i => (i - 1 + withPoster.length) % withPoster.length);
    }
    function next() {
        setIndex(i => (i + 1) % withPoster.length);
    }

    return (
        <div className="relative overflow-hidden rounded-3xl border border-line shadow-glow">
            <Link to={`/events/${event.id}`} className="block">
                <div className="relative h-[420px] w-full">
                    <img src={event.poster_url} alt={event.name} className="h-full w-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-8">
                        <span className="rounded-full bg-flare px-3 py-1 text-[11px] font-semibold uppercase">
                            {event.genre || 'Konser'}
                        </span>
                        <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">{event.name}</h2>
                        <p className="mt-2 text-sm text-muted">
                            {new Date(event.event_date).toLocaleDateString('id-ID', {
                                day: 'numeric', month: 'long', year: 'numeric'
                            })} · {event.venue}, {event.city}
                        </p>
                    </div>
                </div>
            </Link>

            {withPoster.length > 1 && (
                <>
                    <button
                        onClick={(e) => { e.preventDefault(); prev(); }}
                        className="absolute left-4 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-ink/60 backdrop-blur hover:bg-ink/80"
                    >
                        ‹
                    </button>
                    <button
                        onClick={(e) => { e.preventDefault(); next(); }}
                        className="absolute right-4 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full bg-ink/60 backdrop-blur hover:bg-ink/80"
                    >
                        ›
                    </button>
                    <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-2">
                        {withPoster.map((_, i) => (
                            <button
                                key={i}
                                onClick={(e) => { e.preventDefault(); setIndex(i); }}
                                className={`h-1.5 rounded-full transition-all ${
                                    i === index ? 'w-6 bg-flare' : 'w-1.5 bg-white/40'
                                }`}
                            />
                        ))}
                    </div>
                </>
            )}
        </div>
    );
}
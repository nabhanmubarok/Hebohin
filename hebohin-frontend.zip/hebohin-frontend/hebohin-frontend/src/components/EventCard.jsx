import { Link } from 'react-router-dom';
import { useFavorites } from '../pages/Favorites';

function formatDate(dateStr) {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('id-ID', {
        day: 'numeric', month: 'short', year: 'numeric'
    });
}

function lowestPrice(ticketTypes) {
    if (!ticketTypes || ticketTypes.length === 0) return null;
    return Math.min(...ticketTypes.map(t => t.price));
}

export default function EventCard({ event }) {
    const price = lowestPrice(event.ticket_types);
    const { favoriteIds, toggleFavorite } = useFavorites();
    const isFavorite = favoriteIds.includes(event.id);

    return (
        <div className="group relative overflow-hidden rounded-2xl border border-line bg-panel transition hover:border-flare/50 hover:shadow-glow">
            <button
                onClick={(e) => { e.preventDefault(); toggleFavorite(event.id); }}
                aria-label={isFavorite ? 'Hapus dari favorit' : 'Tambah ke favorit'}
                className={`absolute right-3 top-3 z-10 flex h-8 w-8 items-center justify-center rounded-full backdrop-blur transition ${
                    isFavorite ? 'bg-flare text-white' : 'bg-ink/60 text-white/70 hover:text-white'
                }`}
            >
                ♥
            </button>
            <Link to={`/events/${event.id}`} className="block">
                <div className="relative h-40 w-full overflow-hidden bg-panel2">
    {event.poster_url ? (
        <img src={event.poster_url} alt={event.name} className="h-full w-full object-cover" />
    ) : (
        <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-flare/20 via-panel2 to-pulse/10 text-4xl font-display font-bold text-white/10">
            {event.name?.[0] ?? '?'}
        </div>
    )}
    <span className="absolute left-3 top-3 rounded-full bg-ink/70 px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-pulse backdrop-blur">
        {event.genre || 'Konser'}
    </span>
</div>
                <div className="space-y-1 p-4">
                    <h3 className="font-display text-base font-semibold leading-snug group-hover:text-flare2">
                        {event.name}
                    </h3>
                    <p className="text-xs text-muted">{event.venue} · {event.city}</p>
                    <div className="mt-3 flex items-center justify-between">
                        <span className="text-xs text-muted">{formatDate(event.event_date)}</span>
                        {price !== null && (
                            <span className="text-sm font-semibold text-pulse">
                                mulai Rp{price.toLocaleString('id-ID')}
                            </span>
                        )}
                    </div>
                </div>
            </Link>
        </div>
    );
}

// Peta zona venue: panggung di atas, zona termahal paling dekat panggung.
// Zona dibentuk otomatis dari ticket_types event (tidak perlu ubah database).
const ZONE_COLORS = [
    'border-flare bg-flare/20 text-flare2',
    'border-pulse bg-pulse/20 text-pulse',
    'border-yellow-400 bg-yellow-400/15 text-yellow-300',
    'border-sky-400 bg-sky-400/15 text-sky-300',
    'border-fuchsia-400 bg-fuchsia-400/15 text-fuchsia-300'
];

export default function VenueMap({ ticketTypes = [], selectedId, onSelect }) {
    // Urutkan dari harga tertinggi (dekat panggung) ke terendah (paling belakang)
    const zones = [...ticketTypes].sort((a, b) => b.price - a.price);
    const n = zones.length;
    if (n === 0) return null;

    return (
        <div className="mt-8">
            <h2 className="font-display text-lg font-semibold">Pilih Zona</h2>
            <p className="mt-1 text-xs text-muted">Klik zona di peta untuk memilih area tiketmu.</p>

            <div className="mt-4 rounded-3xl border border-line bg-panel p-5">
                <div className="mx-auto mb-5 w-2/3 rounded-b-2xl bg-white/10 py-2 text-center text-xs font-semibold uppercase tracking-[0.3em] text-muted">
                    Panggung
                </div>

                <div className="flex flex-col items-center gap-2">
                    {zones.map((z, i) => {
                        const remaining = z.stock - z.sold;
                        const soldOut = remaining <= 0;
                        const active = z.id === selectedId;
                        const width = n === 1 ? 100 : 55 + (45 * i) / (n - 1); // makin belakang makin lebar
                        const color = ZONE_COLORS[i % ZONE_COLORS.length];

                        return (
                            <button
                                key={z.id}
                                type="button"
                                disabled={soldOut}
                                onClick={() => onSelect(z)}
                                style={{ width: `${width}%` }}
                                className={`rounded-xl border-2 px-4 py-3 text-left transition ${
                                    soldOut
                                        ? 'cursor-not-allowed border-line bg-white/5 text-muted opacity-50'
                                        : color
                                } ${active ? 'scale-[1.02] ring-2 ring-white/70 shadow-glow' : 'hover:brightness-125'}`}
                            >
                                <div className="flex items-center justify-between gap-3">
                                    <span className="text-sm font-bold">{z.category}</span>
                                    <span className="text-xs font-semibold">Rp{z.price.toLocaleString('id-ID')}</span>
                                </div>
                                <p className="mt-0.5 text-[11px] opacity-80">
                                    {soldOut ? 'Habis' : `Sisa ${remaining} tiket`}
                                </p>
                            </button>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}
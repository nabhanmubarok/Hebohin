import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getEventById, createOrder, validateVoucher } from '../api/client';
import { useAuth } from '../context/AuthContext';
import VenueMap from '../components/VenueMap';

export default function EventDetail() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();

    const [event, setEvent] = useState(null);
    const [selected, setSelected] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const [voucherCode, setVoucherCode] = useState('');
    const [voucherInfo, setVoucherInfo] = useState(null);
    const [voucherError, setVoucherError] = useState('');
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        getEventById(id).then(res => {
            setEvent(res.data);
            setSelected(res.data.ticket_types?.find(t => t.stock - t.sold > 0) || res.data.ticket_types?.[0] || null);
        }).catch(console.error);
    }, [id]);

    if (!event) {
        return <div className="mx-auto max-w-4xl px-6 py-16 text-sm text-muted">Memuat detail event...</div>;
    }

    const subtotal = selected ? selected.price * quantity : 0;
    const discount = voucherInfo?.discountAmount || 0;
    const total = subtotal - discount;

    async function handleApplyVoucher() {
        setVoucherError('');
        setVoucherInfo(null);
        if (!voucherCode) return;
        try {
            const res = await validateVoucher({ code: voucherCode, totalAmount: subtotal });
            setVoucherInfo(res.data);
        } catch (err) {
            setVoucherError(err.response?.data?.message || 'Voucher tidak valid');
        }
    }

    async function handleCheckout() {
        if (!user) {
            navigate('/login');
            return;
        }
        setSubmitting(true);
        setError('');
        try {
            const res = await createOrder({
                eventId: event.id,
                items: [{
                    ticketTypeId: selected.id,
                    category: selected.category,
                    quantity,
                    pricePerItem: selected.price
                }],
                voucherCode: voucherInfo?.valid ? voucherCode : undefined
            });
            window.location.href = res.data.redirectUrl;
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal membuat order');
        } finally {
            setSubmitting(false);
        }
    }

    return (
        <div className="mx-auto max-w-5xl px-6 py-10">
            <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr]">
                <div>
                    <div className="relative h-56 w-full overflow-hidden rounded-3xl bg-panel2">
                        {event.poster_url ? (
                            <img src={event.poster_url} alt={event.name} className="h-full w-full object-cover" />
                        ) : (
                            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-flare/25 via-panel to-pulse/15 font-display text-6xl font-bold text-white/10">
                                {event.name?.[0]}
                            </div>
                        )}
                    </div>
                    <span className="mt-6 inline-block rounded-full bg-pulse/15 px-3 py-1 text-xs font-semibold uppercase text-pulse">
                        {event.genre || 'Konser'}
                    </span>
                    <h1 className="mt-3 font-display text-3xl font-bold">{event.name}</h1>
                    <p className="mt-1 text-sm text-muted">{event.artist}</p>

                    <div className="mt-6 flex flex-wrap gap-6 text-sm text-muted">
                        <div>
                            <p className="text-xs uppercase tracking-wide">Tanggal</p>
                            <p className="mt-1 font-medium text-white">
                                {new Date(event.event_date).toLocaleDateString('id-ID', {
                                    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
                                })}
                            </p>
                        </div>
                        <div>
                            <p className="text-xs uppercase tracking-wide">Lokasi</p>
                            <p className="mt-1 font-medium text-white">{event.venue}, {event.city}</p>
                        </div>
                    </div>

                    {event.description && (
                        <p className="mt-6 text-sm leading-relaxed text-muted">{event.description}</p>
                    )}

                    <VenueMap
                        ticketTypes={event.ticket_types}
                        selectedId={selected?.id}
                        onSelect={(z) => { setSelected(z); setQuantity(1); }}
                    />
                </div>

                {/* Kartu checkout */}
                <div className="h-fit rounded-3xl border border-line bg-panel p-6 shadow-glow">
                    <h2 className="font-display text-lg font-semibold">Pilih Tiket</h2>
                    {selected && <p className="mt-1 text-xs text-muted">Zona terpilih: <span className="font-semibold text-white">{selected.category}</span></p>}

                    <div className="mt-4 space-y-2">
                        {event.ticket_types?.map(tt => (
                            <button
                                key={tt.id}
                                onClick={() => setSelected(tt)}
                                className={`w-full rounded-xl border p-3 text-left transition ${
                                    selected?.id === tt.id
                                        ? 'border-flare bg-flare/10'
                                        : 'border-line hover:border-white/20'
                                }`}
                            >
                                <div className="flex items-center justify-between">
                                    <span className="text-sm font-semibold">{tt.category}</span>
                                    <span className="text-sm text-pulse">Rp{tt.price.toLocaleString('id-ID')}</span>
                                </div>
                                <p className="text-xs text-muted">Sisa {tt.stock - tt.sold} tiket</p>
                            </button>
                        ))}
                    </div>

                    <div className="mt-4 flex items-center justify-between">
                        <span className="text-sm text-muted">Jumlah</span>
                        <div className="flex items-center gap-3">
                            <button
                                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                                className="h-8 w-8 rounded-full border border-line text-sm hover:border-white/30"
                            >
                                −
                            </button>
                            <span className="w-4 text-center text-sm">{quantity}</span>
                            <button
                                onClick={() => setQuantity(q => Math.min(selected ? selected.stock - selected.sold : q, q + 1))}
                                className="h-8 w-8 rounded-full border border-line text-sm hover:border-white/30"
                            >
                                +
                            </button>
                        </div>
                    </div>

                    <div className="mt-4">
                        <label className="text-xs text-muted">Kode Voucher</label>
                        <div className="mt-1 flex gap-2">
                            <input
                                type="text"
                                value={voucherCode}
                                onChange={(e) => setVoucherCode(e.target.value.toUpperCase())}
                                placeholder="Contoh: HEMAT10"
                                className="w-full rounded-lg border border-line bg-panel2 px-3 py-2 text-sm outline-none placeholder:text-muted focus:border-pulse/60"
                            />
                            <button
                                onClick={handleApplyVoucher}
                                className="whitespace-nowrap rounded-lg border border-line px-3 py-2 text-xs font-semibold hover:border-pulse/60"
                            >
                                Terapkan
                            </button>
                        </div>
                        {voucherError && <p className="mt-1 text-xs text-flare2">{voucherError}</p>}
                        {voucherInfo?.valid && (
                            <p className="mt-1 text-xs text-pulse">
                                Diskon Rp{voucherInfo.discountAmount.toLocaleString('id-ID')} diterapkan
                            </p>
                        )}
                    </div>

                    <div className="mt-5 space-y-1 border-t border-line pt-4 text-sm">
                        <div className="flex justify-between text-muted">
                            <span>Subtotal</span>
                            <span>Rp{subtotal.toLocaleString('id-ID')}</span>
                        </div>
                        {discount > 0 && (
                            <div className="flex justify-between text-pulse">
                                <span>Diskon</span>
                                <span>-Rp{discount.toLocaleString('id-ID')}</span>
                            </div>
                        )}
                        <div className="flex justify-between pt-2 text-base font-semibold">
                            <span>Total</span>
                            <span>Rp{total.toLocaleString('id-ID')}</span>
                        </div>
                    </div>

                    {error && <p className="mt-3 text-xs text-flare2">{error}</p>}

                    <button
                        onClick={handleCheckout}
                        disabled={submitting || !selected}
                        className="mt-5 w-full rounded-full bg-flare py-3 text-sm font-semibold shadow-glow transition hover:bg-flare2 disabled:opacity-50"
                    >
                        {submitting ? 'Memproses...' : 'Beli Tiket'}
                    </button>
                </div>
            </div>
        </div>
    );
}
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { applyOrganizer, getMyApplication } from '../api/client';
import { useAuth } from '../context/AuthContext';

const statusInfo = {
    pending: { label: 'Menunggu Persetujuan', style: 'bg-yellow-500/15 text-yellow-400' },
    approved: { label: 'Disetujui', style: 'bg-pulse/15 text-pulse' },
    rejected: { label: 'Ditolak', style: 'bg-red-500/15 text-red-400' }
};

export default function BecomeOrganizer() {
    const { user, refreshUser } = useAuth();
    const navigate = useNavigate();
    const [application, setApplication] = useState(null);
    const [loading, setLoading] = useState(true);
    const [form, setForm] = useState({ businessName: '', description: '', phone: '' });
    const [error, setError] = useState('');
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        if (!user) {
            navigate('/login');
            return;
        }
        getMyApplication()
            .then(res => setApplication(res.data))
            .catch(() => setApplication(null))
            .finally(() => setLoading(false));
    }, [user]);

    async function handleSubmit(e) {
        e.preventDefault();
        setError('');
        setSubmitting(true);
        try {
            const res = await applyOrganizer(form);
            setApplication(res.data.application);
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal mengirim pengajuan');
        } finally {
            setSubmitting(false);
        }
    }

    if (loading) {
        return <div className="mx-auto max-w-2xl px-6 py-16 text-sm text-muted">Memuat...</div>;
    }

    // Sudah jadi organizer/admin, tidak perlu daftar lagi
    if (user?.role !== 'customer') {
        return (
            <div className="mx-auto max-w-2xl px-6 py-16 text-center">
                <p className="text-sm text-muted">
                    Akun kamu sudah punya akses sebagai <span className="text-white">{user.role}</span>.
                </p>
            </div>
        );
    }

    return (
        <div className="mx-auto max-w-2xl px-6 py-16">
            <h1 className="font-display text-3xl font-bold">Jadi Event Organizer</h1>
            <p className="mt-2 text-sm text-muted">
                Ajukan diri untuk mulai menyelenggarakan dan menjual tiket konsermu sendiri di HebohIn.
            </p>

            {application ? (
                <div className="mt-8 rounded-2xl border border-line bg-panel p-6">
                    <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold uppercase ${statusInfo[application.status]?.style}`}>
                        {statusInfo[application.status]?.label}
                    </span>
                    <h2 className="mt-3 font-display text-lg font-semibold">{application.business_name}</h2>
                    {application.description && (
                        <p className="mt-1 text-sm text-muted">{application.description}</p>
                    )}

                    {application.status === 'pending' && (
                        <p className="mt-4 text-xs text-muted">
                            Pengajuan kamu sedang ditinjau oleh admin. Kamu akan bisa membuat event begitu disetujui.
                        </p>
                    )}
                    {application.status === 'rejected' && (
                        <button
                            onClick={() => setApplication(null)}
                            className="mt-4 rounded-full border border-line px-5 py-2 text-xs font-semibold hover:border-flare/60"
                        >
                            Ajukan Ulang
                        </button>
                    )}
                </div>
            ) : (
                <form onSubmit={handleSubmit} className="mt-8 space-y-4 rounded-2xl border border-line bg-panel p-6">
                    <div>
                        <label className="text-xs text-muted">Nama Penyelenggara / Brand</label>
                        <input
                            required
                            value={form.businessName}
                            onChange={(e) => setForm({ ...form, businessName: e.target.value })}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-4 py-3 text-sm outline-none focus:border-flare/60"
                        />
                    </div>
                    <div>
                        <label className="text-xs text-muted">Nomor HP</label>
                        <input
                            value={form.phone}
                            onChange={(e) => setForm({ ...form, phone: e.target.value })}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-4 py-3 text-sm outline-none focus:border-flare/60"
                        />
                    </div>
                    <div>
                        <label className="text-xs text-muted">Ceritakan Sedikit Tentang Event yang Ingin Diselenggarakan</label>
                        <textarea
                            rows={4}
                            value={form.description}
                            onChange={(e) => setForm({ ...form, description: e.target.value })}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-4 py-3 text-sm outline-none focus:border-flare/60"
                        />
                    </div>

                    {error && <p className="text-xs text-flare2">{error}</p>}

                    <button
                        type="submit"
                        disabled={submitting}
                        className="w-full rounded-full bg-flare py-3 text-sm font-semibold shadow-glow transition hover:bg-flare2 disabled:opacity-50"
                    >
                        {submitting ? 'Mengirim...' : 'Kirim Pengajuan'}
                    </button>
                </form>
            )}
        </div>
    );
}
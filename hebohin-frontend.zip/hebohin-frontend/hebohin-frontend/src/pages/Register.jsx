import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { registerUser, googleLoginUrl } from '../api/client';

export default function Register() {
    const [form, setForm] = useState({ name: '', email: '', password: '' });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    async function handleSubmit(e) {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            await registerUser(form);
            navigate('/verify-otp', { state: { email: form.email } });
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal mendaftar');
        } finally {
            setLoading(false);
        }
    }

    return (
        <div className="mx-auto flex min-h-[80vh] max-w-md items-center px-6">
            <div className="w-full rounded-3xl border border-line bg-panel p-8 shadow-glow">
                <h1 className="font-display text-2xl font-bold">Buat Akun HebohIn</h1>
                <p className="mt-1 text-sm text-muted">Mulai kumpulkan momen konsermu.</p>

                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                    <div>
                        <label className="text-xs text-muted">Nama Lengkap</label>
                        <input
                            type="text"
                            required
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-4 py-3 text-sm outline-none focus:border-flare/60"
                        />
                    </div>
                    <div>
                        <label className="text-xs text-muted">Email</label>
                        <input
                            type="email"
                            required
                            value={form.email}
                            onChange={(e) => setForm({ ...form, email: e.target.value })}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-4 py-3 text-sm outline-none focus:border-flare/60"
                        />
                    </div>
                    <div>
                        <label className="text-xs text-muted">Password</label>
                        <input
                            type="password"
                            required
                            minLength={6}
                            value={form.password}
                            onChange={(e) => setForm({ ...form, password: e.target.value })}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-4 py-3 text-sm outline-none focus:border-flare/60"
                        />
                    </div>

                    {error && <p className="text-xs text-flare2">{error}</p>}

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full rounded-full bg-flare py-3 text-sm font-semibold shadow-glow transition hover:bg-flare2 disabled:opacity-50"
                    >
                        {loading ? 'Memproses...' : 'Daftar'}
                    </button>
                </form>

                <div className="my-5 flex items-center gap-3 text-xs text-muted">
                    <div className="h-px flex-1 bg-line" />
                    atau
                    <div className="h-px flex-1 bg-line" />
                </div>

                <a
                    href={googleLoginUrl}
                    className="flex w-full items-center justify-center gap-2 rounded-full border border-line bg-panel2 py-3 text-sm font-semibold transition hover:border-white/30"
                >
                    Lanjutkan dengan Google
                </a>

                <p className="mt-6 text-center text-xs text-muted">
                    Sudah punya akun?{' '}
                    <Link to="/login" className="font-semibold text-pulse hover:underline">
                        Masuk di sini
                    </Link>
                </p>
            </div>
        </div>
    );
}

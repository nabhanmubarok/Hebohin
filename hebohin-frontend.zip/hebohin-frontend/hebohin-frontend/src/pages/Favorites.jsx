import { useEffect, useState } from 'react';
import { getEvents } from '../api/client';
import EventCard from '../components/EventCard';

import { useAuth } from '../context/AuthContext';

function getStorageKey(userId) {
    return userId ? `hebohin_favorites_${userId}` : null;
}

export function useFavorites() {
    const { user } = useAuth();
    const storageKey = getStorageKey(user?.id);

    const [favoriteIds, setFavoriteIds] = useState([]);

    useEffect(() => {
        if (!storageKey) {
            setFavoriteIds([]);
            return;
        }
        try {
            setFavoriteIds(JSON.parse(localStorage.getItem(storageKey)) || []);
        } catch {
            setFavoriteIds([]);
        }
    }, [storageKey]);

    function toggleFavorite(eventId) {
        if (!storageKey) return; // belum login, tidak bisa simpan favorit
        setFavoriteIds(prev => {
            const next = prev.includes(eventId)
                ? prev.filter(id => id !== eventId)
                : [...prev, eventId];
            localStorage.setItem(storageKey, JSON.stringify(next));
            return next;
        });
    }

    return { favoriteIds, toggleFavorite };
}

export default function Favorites() {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const { favoriteIds } = useFavorites();

    useEffect(() => {
        getEvents()
            .then(res => setEvents(res.data))
            .catch(console.error)
            .finally(() => setLoading(false));
    }, []);

    const favoriteEvents = events.filter(e => favoriteIds.includes(e.id));

    return (
        <div className="mx-auto max-w-6xl px-6 py-10">
            <h1 className="font-display text-3xl font-bold">Event Favorit</h1>
            <p className="mt-2 text-sm text-muted">
                Event yang kamu tandai akan muncul di sini.
            </p>

            <div className="mt-8">
                {loading ? (
                    <p className="text-sm text-muted">Memuat...</p>
                ) : favoriteEvents.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">
                        Belum ada event favorit. Tandai event dari halaman Jelajahi.
                    </div>
                ) : (
                    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                        {favoriteEvents.map(event => (
                            <EventCard key={event.id} event={event} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

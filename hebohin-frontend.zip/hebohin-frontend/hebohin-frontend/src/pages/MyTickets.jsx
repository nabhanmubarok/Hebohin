import { useEffect, useState } from 'react';
import { getMyOrders, syncOrder } from '../api/client';

const statusStyle = {
    paid: 'bg-pulse/15 text-pulse',
    pending: 'bg-yellow-500/15 text-yellow-400',
    cancelled: 'bg-red-500/15 text-red-400',
    expired: 'bg-red-500/15 text-red-400'
};

const statusLabel = {
    paid: 'Lunas',
    pending: 'Menunggu Pembayaran',
    cancelled: 'Dibatalkan',
    expired: 'Kadaluarsa'
};

export default function MyTickets() {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function load() {
            try {
                let res = await getMyOrders();
                const pending = res.data.filter(o => o.status === 'pending');

                // Tanya Midtrans untuk tiap order yang masih pending, lalu muat ulang kalau ada yang berubah
                if (pending.length > 0) {
                    const results = await Promise.allSettled(pending.map(o => syncOrder(o.order_id)));
                    const changed = results.some(r => r.status === 'fulfilled' && r.value.data.status !== 'pending');
                    if (changed) res = await getMyOrders();
                }
                setOrders(res.data);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        }
        load();
    }, []);

    return (
        <div className="mx-auto max-w-4xl px-6 py-10">
            <h1 className="font-display text-3xl font-bold">Tiket Saya</h1>
            <p className="mt-2 text-sm text-muted">Semua tiket dan riwayat pesananmu ada di sini.</p>

            <div className="mt-8 space-y-5">
                {loading ? (
                    <p className="text-sm text-muted">Memuat...</p>
                ) : orders.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">
                        Kamu belum punya tiket. Yuk jelajahi event yang tersedia.
                    </div>
                ) : (
                    orders.map(order => (
                        <div key={order.id} className="ticket-notch overflow-hidden rounded-2xl border border-line bg-panel">
                            <div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <span className={`inline-block rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${statusStyle[order.status] || 'bg-white/10 text-muted'}`}>
                                        {statusLabel[order.status] || order.status}
                                    </span>
                                    <h3 className="mt-2 font-display text-lg font-semibold">
                                        {order.events?.name || 'Event'}
                                    </h3>
                                    <p className="text-xs text-muted">
                                        {order.events?.venue}
                                        {order.events?.event_date && (
                                            <> · {new Date(order.events.event_date).toLocaleDateString('id-ID', {
                                                day: 'numeric', month: 'short', year: 'numeric'
                                            })}</>
                                        )}
                                    </p>
                                    <p className="mt-1 text-xs text-muted">Order ID: {order.order_id}</p>
                                </div>
                                <div className="text-left sm:text-right">
                                    <p className="text-xs text-muted">Total Bayar</p>
                                    <p className="font-display text-lg font-semibold text-pulse">
                                        Rp{order.total_amount?.toLocaleString('id-ID')}
                                    </p>
                                </div>
                            </div>

                            {order.status === 'paid' && order.tickets?.length > 0 && (
                                <div className="border-t border-dashed border-line bg-panel2/50 p-5">
                                    <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted">
                                        {order.tickets.length} E-Tiket
                                    </p>
                                    <div className="grid gap-3 sm:grid-cols-2">
                                        {order.tickets.map(ticket => (
                                            <div key={ticket.id} className="flex items-center gap-3 rounded-xl border border-line bg-ink p-3">
                                                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-white text-[8px] font-mono text-ink">
                                                    QR
                                                </div>
                                                <div className="min-w-0">
                                                    <p className="truncate text-xs font-semibold">{ticket.category}</p>
                                                    <p className="truncate text-[11px] text-muted">{ticket.ticket_code}</p>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}
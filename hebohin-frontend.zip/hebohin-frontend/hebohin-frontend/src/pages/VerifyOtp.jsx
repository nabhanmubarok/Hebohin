import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { verifyOtp, sendOtp } from '../api/client';

export default function VerifyOtp() {
    const location = useLocation();
    const navigate = useNavigate();
    const [email, setEmail] = useState(location.state?.email || '');
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    const [loading, setLoading] = useState(false);

    async function handleSubmit(e) {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            await verifyOtp({ email, otp });
            navigate('/login');
        } catch (err) {
            setError(err.response?.data?.message || 'Kode OTP salah');
        } finally {
            setLoading(false);
        }
    }

    async function handleResend() {
        setMessage('');
        setError('');
        try {
            await sendOtp(email);
            setMessage('Kode OTP baru sudah dikirim ke email kamu.');
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal mengirim OTP');
        }
    }

    return (
        <div className="mx-auto flex min-h-[80vh] max-w-md items-center px-6">
            <div className="w-full rounded-3xl border border-line bg-panel p-8 shadow-glow">
                <h1 className="font-display text-2xl font-bold">Verifikasi Email</h1>
                <p className="mt-1 text-sm text-muted">
                    Masukkan kode 6 digit yang dikirim ke email kamu.
                </p>

                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                    <div>
                        <label className="text-xs text-muted">Email</label>
                        <input
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-4 py-3 text-sm outline-none focus:border-flare/60"
                        />
                    </div>
                    <div>
                        <label className="text-xs text-muted">Kode OTP</label>
                        <input
                            type="text"
                            required
                            maxLength={6}
                            value={otp}
                            onChange={(e) => setOtp(e.target.value)}
                            placeholder="123456"
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-4 py-3 text-center text-lg tracking-[0.5em] outline-none focus:border-flare/60"
                        />
                    </div>

                    {error && <p className="text-xs text-flare2">{error}</p>}
                    {message && <p className="text-xs text-pulse">{message}</p>}

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full rounded-full bg-flare py-3 text-sm font-semibold shadow-glow transition hover:bg-flare2 disabled:opacity-50"
                    >
                        {loading ? 'Memverifikasi...' : 'Verifikasi'}
                    </button>
                </form>

                <button
                    onClick={handleResend}
                    className="mt-4 w-full text-center text-xs font-semibold text-pulse hover:underline"
                >
                    Kirim ulang kode OTP
                </button>
            </div>
        </div>
    );
}

import { useEffect, useState } from 'react';
import { getAllOrders } from '../../api/client';

const statusStyle = {
    paid: 'bg-pulse/15 text-pulse',
    pending: 'bg-yellow-500/15 text-yellow-400',
    cancelled: 'bg-red-500/15 text-red-400',
    expired: 'bg-red-500/15 text-red-400'
};

export default function AdminOrders() {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('all');

    useEffect(() => {
        getAllOrders().then(res => setOrders(res.data)).catch(console.error).finally(() => setLoading(false));
    }, []);

    const filtered = filter === 'all' ? orders : orders.filter(o => o.status === filter);

    return (
        <div>
            <h1 className="font-display text-2xl font-bold">Semua Pesanan</h1>
            <p className="mt-1 text-sm text-muted">Pantau seluruh transaksi tiket dari semua customer.</p>

            <div className="mt-4 flex gap-2">
                {['all', 'paid', 'pending', 'cancelled', 'expired'].map(s => (
                    <button
                        key={s}
                        onClick={() => setFilter(s)}
                        className={`rounded-full px-4 py-1.5 text-xs font-semibold transition ${
                            filter === s ? 'bg-flare text-white' : 'border border-line text-muted hover:text-white'
                        }`}
                    >
                        {s === 'all' ? 'Semua' : s}
                    </button>
                ))}
            </div>

            <div className="mt-6 overflow-hidden rounded-2xl border border-line bg-panel">
                <table className="w-full text-left text-sm">
                    <thead className="border-b border-line text-xs uppercase text-muted">
                        <tr>
                            <th className="px-4 py-3">Order ID</th>
                            <th className="px-4 py-3">Customer</th>
                            <th className="px-4 py-3">Event</th>
                            <th className="px-4 py-3">Total</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3">Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={6} className="px-4 py-6 text-center text-muted">Memuat...</td></tr>
                        ) : filtered.length === 0 ? (
                            <tr><td colSpan={6} className="px-4 py-6 text-center text-muted">Tidak ada pesanan.</td></tr>
                        ) : filtered.map(order => (
                            <tr key={order.id} className="border-b border-line last:border-0">
                                <td className="px-4 py-3 font-mono text-xs text-muted">{order.order_id}</td>
                                <td className="px-4 py-3">
                                    <p className="font-medium">{order.users?.name}</p>
                                    <p className="text-xs text-muted">{order.users?.email}</p>
                                </td>
                                <td className="px-4 py-3 text-muted">{order.events?.name}</td>
                                <td className="px-4 py-3 font-semibold text-pulse">
                                    Rp{order.total_amount?.toLocaleString('id-ID')}
                                </td>
                                <td className="px-4 py-3">
                                    <span className={`rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${statusStyle[order.status] || 'bg-white/10 text-muted'}`}>
                                        {order.status}
                                    </span>
                                </td>
                                <td className="px-4 py-3 text-xs text-muted">
                                    {new Date(order.created_at).toLocaleDateString('id-ID')}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

import { useEffect, useState } from 'react';
import { getVouchers, createVoucher, updateVoucher, deleteVoucher } from '../../api/client';

const emptyForm = {
    code: '', discountType: 'percentage', discountValue: 10,
    maxDiscount: '', minPurchase: 0, quota: 50, validUntil: ''
};

export default function AdminVouchers() {
    const [vouchers, setVouchers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [form, setForm] = useState(emptyForm);
    const [error, setError] = useState('');

    function load() {
        setLoading(true);
        getVouchers().then(res => setVouchers(res.data)).catch(console.error).finally(() => setLoading(false));
    }

    useEffect(() => { load(); }, []);

    function openCreate() {
        setForm(emptyForm);
        setEditingId(null);
        setShowForm(true);
    }

    function openEdit(v) {
        setForm({
            code: v.code, discountType: v.discount_type, discountValue: v.discount_value,
            maxDiscount: v.max_discount || '', minPurchase: v.min_purchase,
            quota: v.quota, validUntil: v.valid_until?.slice(0, 16) || ''
        });
        setEditingId(v.id);
        setShowForm(true);
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setError('');
        try {
            const payload = {
                ...form,
                discountValue: Number(form.discountValue),
                maxDiscount: form.maxDiscount ? Number(form.maxDiscount) : null,
                minPurchase: Number(form.minPurchase),
                quota: Number(form.quota),
                isActive: true
            };
            if (editingId) {
                await updateVoucher(editingId, payload);
            } else {
                await createVoucher(payload);
            }
            setShowForm(false);
            load();
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal menyimpan voucher');
        }
    }

    async function handleDelete(id) {
        if (!confirm('Hapus voucher ini?')) return;
        await deleteVoucher(id);
        load();
    }

    async function handleToggleActive(v) {
        await updateVoucher(v.id, {
            discountType: v.discount_type,
            discountValue: v.discount_value,
            maxDiscount: v.max_discount,
            minPurchase: v.min_purchase,
            quota: v.quota,
            isActive: !v.is_active,
            validFrom: v.valid_from,
            validUntil: v.valid_until
        });
        load();
    }

    return (
        <div>
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="font-display text-2xl font-bold">Kelola Voucher</h1>
                    <p className="mt-1 text-sm text-muted">Buat kode promo untuk mendorong penjualan tiket.</p>
                </div>
                <button onClick={openCreate} className="rounded-full bg-flare px-5 py-2.5 text-sm font-semibold shadow-glow hover:bg-flare2">
                    + Buat Voucher
                </button>
            </div>

            {showForm && (
                <form onSubmit={handleSubmit} className="mt-6 space-y-4 rounded-2xl border border-line bg-panel p-6">
                    <h2 className="font-display text-lg font-semibold">
                        {editingId ? 'Ubah Voucher' : 'Voucher Baru'}
                    </h2>
                    <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                            <label className="text-xs text-muted">Kode Voucher</label>
                            <input required disabled={!!editingId} value={form.code}
                                onChange={e => setForm({ ...form, code: e.target.value.toUpperCase() })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60 disabled:opacity-50" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Tipe Diskon</label>
                            <select value={form.discountType} onChange={e => setForm({ ...form, discountType: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60">
                                <option value="percentage">Persentase (%)</option>
                                <option value="fixed">Nominal Tetap (Rp)</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-muted">
                                Nilai Diskon {form.discountType === 'percentage' ? '(1-100)' : '(Rp)'}
                            </label>
                            <input required type="number" value={form.discountValue}
                                onChange={e => setForm({ ...form, discountValue: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        {form.discountType === 'percentage' && (
                            <div>
                                <label className="text-xs text-muted">Maks. Potongan (Rp, opsional)</label>
                                <input type="number" value={form.maxDiscount}
                                    onChange={e => setForm({ ...form, maxDiscount: e.target.value })}
                                    className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                            </div>
                        )}
                        <div>
                            <label className="text-xs text-muted">Minimal Belanja (Rp)</label>
                            <input type="number" value={form.minPurchase}
                                onChange={e => setForm({ ...form, minPurchase: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Kuota Pemakaian</label>
                            <input type="number" value={form.quota}
                                onChange={e => setForm({ ...form, quota: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Berlaku Sampai (opsional)</label>
                            <input type="datetime-local" value={form.validUntil}
                                onChange={e => setForm({ ...form, validUntil: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                    </div>

                    {error && <p className="text-xs text-flare2">{error}</p>}

                    <div className="flex gap-3">
                        <button type="submit" className="rounded-full bg-flare px-6 py-2.5 text-sm font-semibold shadow-glow hover:bg-flare2">
                            Simpan
                        </button>
                        <button type="button" onClick={() => setShowForm(false)}
                            className="rounded-full border border-line px-6 py-2.5 text-sm font-semibold text-muted hover:text-white">
                            Batal
                        </button>
                    </div>
                </form>
            )}

            <div className="mt-6 overflow-hidden rounded-2xl border border-line bg-panel">
                <table className="w-full text-left text-sm">
                    <thead className="border-b border-line text-xs uppercase text-muted">
                        <tr>
                            <th className="px-4 py-3">Kode</th>
                            <th className="px-4 py-3">Diskon</th>
                            <th className="px-4 py-3">Pemakaian</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={5} className="px-4 py-6 text-center text-muted">Memuat...</td></tr>
                        ) : vouchers.length === 0 ? (
                            <tr><td colSpan={5} className="px-4 py-6 text-center text-muted">Belum ada voucher.</td></tr>
                        ) : vouchers.map(v => (
                            <tr key={v.id} className="border-b border-line last:border-0">
                                <td className="px-4 py-3 font-mono font-semibold text-pulse">{v.code}</td>
                                <td className="px-4 py-3 text-muted">
                                    {v.discount_type === 'percentage' ? `${v.discount_value}%` : `Rp${v.discount_value.toLocaleString('id-ID')}`}
                                </td>
                                <td className="px-4 py-3 text-muted">{v.used_count} / {v.quota}</td>
                                <td className="px-4 py-3">
                                    <button onClick={() => handleToggleActive(v)}
                                        className={`rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${
                                            v.is_active ? 'bg-pulse/15 text-pulse' : 'bg-white/10 text-muted'
                                        }`}>
                                        {v.is_active ? 'Aktif' : 'Nonaktif'}
                                    </button>
                                </td>
                                <td className="px-4 py-3 text-right">
                                    <button onClick={() => openEdit(v)} className="mr-3 text-xs font-semibold text-pulse hover:underline">
                                        Ubah
                                    </button>
                                    <button onClick={() => handleDelete(v.id)} className="text-xs font-semibold text-flare2 hover:underline">
                                        Hapus
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

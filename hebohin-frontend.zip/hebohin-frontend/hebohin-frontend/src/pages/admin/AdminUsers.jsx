import { useEffect, useState } from 'react';
import { getUsers, updateUserRole, deleteUser } from '../../api/client';
import { useAuth } from '../../context/AuthContext';

const roleStyle = {
    super_admin: 'bg-flare/15 text-flare2',
    admin: 'bg-pulse/15 text-pulse',
    customer: 'bg-white/10 text-muted'
};

const roleLabel = {
    super_admin: 'Super Admin',
    admin: 'Admin',
    customer: 'Customer'
};

export default function AdminUsers() {
    const { user: currentUser } = useAuth();
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    function load() {
        setLoading(true);
        getUsers().then(res => setUsers(res.data)).catch(console.error).finally(() => setLoading(false));
    }

    useEffect(() => { load(); }, []);

    async function handleRoleChange(id, role) {
        setError('');
        try {
            await updateUserRole(id, role);
            load();
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal mengubah role');
        }
    }

    async function handleDelete(id) {
        if (!confirm('Hapus user ini secara permanen?')) return;
        try {
            await deleteUser(id);
            load();
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal menghapus user');
        }
    }

    return (
        <div>
            <h1 className="font-display text-2xl font-bold">Kelola Admin & User</h1>
            <p className="mt-1 text-sm text-muted">
                Naikkan customer menjadi admin, atau kelola akses admin yang sudah ada.
            </p>

            {error && <p className="mt-3 text-xs text-flare2">{error}</p>}

            <div className="mt-6 overflow-hidden rounded-2xl border border-line bg-panel">
                <table className="w-full text-left text-sm">
                    <thead className="border-b border-line text-xs uppercase text-muted">
                        <tr>
                            <th className="px-4 py-3">Nama</th>
                            <th className="px-4 py-3">Email</th>
                            <th className="px-4 py-3">Role</th>
                            <th className="px-4 py-3 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={4} className="px-4 py-6 text-center text-muted">Memuat...</td></tr>
                        ) : users.map(u => (
                            <tr key={u.id} className="border-b border-line last:border-0">
                                <td className="px-4 py-3 font-medium">
                                    {u.name} {u.id === currentUser.id && <span className="text-xs text-muted">(kamu)</span>}
                                </td>
                                <td className="px-4 py-3 text-muted">{u.email}</td>
                                <td className="px-4 py-3">
                                    <span className={`rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${roleStyle[u.role]}`}>
                                        {roleLabel[u.role]}
                                    </span>
                                </td>
                                <td className="px-4 py-3 text-right">
                                    {u.id === currentUser.id ? (
                                        <span className="text-xs text-muted">—</span>
                                    ) : (
                                        <div className="flex items-center justify-end gap-2">
                                            <select
                                                value={u.role}
                                                onChange={(e) => handleRoleChange(u.id, e.target.value)}
                                                className="rounded-lg border border-line bg-panel2 px-2 py-1.5 text-xs outline-none focus:border-flare/60"
                                            >
                                                <option value="customer">Customer</option>
                                                <option value="admin">Admin</option>
                                                <option value="super_admin">Super Admin</option>
                                            </select>
                                            <button
                                                onClick={() => handleDelete(u.id)}
                                                className="text-xs font-semibold text-flare2 hover:underline"
                                            >
                                                Hapus
                                            </button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

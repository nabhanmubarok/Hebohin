import { useEffect, useState } from 'react';
import { getEvents, createEvent, updateEvent, deleteEvent, uploadEventPoster } from '../../api/client';

const emptyForm = {
    name: '', artist: '', venue: '', city: '', eventDate: '',
    description: '', genre: '', posterUrl: '',
    ticketTypes: [{ category: 'Regular', price: 0, stock: 0 }]
};

export default function AdminEvents() {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [form, setForm] = useState(emptyForm);
    const [error, setError] = useState('');

    const [uploading, setUploading] = useState(false);

async function handleImageChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
        const res = await uploadEventPoster(file);
        setForm(prev => ({ ...prev, posterUrl: res.data.url }));
    } catch (err) {
        setError('Gagal upload gambar: ' + (err.response?.data?.message || err.message));
    } finally {
        setUploading(false);
    }
}

    function load() {
        setLoading(true);
        getEvents().then(res => setEvents(res.data)).catch(console.error).finally(() => setLoading(false));
    }

    useEffect(() => { load(); }, []);

    function openCreate() {
        setForm(emptyForm);
        setEditingId(null);
        setShowForm(true);
    }

    function openEdit(event) {
    setForm({
        name: event.name, artist: event.artist || '', venue: event.venue,
        city: event.city || '', eventDate: event.event_date?.slice(0, 16) || '',
        description: event.description || '', genre: event.genre || '',
        posterUrl: event.poster_url || '',
        ticketTypes: event.ticket_types?.length ? event.ticket_types : emptyForm.ticketTypes
    });
    setEditingId(event.id);
    setShowForm(true);
}

    function updateTicketType(index, field, value) {
        setForm(prev => {
            const next = [...prev.ticketTypes];
            next[index] = { ...next[index], [field]: field === 'category' ? value : Number(value) };
            return { ...prev, ticketTypes: next };
        });
    }

    function addTicketType() {
        setForm(prev => ({
            ...prev,
            ticketTypes: [...prev.ticketTypes, { category: '', price: 0, stock: 0 }]
        }));
    }

    function removeTicketType(index) {
        setForm(prev => ({
            ...prev,
            ticketTypes: prev.ticketTypes.filter((_, i) => i !== index)
        }));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setError('');
        try {
            if (editingId) {
                await updateEvent(editingId, form);
            } else {
                await createEvent(form);
            }
            setShowForm(false);
            load();
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal menyimpan event');
        }
    }

    async function handleDelete(id) {
        if (!confirm('Hapus event ini? Tindakan tidak bisa dibatalkan.')) return;
        await deleteEvent(id);
        load();
    }

    return (
        <div>
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="font-display text-2xl font-bold">Kelola Event</h1>
                    <p className="mt-1 text-sm text-muted">Tambah, ubah, atau hapus konser yang tersedia.</p>
                </div>
                <button
                    onClick={openCreate}
                    className="rounded-full bg-flare px-5 py-2.5 text-sm font-semibold shadow-glow transition hover:bg-flare2"
                >
                    + Tambah Event
                </button>
            </div>

            {showForm && (
                <form onSubmit={handleSubmit} className="mt-6 space-y-4 rounded-2xl border border-line bg-panel p-6">
                    <h2 className="font-display text-lg font-semibold">
                        {editingId ? 'Ubah Event' : 'Event Baru'}
                    </h2>

                    <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                            <label className="text-xs text-muted">Nama Event</label>
                            <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Artis</label>
                            <input value={form.artist} onChange={e => setForm({ ...form, artist: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Venue</label>
                            <input required value={form.venue} onChange={e => setForm({ ...form, venue: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Kota</label>
                            <input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Tanggal & Waktu</label>
                            <input required type="datetime-local" value={form.eventDate}
                                onChange={e => setForm({ ...form, eventDate: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
    <label className="text-xs text-muted">Genre</label>
    <select value={form.genre} onChange={e => setForm({ ...form, genre: e.target.value })}
        className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60">
        <option value="">Pilih genre</option>
        <option value="Pop">Pop</option>
        <option value="Rock">Rock</option>
        <option value="Indie">Indie</option>
        <option value="Jazz">Jazz</option>
        <option value="EDM">EDM</option>
        <option value="Hip Hop">Hip Hop</option>
        <option value="RnB">R&B</option>
        <option value="Metal">Metal</option>
        <option value="Klasik">Klasik</option>
        <option value="Dangdut">Dangdut</option>
        <option value="Folk/Akustik">Folk/Akustik</option>
        <option value="Lainnya">Lainnya</option>
    </select>
</div>
                    </div>

                    <div>
                        <label className="text-xs text-muted">Deskripsi</label>
                        <textarea rows={3} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                    </div>

                    <div>
    <label className="text-xs text-muted">Gambar Poster Event</label>
    <input
        type="file"
        accept="image/*"
        onChange={handleImageChange}
        className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none file:mr-3 file:rounded-lg file:border-0 file:bg-flare file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white"
    />
    {uploading && <p className="mt-1 text-xs text-pulse">Mengupload...</p>}
    {form.posterUrl && (
        <img src={form.posterUrl} alt="Preview" className="mt-3 h-40 w-full rounded-xl object-cover" />
    )}
</div>

                    <div>
                        <div className="flex items-center justify-between">
                            <label className="text-xs text-muted">Kategori Tiket</label>
                            <button type="button" onClick={addTicketType} className="text-xs font-semibold text-pulse hover:underline">
                                + Tambah Kategori
                            </button>
                        </div>
                        <div className="mt-2 space-y-2">
                            {form.ticketTypes.map((tt, i) => (
                                <div key={i} className="grid grid-cols-[1.5fr_1fr_1fr_auto] gap-2">
                                    <input placeholder="Kategori (VIP/Regular)" value={tt.category}
                                        onChange={e => updateTicketType(i, 'category', e.target.value)}
                                        className="rounded-lg border border-line bg-panel2 px-3 py-2 text-xs outline-none focus:border-flare/60" />
                                    <input type="number" placeholder="Harga" value={tt.price}
                                        onChange={e => updateTicketType(i, 'price', e.target.value)}
                                        className="rounded-lg border border-line bg-panel2 px-3 py-2 text-xs outline-none focus:border-flare/60" />
                                    <input type="number" placeholder="Stok" value={tt.stock}
                                        onChange={e => updateTicketType(i, 'stock', e.target.value)}
                                        className="rounded-lg border border-line bg-panel2 px-3 py-2 text-xs outline-none focus:border-flare/60" />
                                    <button type="button" onClick={() => removeTicketType(i)}
                                        className="rounded-lg border border-line px-2 text-xs text-flare2 hover:border-flare/60">
                                        Hapus
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>

                    {error && <p className="text-xs text-flare2">{error}</p>}

                    <div className="flex gap-3">
                        <button type="submit" className="rounded-full bg-flare px-6 py-2.5 text-sm font-semibold shadow-glow hover:bg-flare2">
                            Simpan
                        </button>
                        <button type="button" onClick={() => setShowForm(false)}
                            className="rounded-full border border-line px-6 py-2.5 text-sm font-semibold text-muted hover:text-white">
                            Batal
                        </button>
                    </div>
                </form>
            )}

            <div className="mt-6 overflow-hidden rounded-2xl border border-line bg-panel">
                <table className="w-full text-left text-sm">
                    <thead className="border-b border-line text-xs uppercase text-muted">
                        <tr>
                            <th className="px-4 py-3">Nama</th>
                            <th className="px-4 py-3">Venue</th>
                            <th className="px-4 py-3">Tanggal</th>
                            <th className="px-4 py-3">Kategori</th>
                            <th className="px-4 py-3 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={5} className="px-4 py-6 text-center text-muted">Memuat...</td></tr>
                        ) : events.length === 0 ? (
                            <tr><td colSpan={5} className="px-4 py-6 text-center text-muted">Belum ada event.</td></tr>
                        ) : events.map(event => (
                            <tr key={event.id} className="border-b border-line last:border-0">
                                <td className="px-4 py-3 font-medium">{event.name}</td>
                                <td className="px-4 py-3 text-muted">{event.venue}</td>
                                <td className="px-4 py-3 text-muted">
                                    {new Date(event.event_date).toLocaleDateString('id-ID')}
                                </td>
                                <td className="px-4 py-3 text-muted">
                                    {event.ticket_types?.map(t => t.category).join(', ')}
                                </td>
                                <td className="px-4 py-3 text-right">
                                    <button onClick={() => openEdit(event)} className="mr-3 text-xs font-semibold text-pulse hover:underline">
                                        Ubah
                                    </button>
                                    <button onClick={() => handleDelete(event.id)} className="text-xs font-semibold text-flare2 hover:underline">
                                        Hapus
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

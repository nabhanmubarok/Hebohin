import { useEffect, useState } from 'react';
import { getApplications, approveApplication, rejectApplication } from '../../api/client';

const statusStyle = {
    pending: 'bg-yellow-500/15 text-yellow-400',
    approved: 'bg-pulse/15 text-pulse',
    rejected: 'bg-red-500/15 text-red-400'
};

export default function AdminOrganizerApplications() {
    const [applications, setApplications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [processingId, setProcessingId] = useState(null);

    function load() {
        setLoading(true);
        getApplications()
            .then(res => setApplications(res.data))
            .catch(console.error)
            .finally(() => setLoading(false));
    }

    useEffect(() => { load(); }, []);

    async function handleApprove(id) {
        setError('');
        setProcessingId(id);
        try {
            await approveApplication(id);
            load();
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal menyetujui pengajuan');
        } finally {
            setProcessingId(null);
        }
    }

    async function handleReject(id) {
        setError('');
        setProcessingId(id);
        try {
            await rejectApplication(id);
            load();
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal menolak pengajuan');
        } finally {
            setProcessingId(null);
        }
    }

    const pending = applications.filter(a => a.status === 'pending');
    const reviewed = applications.filter(a => a.status !== 'pending');

    return (
        <div>
            <h1 className="font-display text-2xl font-bold">Pengajuan Event Organizer</h1>
            <p className="mt-1 text-sm text-muted">Tinjau dan setujui customer yang ingin jadi penyelenggara event.</p>

            {error && <p className="mt-3 text-xs text-flare2">{error}</p>}

            <div className="mt-6">
                <h2 className="mb-3 text-sm font-semibold text-muted">
                    Menunggu Persetujuan ({pending.length})
                </h2>
                {loading ? (
                    <p className="text-sm text-muted">Memuat...</p>
                ) : pending.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-line p-6 text-center text-sm text-muted">
                        Tidak ada pengajuan baru.
                    </div>
                ) : (
                    <div className="space-y-3">
                        {pending.map(app => (
                            <div key={app.id} className="rounded-2xl border border-line bg-panel p-5">
                                <div className="flex flex-wrap items-start justify-between gap-4">
                                    <div>
                                        <span className={`inline-block rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${statusStyle[app.status]}`}>
                                            Pending
                                        </span>
                                        <h3 className="mt-2 font-display text-lg font-semibold">{app.business_name}</h3>
                                        <p className="text-xs text-muted">{app.users?.name} · {app.users?.email}</p>
                                        {app.phone && <p className="mt-1 text-xs text-muted">HP: {app.phone}</p>}
                                        {app.description && (
                                            <p className="mt-2 max-w-xl text-sm text-muted">{app.description}</p>
                                        )}
                                    </div>
                                    <div className="flex gap-2">
                                        <button
                                            onClick={() => handleApprove(app.id)}
                                            disabled={processingId === app.id}
                                            className="rounded-full bg-pulse px-4 py-2 text-xs font-semibold text-ink shadow-glowTeal transition hover:opacity-90 disabled:opacity-50"
                                        >
                                            Setujui
                                        </button>
                                        <button
                                            onClick={() => handleReject(app.id)}
                                            disabled={processingId === app.id}
                                            className="rounded-full border border-line px-4 py-2 text-xs font-semibold text-flare2 hover:border-flare/60 disabled:opacity-50"
                                        >
                                            Tolak
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            <div className="mt-10">
                <h2 className="mb-3 text-sm font-semibold text-muted">Riwayat Pengajuan</h2>
                <div className="overflow-hidden rounded-2xl border border-line bg-panel">
                    <table className="w-full text-left text-sm">
                        <thead className="border-b border-line text-xs uppercase text-muted">
                            <tr>
                                <th className="px-4 py-3">Nama Bisnis</th>
                                <th className="px-4 py-3">Customer</th>
                                <th className="px-4 py-3">Status</th>
                                <th className="px-4 py-3">Ditinjau</th>
                            </tr>
                        </thead>
                        <tbody>
                            {reviewed.length === 0 ? (
                                <tr><td colSpan={4} className="px-4 py-6 text-center text-muted">Belum ada riwayat.</td></tr>
                            ) : reviewed.map(app => (
                                <tr key={app.id} className="border-b border-line last:border-0">
                                    <td className="px-4 py-3 font-medium">{app.business_name}</td>
                                    <td className="px-4 py-3 text-muted">{app.users?.email}</td>
                                    <td className="px-4 py-3">
                                        <span className={`rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${statusStyle[app.status]}`}>
                                            {app.status}
                                        </span>
                                    </td>
                                    <td className="px-4 py-3 text-xs text-muted">
                                        {app.reviewed_at ? new Date(app.reviewed_at).toLocaleDateString('id-ID') : '-'}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
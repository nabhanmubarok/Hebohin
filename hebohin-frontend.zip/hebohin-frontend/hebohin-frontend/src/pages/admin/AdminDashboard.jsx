import { useEffect, useState } from 'react';
import { getDashboardSummary } from '../../api/client';

function StatCard({ label, value, accent }) {
    return (
        <div className="rounded-2xl border border-line bg-panel p-5">
            <p className="text-xs text-muted">{label}</p>
            <p className={`mt-2 font-display text-2xl font-bold ${accent}`}>{value}</p>
        </div>
    );
}

export default function AdminDashboard() {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getDashboardSummary()
            .then(res => setStats(res.data))
            .catch(console.error)
            .finally(() => setLoading(false));
    }, []);

    if (loading) return <p className="text-sm text-muted">Memuat statistik...</p>;
    if (!stats) return <p className="text-sm text-flare2">Gagal memuat statistik.</p>;

    const maxRevenue = Math.max(...stats.revenueByDay.map(d => d.total), 1);

    return (
        <div>
            <h1 className="font-display text-2xl font-bold">Ringkasan</h1>
            <p className="mt-1 text-sm text-muted">Pantau performa penjualan tiket secara keseluruhan.</p>

            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <StatCard label="Total Pendapatan" value={`Rp${stats.totalRevenue.toLocaleString('id-ID')}`} accent="text-pulse" />
                <StatCard label="Total Pesanan Lunas" value={stats.totalOrders} accent="text-flare2" />
                <StatCard label="Tiket Terjual" value={stats.totalTicketsSold} accent="text-white" />
                <StatCard label="Total Event" value={stats.totalEvents} accent="text-white" />
            </div>

            <div className="mt-8 rounded-2xl border border-line bg-panel p-6">
                <h2 className="font-display text-lg font-semibold">Pendapatan 7 Hari Terakhir</h2>
                <div className="mt-6 flex items-end gap-3" style={{ height: 160 }}>
                    {stats.revenueByDay.map(day => (
                        <div key={day.date} className="flex flex-1 flex-col items-center gap-2">
                            <div
                                className="w-full rounded-t-lg bg-gradient-to-t from-flare to-pulse transition-all"
                                style={{ height: `${Math.max(6, (day.total / maxRevenue) * 130)}px` }}
                                title={`Rp${day.total.toLocaleString('id-ID')}`}
                            />
                            <span className="text-[10px] text-muted">
                                {new Date(day.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                            </span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

import { useEffect, useMemo, useState } from 'react';
import { getEvents } from '../api/client';
import EventCard from '../components/EventCard';

export default function Explore() {
    const [events, setEvents] = useState([]);
    const [search, setSearch] = useState('');
    const [genre, setGenre] = useState('Semua');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        getEvents()
            .then(res => setEvents(res.data))
            .catch(console.error)
            .finally(() => setLoading(false));
    }, []);

    const genres = useMemo(() => {
    const set = new Set(events.map(e => e.genre).filter(Boolean));
    return ['Semua', ...set];
}, [events]);

    const filtered = events.filter(e => {
        const matchSearch = e.name?.toLowerCase().includes(search.toLowerCase()) ||
            e.artist?.toLowerCase().includes(search.toLowerCase());
        const matchGenre = genre === 'Semua' || e.genre === genre;
        return matchSearch && matchGenre;
    });

    return (
        <div className="mx-auto max-w-6xl px-6 py-10">
            <h1 className="font-display text-3xl font-bold">Jelajahi Konser</h1>
            <p className="mt-2 text-sm text-muted">Temukan pertunjukan berikutnya yang wajib kamu datangi.</p>

            <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center">
                <input
                    type="text"
                    placeholder="Cari nama event atau artis..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full rounded-full border border-line bg-panel px-5 py-3 text-sm outline-none placeholder:text-muted focus:border-flare/60 sm:max-w-sm"
                />
                <div className="flex flex-wrap gap-2 overflow-x-auto scrollbar-none">
                    {genres.map(g => (
                        <button
                            key={g}
                            onClick={() => setGenre(g)}
                            className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-semibold transition ${
                                genre === g
                                    ? 'bg-flare text-white shadow-glow'
                                    : 'border border-line text-muted hover:text-white'
                            }`}
                        >
                            {g}
                        </button>
                    ))}
                </div>
            </div>

            <div className="mt-8">
                {loading ? (
                    <p className="text-sm text-muted">Memuat event...</p>
                ) : filtered.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">
                        Tidak ada event yang cocok dengan pencarianmu.
                    </div>
                ) : (
                    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                        {filtered.map(event => (
                            <EventCard key={event.id} event={event} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

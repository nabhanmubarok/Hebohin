/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0A12',
        panel: '#12121F',
        panel2: '#181828',
        line: 'rgba(255,255,255,0.08)',
        flare: '#FF3D7A',
        flare2: '#FF6FA0',
        pulse: '#2FE6D0',
        muted: '#9C9CB8'
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif']
      },
      boxShadow: {
        glow: '0 0 40px -10px rgba(255,61,122,0.45)',
        glowTeal: '0 0 40px -12px rgba(47,230,208,0.4)'
      },
      backgroundImage: {
        'grid-fade': 'radial-gradient(circle at 20% 0%, rgba(255,61,122,0.14), transparent 45%), radial-gradient(circle at 90% 10%, rgba(47,230,208,0.12), transparent 40%)'
      }
    }
  },
  plugins: []
};

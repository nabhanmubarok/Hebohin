import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getMyOrders, syncOrder } from '../api/client';
import TicketQR from '../components/TicketQR';

const statusStyle = {
    paid: 'bg-pulse/15 text-pulse',
    pending: 'bg-yellow-500/15 text-yellow-400',
    cancelled: 'bg-red-500/15 text-red-400',
    expired: 'bg-red-500/15 text-red-400'
};

const statusLabel = {
    paid: 'Lunas',
    pending: 'Menunggu Pembayaran',
    cancelled: 'Dibatalkan',
    expired: 'Kadaluarsa'
};

function TicketDetailModal({ order, ticket, onClose }) {
    if (!ticket) return null;
    const eventDate = order?.events?.event_date
        ? new Date(order.events.event_date).toLocaleDateString('id-ID', {
              weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
          })
        : '-';

    return (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-4 sm:items-center" role="dialog" aria-modal="true">
            <button aria-label="Tutup detail tiket" onClick={onClose} className="absolute inset-0 bg-ink/80 backdrop-blur-sm" />
            <div className="relative max-h-[90vh] w-full max-w-md overflow-y-auto rounded-3xl border border-line bg-panel shadow-glow">
                {/* Header tiket */}
                <div className="relative overflow-hidden bg-gradient-to-br from-flare via-flare2 to-pulse p-5 text-white">
                    <button onClick={onClose} className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-ink/30 text-white hover:bg-ink/50" aria-label="Tutup">
                        ✕
                    </button>
                    <p className="text-[11px] font-bold uppercase tracking-[0.25em] opacity-90">E-Tiket HebohIn</p>
                    <h3 className="mt-2 font-display text-xl font-bold leading-tight">{order?.events?.name || 'Event'}</h3>
                    <p className="mt-1 text-xs opacity-90">{order?.events?.venue || ''}{order?.events?.venue && order?.events?.event_date ? ' · ' : ''}{eventDate}</p>
                </div>

                <div className="p-5">
                    {/* QR besar buat ditunjukin ke petugas */}
                    <div className="flex flex-col items-center">
                        <TicketQR value={ticket.ticket_code} size={220} className="shadow-glow" />
                        <p className="mt-3 font-mono text-sm font-bold tracking-widest text-white">{ticket.ticket_code}</p>
                        <p className="mt-1 text-center text-[11px] text-muted">Tunjukkan QR ini ke petugas di pintu masuk. Screenshot juga bisa, tapi pastikan QR terlihat jelas.</p>
                        <span className={`mt-3 inline-block rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${ticket.is_used ? 'bg-red-500/15 text-red-400' : 'bg-pulse/15 text-pulse'}`}>
                            {ticket.is_used ? `Sudah dipakai${ticket.used_at ? ' · ' + new Date(ticket.used_at).toLocaleString('id-ID') : ''}` : 'Belum dipakai'}
                        </span>
                    </div>

                    {/* Detail info */}
                    <dl className="mt-5 space-y-2 rounded-2xl border border-line bg-panel2/60 p-4 text-sm">
                        <div className="flex justify-between gap-4"><dt className="text-muted">Kategori</dt><dd className="font-semibold text-white">{ticket.category}</dd></div>
                        {ticket.seat_label && <div className="flex justify-between gap-4"><dt className="text-muted">Nomor Kursi</dt><dd className="font-semibold text-white">{ticket.seat_label}</dd></div>}
                        <div className="flex justify-between gap-4"><dt className="text-muted">Tanggal</dt><dd className="text-right font-medium text-white">{eventDate}</dd></div>
                        <div className="flex justify-between gap-4"><dt className="text-muted">Venue</dt><dd className="text-right font-medium text-white">{order?.events?.venue || '-'}</dd></div>
                        <div className="flex justify-between gap-4"><dt className="text-muted">Order ID</dt><dd className="font-mono text-xs font-semibold text-white">{order?.order_id || '-'}</dd></div>
                        <div className="flex justify-between gap-4"><dt className="text-muted">Status Bayar</dt><dd className="font-semibold text-pulse">{statusLabel[order?.status] || order?.status || '-'}</dd></div>
                    </dl>

                    <button onClick={onClose} className="mt-5 w-full rounded-full bg-flare py-3 text-sm font-semibold text-white shadow-glow transition hover:bg-flare2">
                        Tutup
                    </button>
                </div>
            </div>
        </div>
    );
}

export default function MyTickets() {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedTicket, setSelectedTicket] = useState(null);
    const [searchParams] = useSearchParams();

    useEffect(() => {
        let cancelled = false;

        async function load() {
            try {
                let res = await getMyOrders();
                if (cancelled) return;
                setOrders(res.data);

                // Order yang masih pending: tanya status terbaru ke Midtrans lewat backend
                // (jaga-jaga kalau webhook belum/tidak sampai)
                const pending = res.data.filter(o => o.status === 'pending');
                if (pending.length > 0) {
                    await Promise.allSettled(pending.map(o => syncOrder(o.order_id)));
                    res = await getMyOrders();
                    if (!cancelled) setOrders(res.data);
                }
            } catch (err) {
                console.error(err);
            } finally {
                if (!cancelled) setLoading(false);
            }
        }

        load();
        return () => { cancelled = true; };
    }, []);

    // Habis bayar di Midtrans, user balik ke /my-tickets?order_id=ORDER-... -> auto buka detail tiket pertama order itu
    useEffect(() => {
        const orderId = searchParams.get('order_id');
        if (!orderId || orders.length === 0) return;
        const match = orders.find(o => o.order_id === orderId);
        if (match?.tickets?.length > 0) {
            setSelectedTicket({ order: match, ticket: match.tickets[0] });
        }
    }, [searchParams, orders]);

    return (
        <div className="mx-auto max-w-4xl px-6 py-10">
            <h1 className="font-display text-3xl font-bold">Tiket Saya</h1>
            <p className="mt-2 text-sm text-muted">Semua tiket dan riwayat pesananmu ada di sini. Klik “Lihat Detail” buat buka QR-nya.</p>

            <div className="mt-8 space-y-5">
                {loading ? (
                    <p className="text-sm text-muted">Memuat...</p>
                ) : orders.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">
                        Kamu belum punya tiket. Yuk jelajahi event yang tersedia.
                    </div>
                ) : (
                    orders.map(order => {
                        const isJustPaid = searchParams.get('order_id') === order.order_id;
                        return (
                        <div key={order.id} className={`ticket-notch overflow-hidden rounded-2xl border bg-panel ${isJustPaid ? 'border-pulse/60 shadow-glowTeal' : 'border-line'}`}>
                            <div className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <span className={`inline-block rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${statusStyle[order.status] || 'bg-white/10 text-muted'}`}>
                                        {statusLabel[order.status] || order.status}
                                    </span>
                                    {isJustPaid && order.status === 'paid' && (
                                        <span className="ml-2 inline-block rounded-full bg-flare px-3 py-1 text-[11px] font-semibold uppercase text-white">Baru Lunas</span>
                                    )}
                                    <h3 className="mt-2 font-display text-lg font-semibold">
                                        {order.events?.name || 'Event'}
                                    </h3>
                                    <p className="text-xs text-muted">
                                        {order.events?.venue}
                                        {order.events?.event_date && (
                                            <> · {new Date(order.events.event_date).toLocaleDateString('id-ID', {
                                                day: 'numeric', month: 'short', year: 'numeric'
                                            })}</>
                                        )}
                                    </p>
                                    <p className="mt-1 text-xs text-muted">Order ID: {order.order_id}</p>
                                </div>
                                <div className="text-left sm:text-right">
                                    <p className="text-xs text-muted">Total Bayar</p>
                                    <p className="font-display text-lg font-semibold text-pulse">
                                        Rp{order.total_amount?.toLocaleString('id-ID')}
                                    </p>
                                </div>
                            </div>

                            {order.status === 'paid' && order.tickets?.length > 0 && (
                                <div className="border-t border-dashed border-line bg-panel2/50 p-5">
                                    <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted">
                                        {order.tickets.length} E-Tiket — klik salah satu buat lihat QR
                                    </p>
                                    <div className="grid gap-3 sm:grid-cols-2">
                                        {order.tickets.map(ticket => (
                                            <button
                                                key={ticket.id}
                                                type="button"
                                                onClick={() => setSelectedTicket({ order, ticket })}
                                                className="flex items-center gap-3 rounded-xl border border-line bg-ink p-3 text-left transition hover:border-flare/60 hover:shadow-glow"
                                            >
                                                <TicketQR value={ticket.ticket_code} size={64} className="shrink-0" />
                                                <div className="min-w-0 flex-1">
                                                    <p className="truncate text-xs font-semibold text-white">{ticket.category}{ticket.seat_label ? ` · Kursi ${ticket.seat_label}` : ''}</p>
                                                    <p className="truncate font-mono text-[11px] text-muted">{ticket.ticket_code}</p>
                                                    <p className={`mt-1 text-[11px] font-semibold ${ticket.is_used ? 'text-red-400' : 'text-pulse'}`}>
                                                        {ticket.is_used ? 'Sudah dipakai' : 'Belum dipakai'} — Lihat Detail →
                                                    </p>
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                    <p className="mt-3 text-[11px] text-muted">Petugas akan scan QR di atas saat kamu masuk venue. Jangan bagikan screenshot QR ke orang lain.</p>
                                </div>
                            )}
                        </div>
                        );
                    })
                )}
            </div>

            {selectedTicket && (
                <TicketDetailModal
                    order={selectedTicket.order}
                    ticket={selectedTicket.ticket}
                    onClose={() => setSelectedTicket(null)}
                />
            )}
        </div>
    );
}

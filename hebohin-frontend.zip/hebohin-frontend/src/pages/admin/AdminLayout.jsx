import { NavLink, Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const navItems = [
    { to: '/admin', label: 'Ringkasan', end: true },
    { to: '/admin/events', label: 'Event' },
    { to: '/admin/vouchers', label: 'Voucher' },
    { to: '/admin/orders', label: 'Pesanan' }
];

export default function AdminLayout() {
    const { user, loading } = useAuth();

    if (loading) {
        return <div className="p-10 text-sm text-muted">Memuat...</div>;
    }

    if (user?.role === 'super_admin') {
        return <Navigate to="/super-admin" replace />;
    }

    const allowedRoles = ['organizer', 'admin'];
    if (!user || !allowedRoles.includes(user.role)) {
        return <Navigate to="/" replace />;
    }

    let items = navItems;
if (user.role === 'organizer') {
    items = navItems.filter(item => item.to === '/admin' || item.to === '/admin/events');
}

    return (
        <div className="mx-auto flex max-w-6xl gap-8 px-6 py-10">
            <aside className="w-56 shrink-0">
                <div className="mb-6">
                    <p className="text-xs uppercase tracking-wide text-muted">Panel</p>
                    <p className="font-display text-lg font-semibold">
    {user.role === 'organizer' ? 'Organizer' : 'Admin'}
</p>
                </div>
                <nav className="space-y-1">
                    {items.map(item => (
                        <NavLink
                            key={item.to}
                            to={item.to}
                            end={item.end}
                            className={({ isActive }) =>
                                `block rounded-xl px-4 py-2.5 text-sm font-medium transition ${
                                    isActive
                                        ? 'bg-flare/15 text-flare2 border border-flare/30'
                                        : 'text-muted hover:bg-panel2 hover:text-white'
                                }`
                            }
                        >
                            {item.label}
                        </NavLink>
                    ))}
                </nav>
            </aside>
            <div className="min-w-0 flex-1">
                <Outlet />
            </div>
        </div>
    );
}
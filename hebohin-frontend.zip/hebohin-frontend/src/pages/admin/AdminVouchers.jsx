import { useEffect, useState } from 'react';
import { getVouchers, createVoucher, updateVoucher, deleteVoucher } from '../../api/client';

const emptyForm = {
    code: '', discountType: 'percentage', discountValue: 10,
    maxDiscount: '', minPurchase: 0, quota: 50, validFrom: '', validUntil: ''
};

function formatRemaining(validUntil) {
    if (!validUntil) return 'Tanpa batas waktu';
    const diffMs = new Date(validUntil).getTime() - Date.now();
    if (diffMs <= 0) return 'Sudah berakhir';
    const totalHours = Math.floor(diffMs / 3600000);
    const days = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    if (days > 0) return `${days} hari ${hours} jam lagi`;
    if (totalHours > 0) return `${totalHours} jam lagi`;
    return `${Math.floor(diffMs / 60000)} menit lagi`;
}

function remainingStyle(validUntil) {
    if (!validUntil) return 'bg-pulse/15 text-pulse';
    const diffMs = new Date(validUntil).getTime() - Date.now();
    if (diffMs <= 0) return 'bg-red-500/15 text-red-400';
    if (diffMs <= 24 * 3600000) return 'bg-yellow-500/15 text-yellow-400';
    return 'bg-pulse/15 text-pulse';
}

function toLocalInput(date) {
    if (!date) return '';
    const d = new Date(date);
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function AdminVouchers() {
    const [vouchers, setVouchers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [form, setForm] = useState(emptyForm);
    const [error, setError] = useState('');

    function load() {
        setLoading(true);
        getVouchers().then(res => setVouchers(res.data)).catch(console.error).finally(() => setLoading(false));
    }

    useEffect(() => { load(); }, []);

    function openCreate() {
        setForm(emptyForm);
        setEditingId(null);
        setShowForm(true);
    }

    function openEdit(v) {
        setForm({
            code: v.code, discountType: v.discount_type, discountValue: v.discount_value,
            maxDiscount: v.max_discount || '', minPurchase: v.min_purchase,
            quota: v.quota, validFrom: toLocalInput(v.valid_from) || '', validUntil: toLocalInput(v.valid_until) || ''
        });
        setEditingId(v.id);
        setShowForm(true);
    }

    function applyPreset(days) {
        const until = new Date(Date.now() + days * 24 * 3600000);
        const from = new Date();
        setForm(prev => ({
            ...prev,
            validFrom: toLocalInput(from.toISOString()),
            validUntil: toLocalInput(until.toISOString())
        }));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setError('');
        if (form.validFrom && form.validUntil && new Date(form.validUntil) < new Date(form.validFrom)) {
            setError('Tanggal berakhir harus setelah tanggal mulai berlaku');
            return;
        }
        try {
            const payload = {
                ...form,
                // datetime-local tanpa zona waktu bikin jam geser 7 jam (WIB vs UTC),
                // jadi kirim sebagai ISO biar valid_from/valid_until pas
                validFrom: form.validFrom ? new Date(form.validFrom).toISOString() : null,
                validUntil: form.validUntil ? new Date(form.validUntil).toISOString() : null,
                discountValue: Number(form.discountValue),
                maxDiscount: form.maxDiscount ? Number(form.maxDiscount) : null,
                minPurchase: Number(form.minPurchase),
                quota: Number(form.quota),
                isActive: true
            };
            if (editingId) {
                await updateVoucher(editingId, payload);
            } else {
                await createVoucher(payload);
            }
            setShowForm(false);
            load();
        } catch (err) {
            setError(err.response?.data?.message || 'Gagal menyimpan voucher');
        }
    }

    async function handleDelete(id) {
        if (!confirm('Hapus voucher ini?')) return;
        await deleteVoucher(id);
        load();
    }

    async function handleToggleActive(v) {
        await updateVoucher(v.id, {
            discountType: v.discount_type,
            discountValue: v.discount_value,
            maxDiscount: v.max_discount,
            minPurchase: v.min_purchase,
            quota: v.quota,
            isActive: !v.is_active,
            validFrom: v.valid_from,
            validUntil: v.valid_until
        });
        load();
    }

    return (
        <div>
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="font-display text-2xl font-bold">Kelola Voucher</h1>
                    <p className="mt-1 text-sm text-muted">Buat kode promo untuk mendorong penjualan tiket.</p>
                </div>
                <button onClick={openCreate} className="rounded-full bg-flare px-5 py-2.5 text-sm font-semibold shadow-glow hover:bg-flare2">
                    + Buat Voucher
                </button>
            </div>

            {showForm && (
                <form onSubmit={handleSubmit} className="mt-6 space-y-4 rounded-2xl border border-line bg-panel p-6">
                    <h2 className="font-display text-lg font-semibold">
                        {editingId ? 'Ubah Voucher' : 'Voucher Baru'}
                    </h2>
                    <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                            <label className="text-xs text-muted">Kode Voucher</label>
                            <input required disabled={!!editingId} value={form.code}
                                onChange={e => setForm({ ...form, code: e.target.value.toUpperCase() })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60 disabled:opacity-50" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Tipe Diskon</label>
                            <select value={form.discountType} onChange={e => setForm({ ...form, discountType: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60">
                                <option value="percentage">Persentase (%)</option>
                                <option value="fixed">Nominal Tetap (Rp)</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-muted">
                                Nilai Diskon {form.discountType === 'percentage' ? '(1-100)' : '(Rp)'}
                            </label>
                            <input required type="number" value={form.discountValue}
                                onChange={e => setForm({ ...form, discountValue: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        {form.discountType === 'percentage' && (
                            <div>
                                <label className="text-xs text-muted">Maks. Potongan (Rp, opsional)</label>
                                <input type="number" value={form.maxDiscount}
                                    onChange={e => setForm({ ...form, maxDiscount: e.target.value })}
                                    className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                            </div>
                        )}
                        <div>
                            <label className="text-xs text-muted">Minimal Belanja (Rp)</label>
                            <input type="number" value={form.minPurchase}
                                onChange={e => setForm({ ...form, minPurchase: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Kuota Pemakaian</label>
                            <input type="number" value={form.quota}
                                onChange={e => setForm({ ...form, quota: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Berlaku Dari (tanggal & jam)</label>
                            <input type="datetime-local" value={form.validFrom}
                                onChange={e => setForm({ ...form, validFrom: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Berlaku Sampai (tanggal & jam)</label>
                            <input type="datetime-local" value={form.validUntil}
                                onChange={e => setForm({ ...form, validUntil: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                            <div className="mt-2 flex flex-wrap gap-2">
                                <span className="text-[11px] text-muted">Masa aktif cepat:</span>
                                {[1, 7, 30].map(d => (
                                    <button
                                        key={d}
                                        type="button"
                                        onClick={() => applyPreset(d)}
                                        className="rounded-full border border-line px-3 py-1 text-[11px] font-semibold text-muted hover:border-flare/60 hover:text-white"
                                    >
                                        {d} hari
                                    </button>
                                ))}
                            </div>
                            {form.validFrom && form.validUntil && (
                                <p className="mt-1 text-[11px] text-muted">
                                    Berlaku selama {Math.max(0, Math.floor((new Date(form.validUntil) - new Date(form.validFrom)) / 86400000))} hari {Math.max(0, Math.floor(((new Date(form.validUntil) - new Date(form.validFrom)) % 86400000) / 3600000))} jam
                                    {form.validUntil === '' ? '' : ` · Sisa ${formatRemaining(form.validUntil)}`}
                                </p>
                            )}
                        </div>
                    </div>

                    {error && <p className="text-xs text-flare2">{error}</p>}

                    <div className="flex gap-3">
                        <button type="submit" className="rounded-full bg-flare px-6 py-2.5 text-sm font-semibold shadow-glow hover:bg-flare2">
                            Simpan
                        </button>
                        <button type="button" onClick={() => setShowForm(false)}
                            className="rounded-full border border-line px-6 py-2.5 text-sm font-semibold text-muted hover:text-white">
                            Batal
                        </button>
                    </div>
                </form>
            )}

            <div className="mt-6 overflow-hidden rounded-2xl border border-line bg-panel">
                <table className="w-full text-left text-sm">
                    <thead className="border-b border-line text-xs uppercase text-muted">
                        <tr>
                            <th className="px-4 py-3">Kode</th>
                            <th className="px-4 py-3">Diskon</th>
                            <th className="px-4 py-3">Berlaku S/D</th>
                            <th className="px-4 py-3">Pemakaian</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={6} className="px-4 py-6 text-center text-muted">Memuat...</td></tr>
                        ) : vouchers.length === 0 ? (
                            <tr><td colSpan={6} className="px-4 py-6 text-center text-muted">Belum ada voucher.</td></tr>
                        ) : vouchers.map(v => (
                            <tr key={v.id} className="border-b border-line last:border-0">
                                <td className="px-4 py-3 font-mono font-semibold text-pulse">{v.code}</td>
                                <td className="px-4 py-3 text-muted">
                                    {v.discount_type === 'percentage' ? `${v.discount_value}%` : `Rp${v.discount_value.toLocaleString('id-ID')}`}
                                </td>
                                <td className="px-4 py-3">
                                    <p className="text-xs text-muted">
                                        {v.valid_until ? `${new Date(v.valid_until).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })} · ${new Date(v.valid_until).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB` : 'Tanpa batas'}
                                    </p>
                                    <span className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold ${remainingStyle(v.valid_until)}`}>
                                        {formatRemaining(v.valid_until)}
                                    </span>
                                </td>
                                <td className="px-4 py-3 text-muted">{v.used_count} / {v.quota}</td>
                                <td className="px-4 py-3">
                                    <button onClick={() => handleToggleActive(v)}
                                        className={`rounded-full px-3 py-1 text-[11px] font-semibold uppercase ${
                                            v.is_active ? 'bg-pulse/15 text-pulse' : 'bg-white/10 text-muted'
                                        }`}>
                                        {v.is_active ? 'Aktif' : 'Nonaktif'}
                                    </button>
                                </td>
                                <td className="px-4 py-3 text-right">
                                    <button onClick={() => openEdit(v)} className="mr-3 text-xs font-semibold text-pulse hover:underline">
                                        Ubah
                                    </button>
                                    <button onClick={() => handleDelete(v.id)} className="text-xs font-semibold text-flare2 hover:underline">
                                        Hapus
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

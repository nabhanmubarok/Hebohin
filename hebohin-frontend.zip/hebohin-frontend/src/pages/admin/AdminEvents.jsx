import { useEffect, useState } from 'react';
import { getAdminEvents, createEvent, updateEvent, deleteEvent, uploadEventPoster } from '../../api/client';
import { useAuth } from '../../context/AuthContext';

const emptyForm = {
    name: '', artist: '', venue: '', city: '', eventDate: '', mapsLink: '', address: '', latitude: '', longitude: '', isActive: true,
    description: '', genre: '', posterUrl: '',
    ticketTypes: [{ category: 'Regular', price: 0, stock: 0, hasSeating: false, seatRows: null, seatsPerRow: null, color: '' }]
};

// Ambil latitude/longitude dari link Google Maps yang ditempel organizer.
// Support format umum:
// - https://www.google.com/maps/place/Nama/@-6.2285,106.8064,17z/
// - https://www.google.com/maps/search/?api=1&query=-6.2285,106.8064
// - https://www.google.com/maps?q=-6.2285,106.8064
// - teks koordinat saja "-6.2285, 106.8064"
// Link pendek maps.app.goo.gl tidak bisa di-parse tanpa resolve, jadi kembalikan null.
function parseMapsLink(raw) {
    const text = String(raw || '').trim();
    if (!text) return { latitude: '', longitude: '' };

    const patterns = [
        /@(-?\d+\.\d+),(-?\d+\.\d+)/,
        /[?&](?:q|query|ll|center)=(-?\d+\.\d+),(-?\d+\.\d+)/i,
        /!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/,
        /(-?\d{1,3}\.\d+),\s*(-?\d{1,3}\.\d+)/,
    ];
    for (const re of patterns) {
        const m = text.match(re);
        if (m) {
            const lat = Number(m[1]);
            const lng = Number(m[2]);
            if (Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
                return { latitude: String(lat), longitude: String(lng) };
            }
        }
    }
    return { latitude: '', longitude: '' };
}

function mapsLinkFromCoords(latitude, longitude, address) {
    if (latitude !== '' && latitude !== null && latitude !== undefined && longitude !== '' && longitude !== null && longitude !== undefined) {
        return `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;
    }
    if (address && /^https?:\/\//i.test(address)) return address;
    return '';
}

// Harga dibuat gampang: tampil "150.000" (titik ribuan), nyimpan angka asli 150000
function formatPrice(value) {
    if (value === '' || value === null || value === undefined) return '';
    const n = Number(value);
    if (!Number.isFinite(n)) return String(value);
    return n.toLocaleString('id-ID'); // 150000 -> "150.000"
}

function parsePriceInput(str) {
    const digits = String(str ?? '').replace(/[^\d]/g, '');
    if (digits === '') return 0;
    const n = Number(digits);
    return Number.isFinite(n) ? n : 0;
}

// Ubah ticket_types mentah dari DB (snake_case) jadi bentuk yang diterima backend (camelCase)
function toFormTicketTypes(ticketTypes) {
    if (!ticketTypes?.length) return emptyForm.ticketTypes;
    return ticketTypes.map(tt => ({
        id: tt.id,
        category: tt.category || '',
        price: tt.price ?? 0,
        stock: tt.stock ?? 0,
        color: tt.color || '',
        hasSeating: Boolean(tt.has_seating ?? tt.hasSeating),
        seatRows: tt.seat_rows ?? tt.seatRows ?? null,
        seatsPerRow: tt.seats_per_row ?? tt.seatsPerRow ?? null,
    }));
}

export default function AdminEvents() {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [form, setForm] = useState(emptyForm);
    const [error, setError] = useState('');
    const { user } = useAuth();
    const isOrganizer = user?.role === 'organizer';

    const [uploading, setUploading] = useState(false);

async function handleImageChange(e) {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
        const res = await uploadEventPoster(file);
        setForm(prev => ({ ...prev, posterUrl: res.data.url }));
    } catch (err) {
        setError('Gagal upload gambar: ' + (err.response?.data?.message || err.message));
    } finally {
        setUploading(false);
    }
}

    function load() {
        setLoading(true);
        getAdminEvents().then(res => setEvents(res.data)).catch(console.error).finally(() => setLoading(false));
    }

    useEffect(() => { load(); }, []);

    function openCreate() {
        setForm(emptyForm);
        setEditingId(null);
        setShowForm(true);
    }

    function openEdit(event) {
    setForm({
        name: event.name, artist: event.artist || '', venue: event.venue,
        city: event.city || '', eventDate: event.event_date?.slice(0, 16) || '',
        mapsLink: mapsLinkFromCoords(event.latitude, event.longitude, event.address),
        address: event.address || '',
        latitude: event.latitude ?? '',
        longitude: event.longitude ?? '',
        isActive: event.is_active ?? event.isActive ?? true,
        description: event.description || '', genre: event.genre || '',
        posterUrl: event.poster_url || '',
        ticketTypes: toFormTicketTypes(event.ticket_types)
    });
    setEditingId(event.id);
    setShowForm(true);
}

    function handleMapsLinkChange(value) {
        const parsed = parseMapsLink(value);
        const trimmed = String(value || '').trim();
        setForm(prev => {
            // Alamat di DB tetap disimpan sebagai link Maps (atau tetap link awal kalau koordinat ketemu).
            // Kalau user tempel link pendek (maps.app.goo.gl) yang koordinatnya tidak bisa di-parse,
            // link tetap disimpan sebagai address biar tombol Maps di detail event tetap bekerja.
            const next = { ...prev, mapsLink: trimmed, address: trimmed || prev.address };
            if (parsed.latitude && parsed.longitude) {
                next.latitude = parsed.latitude;
                next.longitude = parsed.longitude;
            } else if (trimmed && !/^https?:\/\//i.test(trimmed) && trimmed.includes(',')) {
                // Teks koordinat manual sudah di-handle parseMapsLink, kalau tidak match jangan timpa lat/lng lama diam-diam
            } else if (!trimmed) {
                // Kalau dikosongkan, bersihkan juga koordinat biar tidak tersimpan nyasar
                next.latitude = '';
                next.longitude = '';
                next.address = '';
            }
            return next;
        });
    }

    function updateTicketType(index, field, value) {
        setForm(prev => {
            const next = [...prev.ticketTypes];
            next[index] = { ...next[index], [field]: field === 'category' ? value : Number(value) };
            return { ...prev, ticketTypes: next };
        });
    }

    function addTicketType() {
        setForm(prev => ({
            ...prev,
            ticketTypes: [...prev.ticketTypes, { category: '', price: 0, stock: 0, hasSeating: false, seatRows: null, seatsPerRow: null, color: '' }]
        }));
    }

    function removeTicketType(index) {
        setForm(prev => ({
            ...prev,
            ticketTypes: prev.ticketTypes.filter((_, i) => i !== index)
        }));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setError('');
        try {
            if (editingId) {
                await updateEvent(editingId, form);
            } else {
                await createEvent(form);
            }
            setShowForm(false);
            load();
        } catch (err) {
            const detail = err.response?.data?.error;
            const message = err.response?.data?.message;
            // Tampilkan detail error backend juga, biar tidak cuma "Gagal update event" yang membingungkan
            setError([message, detail && detail !== message ? `(${detail})` : ''].filter(Boolean).join(' ') || 'Gagal menyimpan event');
        }
    }

    async function handleDelete(id) {
        if (!confirm('Hapus event ini? Tindakan tidak bisa dibatalkan.')) return;
        try {
            await deleteEvent(id);
            load();
        } catch (err) {
            const detail = err.response?.data?.error;
            const message = err.response?.data?.message;
            setError([message, detail && detail !== message ? `(${detail})` : ''].filter(Boolean).join(' ') || 'Gagal menghapus event');
        }
    }

    return (
        <div>
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="font-display text-2xl font-bold">Kelola Event</h1>
                    <p className="mt-1 text-sm text-muted">
                        {isOrganizer
                            ? 'Kelola event yang kamu buat saja — organizer lain tidak terlihat di sini.'
                            : 'Tambah, ubah, atau hapus konser yang tersedia.'}
                    </p>
                </div>
                <button
                    onClick={openCreate}
                    className="rounded-full bg-flare px-5 py-2.5 text-sm font-semibold shadow-glow transition hover:bg-flare2"
                >
                    + Tambah Event
                </button>
            </div>

            {showForm && (
                <form onSubmit={handleSubmit} className="mt-6 space-y-4 rounded-2xl border border-line bg-panel p-6">
                    <h2 className="font-display text-lg font-semibold">
                        {editingId ? 'Ubah Event' : 'Event Baru'}
                    </h2>

                    <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                            <label className="text-xs text-muted">Nama Event</label>
                            <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Artis</label>
                            <input value={form.artist} onChange={e => setForm({ ...form, artist: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Venue</label>
                            <input required value={form.venue} onChange={e => setForm({ ...form, venue: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Kota</label>
                            <input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
                            <label className="text-xs text-muted">Tanggal & Waktu</label>
                            <input required type="datetime-local" value={form.eventDate}
                                onChange={e => setForm({ ...form, eventDate: e.target.value })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                        </div>
                        <div>
    <label className="text-xs text-muted">Genre</label>
    <select value={form.genre} onChange={e => setForm({ ...form, genre: e.target.value })}
        className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60">
        <option value="">Pilih genre</option>
        <option value="Pop">Pop</option>
        <option value="Rock">Rock</option>
        <option value="Indie">Indie</option>
        <option value="Jazz">Jazz</option>
        <option value="EDM">EDM</option>
        <option value="Hip Hop">Hip Hop</option>
        <option value="RnB">R&B</option>
        <option value="Metal">Metal</option>
        <option value="Klasik">Klasik</option>
        <option value="Dangdut">Dangdut</option>
        <option value="Folk/Akustik">Folk/Akustik</option>
        <option value="Lainnya">Lainnya</option>
    </select>
</div>
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2">
                        <div className="sm:col-span-2">
                            <label className="text-xs text-muted">Link Google Maps (lokasi venue)</label>
                            <input
                                value={form.mapsLink}
                                onChange={e => handleMapsLinkChange(e.target.value)}
                                placeholder="Tempel link dari Google Maps, contoh: https://www.google.com/maps/place/..."
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60"
                            />
                            <p className="mt-1 text-[11px] text-muted">
                                Tempel link Maps sekali — koordinat langsung terisi otomatis, nggak perlu isi latitude/longitude manual.
                                Link pendek (`maps.app.goo.gl`) juga bisa ditempel, tapi koordinatnya nggak bisa di-parse otomatis.
                            </p>
                            {form.latitude && form.longitude ? (
                                <p className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted">
                                    <span className="rounded-full bg-pulse/15 px-3 py-1 font-mono text-pulse">{form.latitude}, {form.longitude}</span>
                                    {form.mapsLink && (
                                        <a href={form.mapsLink} target="_blank" rel="noreferrer" className="font-semibold text-pulse hover:underline">
                                            Lihat di Maps ↗
                                        </a>
                                    )}
                                </p>
                            ) : form.mapsLink ? (
                                <p className="mt-2 text-[11px] text-yellow-400">
                                    Link belum mengandung koordinat yang bisa dibaca. Peta di detail event akan pakai tombol “Buka di Google Maps” saja.
                                </p>
                            ) : null}
                            <details className="mt-2">
                                <summary className="cursor-pointer text-[11px] font-semibold text-muted hover:text-white">Isi koordinat manual (opsional)</summary>
                                <div className="mt-2 grid gap-3 sm:grid-cols-2">
                                    <input type="number" step="any" value={form.latitude} onChange={e => setForm({ ...form, latitude: e.target.value })}
                                        placeholder="Latitude, contoh: -6.2"
                                        className="w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                                    <input type="number" step="any" value={form.longitude} onChange={e => setForm({ ...form, longitude: e.target.value })}
                                        placeholder="Longitude, contoh: 106.8"
                                        className="w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                                </div>
                            </details>
                        </div>
                        <div>
                            <label className="text-xs text-muted">Status Event</label>
                            <select value={form.isActive ? 'aktif' : 'nonaktif'} onChange={e => setForm({ ...form, isActive: e.target.value === 'aktif' })}
                                className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60">
                                <option value="aktif">Aktif</option>
                                <option value="nonaktif">Nonaktif (sembunyikan dari publik)</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label className="text-xs text-muted">Deskripsi</label>
                        <textarea rows={3} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                            className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none focus:border-flare/60" />
                    </div>

                    <div>
    <label className="text-xs text-muted">Gambar Poster Event</label>
    <input
        type="file"
        accept="image/*"
        onChange={handleImageChange}
        className="mt-1 w-full rounded-xl border border-line bg-panel2 px-3 py-2 text-sm outline-none file:mr-3 file:rounded-lg file:border-0 file:bg-flare file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white"
    />
    {uploading && <p className="mt-1 text-xs text-pulse">Mengupload...</p>}
    {form.posterUrl && (
        <img src={form.posterUrl} alt="Preview" className="mt-3 h-40 w-full rounded-xl object-cover" />
    )}
</div>

                    <div>
                        <div className="flex items-center justify-between">
                            <label className="text-xs text-muted">Kategori Tiket</label>
                            <button type="button" onClick={addTicketType} className="text-xs font-semibold text-pulse hover:underline">
                                + Tambah Kategori
                            </button>
                        </div>
                        <div className="mt-2 space-y-2">
                            <div className="grid grid-cols-[1.5fr_1fr_1fr_auto] gap-2 text-[10px] font-semibold uppercase tracking-wide text-muted">
                                <span>Kategori</span><span>Harga (Rp)</span><span>Stok (jumlah tiket)</span><span></span>
                            </div>
                            {form.ticketTypes.map((tt, i) => (
                                <div key={i} className="grid grid-cols-[1.5fr_1fr_1fr_auto] gap-2">
                                    <input placeholder="Kategori (VIP/Regular)" value={tt.category}
                                        onChange={e => updateTicketType(i, 'category', e.target.value)}
                                        className="rounded-lg border border-line bg-panel2 px-3 py-2 text-xs outline-none focus:border-flare/60" />
                                    <input
                                        type="text"
                                        inputMode="numeric"
                                        placeholder="0"
                                        value={tt.price ? formatPrice(tt.price) : ''}
                                        onChange={e => {
                                            const parsed = parsePriceInput(e.target.value);
                                            setForm(prev => {
                                                const next = [...prev.ticketTypes];
                                                next[i] = { ...next[i], price: parsed };
                                                return { ...prev, ticketTypes: next };
                                            });
                                        }}
                                        onFocus={e => e.target.select()}
                                        className="rounded-lg border border-line bg-panel2 px-3 py-2 text-xs outline-none focus:border-flare/60"
                                    />
                                    <input type="number" placeholder="Stok" value={tt.stock}
                                        onChange={e => updateTicketType(i, 'stock', e.target.value)}
                                        className="rounded-lg border border-line bg-panel2 px-3 py-2 text-xs outline-none focus:border-flare/60" />
                                    <button type="button" onClick={() => removeTicketType(i)}
                                        className="rounded-lg border border-line px-2 text-xs text-flare2 hover:border-flare/60">
                                        Hapus
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>

                    {error && <p className="text-xs text-flare2">{error}</p>}

                    <div className="flex gap-3">
                        <button type="submit" className="rounded-full bg-flare px-6 py-2.5 text-sm font-semibold shadow-glow hover:bg-flare2">
                            Simpan
                        </button>
                        <button type="button" onClick={() => setShowForm(false)}
                            className="rounded-full border border-line px-6 py-2.5 text-sm font-semibold text-muted hover:text-white">
                            Batal
                        </button>
                    </div>
                </form>
            )}

            <div className="mt-6 overflow-hidden rounded-2xl border border-line bg-panel">
                <table className="w-full text-left text-sm">
                    <thead className="border-b border-line text-xs uppercase text-muted">
                        <tr>
                            <th className="px-4 py-3">Nama</th>
                            <th className="px-4 py-3">Venue</th>
                            <th className="px-4 py-3">Tanggal</th>
                            <th className="px-4 py-3">Kategori</th>
                            <th className="px-4 py-3 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={5} className="px-4 py-6 text-center text-muted">Memuat...</td></tr>
                        ) : events.length === 0 ? (
                            <tr><td colSpan={5} className="px-4 py-6 text-center text-muted">
                                {isOrganizer ? 'Kamu belum buat event. Klik "+ Tambah Event" untuk buat yang pertama.' : 'Belum ada event.'}
                            </td></tr>
                        ) : events.map(event => (
                            <tr key={event.id} className="border-b border-line last:border-0">
                                <td className="px-4 py-3 font-medium">{event.name}</td>
                                <td className="px-4 py-3 text-muted">{event.venue}</td>
                                <td className="px-4 py-3 text-muted">
                                    {new Date(event.event_date).toLocaleDateString('id-ID')}
                                </td>
                                <td className="px-4 py-3 text-muted">
                                    {event.ticket_types?.map(t => t.category).join(', ')}
                                </td>
                                <td className="px-4 py-3 text-right">
                                    <button onClick={() => openEdit(event)} className="mr-3 text-xs font-semibold text-pulse hover:underline">
                                        Ubah
                                    </button>
                                    <button onClick={() => handleDelete(event.id)} className="text-xs font-semibold text-flare2 hover:underline">
                                        Hapus
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

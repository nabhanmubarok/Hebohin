import { useEffect, useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getEvents, getMyOrders } from '../api/client';
import HeroBanner from '../components/HeroBanner';
import ShowCard from '../components/ShowCard';
import FeaturedCard from '../components/FeaturedCard';

function SectionHeader({ title, to, linkLabel }) {
    return (
        <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-xl font-bold text-white">{title}</h2>
            {to && (
                <Link
                    to={to}
                    className="rounded-full border border-line px-4 py-1.5 text-xs font-semibold text-white transition hover:border-flare/60 hover:bg-flare/10"
                >
                    {linkLabel || 'Lihat Semua'}
                </Link>
            )}
        </div>
    );
}

export default function Dashboard() {
    const { user } = useAuth();
    const [events, setEvents] = useState([]);
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user?.role === 'super_admin') return;
        async function load() {
            try {
                const [eventsRes, ordersRes] = await Promise.all([
                    getEvents(),
                    user ? getMyOrders() : Promise.resolve({ data: [] })
                ]);
                setEvents(eventsRes.data);
                setOrders(ordersRes.data);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        }
        load();
    }, [user]);

    const upcomingOrders = orders.filter(o => o.status === 'paid').slice(0, 2);
    const firstName = user?.name?.split(' ')[0];

    if (user?.role === 'super_admin') return <Navigate to="/super-admin" replace />;

    const sedangTayang = events.slice(0, 8);
    const unggulan = events.slice(0, 2);

    return (
        <>
            {/* Hero carousel full-width dengan efek intip slide tetangga */}
            {events.length > 0 && (
                <div className="w-full pt-6">
                    <HeroBanner events={events} />
                </div>
            )}

            <div className="mx-auto max-w-6xl px-6 py-10">
            {/* Welcome strip */}
            <section className="relative mb-12 overflow-hidden rounded-3xl border border-line bg-panel p-8 shadow-glow">
                <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-flare/20 blur-3xl" />
                <div className="absolute -bottom-20 left-0 h-56 w-56 rounded-full bg-pulse/20 blur-3xl" />
                <div className="relative flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <h1 className="font-display text-2xl font-bold sm:text-3xl">
                            Siap untuk beat berikutnya
                            {firstName ? <>, <span className="text-flare2">{firstName}</span></> : ''}?
                        </h1>
                        <p className="mt-2 max-w-xl text-sm text-muted">
                            {upcomingOrders.length > 0
                                ? `Kamu punya ${upcomingOrders.length} tiket yang belum kadaluarsa. Jangan sampai kelewatan harinya.`
                                : 'Jelajahi konser terbaru dan amankan tiketmu sebelum kehabisan.'}
                        </p>
                    </div>
                    <div className="flex flex-wrap gap-3">
                        <Link to="/explore" className="rounded-full bg-flare px-6 py-3 text-sm font-semibold shadow-glow transition hover:bg-flare2">
                            Cari Event Baru
                        </Link>
                        <Link to="/my-tickets" className="rounded-full border border-line px-6 py-3 text-sm font-semibold text-muted transition hover:border-pulse/60 hover:text-white">
                            Lihat Tiket Saya
                        </Link>
                    </div>
                </div>
            </section>

            {/* Sedang Tayang */}
            <section>
                <SectionHeader title="Sedang Tayang" to="/explore" />
                {loading ? (
                    <p className="text-sm text-muted">Memuat...</p>
                ) : sedangTayang.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">
                        Belum ada event. Yuk jelajahi event yang tersedia.
                    </div>
                ) : (
                    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
                        {sedangTayang.map(event => (
                            <ShowCard key={event.id} event={event} />
                        ))}
                    </div>
                )}
            </section>

            {/* Unggulan */}
            <section className="mt-12">
                <SectionHeader title="Unggulan" to="/explore" />
                {loading ? (
                    <p className="text-sm text-muted">Memuat...</p>
                ) : unggulan.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-line p-10 text-center text-sm text-muted">
                        Belum ada event unggulan.
                    </div>
                ) : (
                    <div className="grid gap-5 lg:grid-cols-2">
                        {unggulan.map(event => (
                            <FeaturedCard key={event.id} event={event} />
                        ))}
                    </div>
                )}
            </section>

            {/* Pribadi (tetap ada, di bawah seperti sebelumnya) */}
            <div className="mt-12 grid gap-8 lg:grid-cols-3">
                <div className="lg:col-span-2">
                    <div className="mb-4 flex items-center justify-between">
                        <h2 className="font-display text-xl font-semibold">Event Mendatang Saya</h2>
                        <Link to="/my-tickets" className="text-xs font-semibold text-pulse hover:underline">
                            Lihat Semua
                        </Link>
                    </div>

                    {loading ? (
                        <p className="text-sm text-muted">Memuat...</p>
                    ) : upcomingOrders.length === 0 ? (
                        <div className="rounded-2xl border border-dashed border-line p-8 text-center text-sm text-muted">
                            Belum ada tiket aktif. Yuk jelajahi event yang tersedia.
                        </div>
                    ) : (
                        <div className="grid gap-4 sm:grid-cols-2">
                            {upcomingOrders.map(order => (
                                <div key={order.id} className="ticket-notch rounded-2xl border border-line bg-panel p-5">
                                    <span className="rounded-full bg-pulse/15 px-3 py-1 text-[11px] font-semibold uppercase text-pulse">
                                        {order.status === 'paid' ? 'Lunas' : order.status}
                                    </span>
                                    <h3 className="mt-3 font-display font-semibold">{order.events?.name}</h3>
                                    <p className="text-xs text-muted">{order.events?.venue}</p>
                                    <Link to="/my-tickets" className="mt-3 inline-block text-xs font-semibold text-flare2 hover:underline">
                                        Lihat Tiket →
                                    </Link>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div className="space-y-6">
                    <div className="rounded-2xl border border-line bg-panel p-5">
                        <h3 className="font-display font-semibold">Riwayat Pesanan</h3>
                        <div className="mt-4 space-y-3">
                            {orders.slice(0, 3).map(order => (
                                <div key={order.id} className="flex items-center justify-between text-sm">
                                    <div>
                                        <p className="font-medium">{order.events?.name || 'Event'}</p>
                                        <p className="text-xs text-muted">
                                            {order.status === 'paid' ? 'Selesai' : order.status}
                                        </p>
                                    </div>
                                    <span className="text-xs text-muted">
                                        Rp{order.total_amount?.toLocaleString('id-ID')}
                                    </span>
                                </div>
                            ))}
                            {orders.length === 0 && (
                                <p className="text-xs text-muted">Belum ada riwayat pesanan.</p>
                            )}
                        </div>
                        <Link to="/my-tickets" className="mt-4 inline-block text-xs font-semibold text-pulse hover:underline">
                            Lihat Riwayat →
                        </Link>
                    </div>

                    <div className="rounded-2xl border border-flare/30 bg-gradient-to-br from-flare/10 to-transparent p-5">
                        <h3 className="font-display font-semibold text-flare2">HebohIn VIP</h3>
                        <p className="mt-2 text-xs text-muted">
                            Dapatkan akses lebih awal ke tiket presale dan promo eksklusif.
                        </p>
                        <button className="mt-4 w-full rounded-full bg-flare py-2 text-sm font-semibold shadow-glow transition hover:bg-flare2">
                            Gabung Sekarang
                        </button>
                    </div>
                </div>
            </div>
            </div>
        </>
    );
}

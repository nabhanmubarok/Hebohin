import { useEffect, useState } from 'react';
import { getDashboardSummary } from '../../api/client';
import { useAuth } from '../../context/AuthContext';

function StatCard({ label, value, color, border }) {
    return (
        <div className={`overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm border-t-4 ${border}`}>
            <div className="p-6">
                <p className="text-sm font-medium text-slate-500">{label}</p>
                <p className={`mt-3 font-display text-3xl font-bold ${color}`}>{value}</p>
            </div>
        </div>
    );
}

export default function SuperAdminDashboard() {
    const { user } = useAuth();
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(false);

    function load() {
        setLoading(true);
        setError(false);
        getDashboardSummary()
            .then(res => setStats(res.data))
            .catch(() => setError(true))
            .finally(() => setLoading(false));
    }

    useEffect(() => { load(); }, []);

    const days = stats?.revenueByDay || [];
    const maxRevenue = Math.max(...days.map(d => d.total), 1);
    const rupiah = n => `Rp${(n || 0).toLocaleString('id-ID')}`;

    return (
        <div className="mx-auto max-w-7xl">
            <div className="flex flex-col gap-4 rounded-3xl border border-slate-200 bg-gradient-to-r from-white via-white to-sky-50 p-8 shadow-sm sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <div className="flex items-center gap-3">
                        <span className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#0b3b6f]">Dashboard Super Admin</span>
                        <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-700">● Live</span>
                    </div>
                    <h1 className="mt-2 font-display text-3xl font-bold">Selamat datang, {user?.name?.split(' ')[0]}</h1>
                    <p className="mt-1 text-sm text-slate-500">Pantau penjualan, event, dan akses pengguna HebohIn dari satu tempat.</p>
                </div>
                <button
                    onClick={load}
                    className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50"
                >
                    ⟳ Refresh Data
                </button>
            </div>

            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
                <StatCard label="Total Pendapatan" value={stats ? rupiah(stats.totalRevenue) : '—'} color="text-[#0b3b6f]" border="border-t-[#0b3b6f]" />
                <StatCard label="Pesanan Lunas" value={stats ? stats.totalOrders : '—'} color="text-violet-600" border="border-t-violet-500" />
                <StatCard label="Tiket Terjual" value={stats ? stats.totalTicketsSold : '—'} color="text-emerald-600" border="border-t-emerald-500" />
                <StatCard label="Total Event" value={stats ? stats.totalEvents : '—'} color="text-amber-600" border="border-t-amber-500" />
            </div>

            <div className="mt-6 rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
                <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-[#0b3b6f]">Aktivitas Penjualan</p>
                <h2 className="mt-1 font-display text-xl font-bold">Pendapatan 7 Hari Terakhir</h2>

                {loading ? (
                    <p className="mt-8 text-sm text-slate-500">Memuat statistik...</p>
                ) : error ? (
                    <p className="mt-8 text-sm text-rose-600">
                        Gagal memuat statistik. Pastikan endpoint <code>/api/dashboard/summary</code> sudah ada di backend.
                    </p>
                ) : (
                    <div className="mt-8 flex items-end gap-4 rounded-2xl bg-slate-50 p-6" style={{ height: 240 }}>
                        {days.map(day => (
                            <div key={day.date} className="flex h-full flex-1 flex-col items-center justify-end gap-2">
                                <div
                                    className="w-full rounded-t-xl bg-gradient-to-t from-[#0b3b6f] to-sky-400"
                                    style={{ height: `${Math.max(4, (day.total / maxRevenue) * 150)}px` }}
                                    title={rupiah(day.total)}
                                />
                                <span className="text-xs font-medium text-slate-500">
                                    {new Date(day.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                                </span>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}
import { useMemo, useState } from 'react';
import { NavLink, Navigate, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { logoutUser } from '../../api/client';

const Icon = ({ d }) => (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
        {d.map((p, i) => <path key={i} d={p} />)}
    </svg>
);

const icons = {
    event: ['M4 6h16v14H4z', 'M4 10h16', 'M8 3v4', 'M16 3v4'],
    voucher: ['M3 8a2 2 0 0 0 0 4v4h18v-4a2 2 0 0 1 0-4V4H3z', 'M13 4v16'],
    order: ['M6 6h15l-1.5 9h-12z', 'M6 6 5 3H2', 'M9 20h.01', 'M18 20h.01'],
    inbox: ['M3 13l3-8h12l3 8', 'M3 13v6h18v-6', 'M3 13h5l1 3h6l1-3h5'],
    users: ['M16 19v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1', 'M9.5 10a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z', 'M21 19v-1a4 4 0 0 0-3-3.9', 'M16 3.1a3.5 3.5 0 0 1 0 6.8']
};

// Isi sidebar: menu CRUD saja
const sections = [
    {
        title: 'Kelola Data',
        items: [
            { to: '/super-admin/events', label: 'Event', sub: 'Tambah, ubah, hapus event', icon: icons.event },
            { to: '/super-admin/vouchers', label: 'Voucher', sub: 'Kode promo & diskon', icon: icons.voucher },
            { to: '/super-admin/orders', label: 'Pesanan', sub: 'Transaksi & pembayaran', icon: icons.order }
        ]
    },
    {
        title: 'Pengguna',
        items: [
            { to: '/super-admin/organizer-applications', label: 'Pengajuan Organizer', sub: 'Setujui / tolak', icon: icons.inbox },
            { to: '/super-admin/users', label: 'Kelola User', sub: 'Role & akses', icon: icons.users }
        ]
    }
];

export default function SuperAdminLayout() {
    const { user, setUser, loading } = useAuth();
    const navigate = useNavigate();
    const [collapsed, setCollapsed] = useState(false);
    const [query, setQuery] = useState('');

    const allItems = useMemo(() => sections.flatMap(s => s.items), []);

    if (loading) return <div className="p-10 text-sm text-muted">Memuat...</div>;
    if (!user || user.role !== 'super_admin') return <Navigate to="/" replace />;

    const matches = query.trim()
        ? allItems.filter(i => (i.label + ' ' + i.sub).toLowerCase().includes(query.toLowerCase()))
        : [];

    async function handleLogout() {
        await logoutUser();
        setUser(null);
        navigate('/login');
    }

    return (
        <div className="flex h-screen overflow-hidden text-white">
            {/* ===== SIDEBAR ===== */}
            <aside className={`relative flex shrink-0 flex-col border-r border-line bg-panel/90 backdrop-blur-md transition-all duration-300 ${collapsed ? 'w-20' : 'w-72'}`}>
                <div className="flex h-[72px] items-center border-b border-line px-6">
                    <span className="font-display text-xl font-bold tracking-tight">
                        Heboh<span className="text-flare">In</span>
                    </span>
                    {!collapsed && (
                        <span className="ml-3 rounded-full border border-flare/30 bg-flare/15 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-flare2">
                            Super Admin
                        </span>
                    )}
                </div>

                <button
                    onClick={() => setCollapsed(c => !c)}
                    aria-label="Ciutkan sidebar"
                    className="absolute -right-4 top-[56px] z-20 flex h-8 w-8 items-center justify-center rounded-full border border-line bg-panel2 text-muted shadow-lg transition hover:border-flare/60 hover:text-white"
                >
                    <svg viewBox="0 0 24 24" className={`h-4 w-4 transition ${collapsed ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M15 18l-6-6 6-6" />
                    </svg>
                </button>

                <nav className="flex-1 space-y-7 overflow-y-auto px-4 py-6">
                    {sections.map(section => (
                        <div key={section.title}>
                            {!collapsed && (
                                <p className="mb-2 px-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-muted">
                                    {section.title}
                                </p>
                            )}
                            <div className="space-y-1.5">
                                {section.items.map(item => (
                                    <NavLink
                                        key={item.to}
                                        to={item.to}
                                        title={item.label}
                                        className={({ isActive }) =>
                                            `flex items-center gap-3 rounded-2xl border px-3 py-2.5 transition ${
                                                isActive
                                                    ? 'border-flare/30 bg-flare/15 text-flare2'
                                                    : 'border-transparent text-muted hover:bg-panel2 hover:text-white'
                                            }`
                                        }
                                    >
                                        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/5">
                                            <Icon d={item.icon} />
                                        </span>
                                        {!collapsed && (
                                            <span className="min-w-0">
                                                <span className="block truncate text-sm font-semibold leading-tight">{item.label}</span>
                                                <span className="block truncate text-xs opacity-70">{item.sub}</span>
                                            </span>
                                        )}
                                    </NavLink>
                                ))}
                            </div>
                        </div>
                    ))}
                </nav>

                <div className="flex items-center justify-between border-t border-line px-5 py-4">
                    {!collapsed && (
                        <div className="min-w-0">
                            <p className="truncate text-sm font-semibold">{user.name}</p>
                            <p className="text-[11px] text-muted">Super Admin</p>
                        </div>
                    )}
                    <button
                        onClick={handleLogout}
                        className="flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-xs font-semibold text-muted transition hover:border-flare/60 hover:text-white"
                    >
                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="M16 17l5-5-5-5" /><path d="M21 12H9" />
                        </svg>
                        {!collapsed && 'Keluar'}
                    </button>
                </div>
            </aside>

            {/* ===== KONTEN ===== */}
            <div className="flex min-w-0 flex-1 flex-col">
                <header className="relative flex h-[72px] shrink-0 items-center justify-between gap-4 border-b border-line bg-ink/60 px-8 backdrop-blur-md">
                    <div className="relative w-full max-w-md">
                        <svg viewBox="0 0 24 24" className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                            <circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" />
                        </svg>
                        <input
                            value={query}
                            onChange={e => setQuery(e.target.value)}
                            placeholder="Cari menu..."
                            className="w-full rounded-full border border-line bg-panel py-2.5 pl-10 pr-4 text-sm text-white outline-none placeholder:text-muted focus:border-pulse/60"
                        />
                        {matches.length > 0 && (
                            <div className="absolute left-0 right-0 top-12 z-30 overflow-hidden rounded-2xl border border-line bg-panel shadow-glow">
                                {matches.map(m => (
                                    <button
                                        key={m.to}
                                        onClick={() => { navigate(m.to); setQuery(''); }}
                                        className="block w-full px-4 py-2.5 text-left hover:bg-panel2"
                                    >
                                        <span className="block text-sm font-semibold">{m.label}</span>
                                        <span className="block text-xs text-muted">{m.sub}</span>
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    <div className="flex items-center gap-3 rounded-full border border-line bg-panel py-1.5 pl-1.5 pr-4">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-flare text-sm font-bold text-white">
                            {user.name?.[0]?.toUpperCase() || 'S'}
                        </span>
                        <span className="hidden text-sm font-semibold sm:block">{user.name}</span>
                    </div>
                </header>

                <main className="flex-1 overflow-y-auto px-8 py-8">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}
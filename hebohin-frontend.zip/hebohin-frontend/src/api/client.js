import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export const api = axios.create({
    baseURL: API_URL,
    withCredentials: true // wajib, supaya cookie session ikut terkirim
});

// ==== Auth ====
export const registerUser = (data) => api.post('/auth/register', data);
export const loginUser = (data) => api.post('/auth/login', data);
export const logoutUser = () => api.post('/auth/logout');
export const sendOtp = (email) => api.post('/auth/send-otp', { email });
export const verifyOtp = (data) => api.post('/auth/verify-otp', data);
export const getMe = () => api.get('/auth/me');
export const googleLoginUrl = `${API_URL}/auth/google`;

// ==== Events ====
export const getEvents = () => api.get('/api/events');
export const getEventById = (id) => api.get(`/api/events/${id}`);

// ==== Orders ====
export const createOrder = (data) => api.post('/api/orders', data);
export const getMyOrders = () => api.get('/api/orders/my-orders');
export const syncOrder = (orderId) => api.post(`/api/orders/${orderId}/sync`);

// ==== Vouchers ====
export const validateVoucher = (data) => api.post('/api/vouchers/validate', data);
export const getVouchers = () => api.get('/api/vouchers');
export const getActiveVouchers = () => api.get('/api/vouchers/active');
export const createVoucher = (data) => api.post('/api/vouchers', data);
export const updateVoucher = (id, data) => api.put(`/api/vouchers/${id}`, data);
export const deleteVoucher = (id) => api.delete(`/api/vouchers/${id}`);

// ==== Events (admin) ====
export const getAdminEvents = () => api.get('/api/events/my-events/list');
export const createEvent = (data) => api.post('/api/events', data);
export const updateEvent = (id, data) => api.put(`/api/events/${id}`, data);
export const deleteEvent = (id) => api.delete(`/api/events/${id}`);

// ==== Orders (admin) ====
export const getAllOrders = () => api.get('/api/orders/all');

// ==== Users (super admin) ====
export const getUsers = () => api.get('/api/users');
export const updateUserRole = (id, role) => api.put(`/api/users/${id}/role`, { role });
export const deleteUser = (id) => api.delete(`/api/users/${id}`);

// ==== Dashboard ====
export const getDashboardSummary = () => api.get('/api/dashboard/summary');

// ==== Upload ====
export const uploadEventPoster = (file) => {
    const formData = new FormData();
    formData.append('image', file);
    return api.post('/api/upload/event-poster', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
    });
};

// ==== Organizer ====
export const applyOrganizer = (data) => api.post('/api/organizer/apply', data);
export const getMyApplication = () => api.get('/api/organizer/my-application');
export const getApplications = () => api.get('/api/organizer/applications');
export const approveApplication = (id) => api.put(`/api/organizer/applications/${id}/approve`);
export const rejectApplication = (id) => api.put(`/api/organizer/applications/${id}/reject`);
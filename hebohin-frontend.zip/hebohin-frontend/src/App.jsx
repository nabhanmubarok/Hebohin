import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import Explore from './pages/Explore';
import EventDetail from './pages/EventDetail';
import MyTickets from './pages/MyTickets';
import Favorites from './pages/Favorites';
import Login from './pages/Login';
import Register from './pages/Register';
import VerifyOtp from './pages/VerifyOtp';
import AdminLayout from './pages/admin/AdminLayout';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminEvents from './pages/admin/AdminEvents';
import AdminVouchers from './pages/admin/AdminVouchers';
import AdminOrders from './pages/admin/AdminOrders';
import AdminUsers from './pages/admin/AdminUsers';
import BecomeOrganizer from './pages/BecomeOrganizer';
import AdminOrganizerApplications from './pages/admin/AdminOrganizerApplications';
import SuperAdminLayout from './pages/superadmin/SuperAdminLayout';

export default function App() {
    const { pathname } = useLocation();
    const inSuperAdmin = pathname.startsWith('/super-admin');

    return (
        <div className="min-h-screen">
            {!inSuperAdmin && <Navbar />}
            <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/explore" element={<Explore />} />
                <Route path="/events/:id" element={<EventDetail />} />
                <Route path="/my-tickets" element={<MyTickets />} />
                <Route path="/favorites" element={<Favorites />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/verify-otp" element={<VerifyOtp />} />
                <Route path="/become-organizer" element={<BecomeOrganizer />} />

                <Route path="/admin" element={<AdminLayout />}>
                    <Route index element={<AdminDashboard />} />
                    <Route path="events" element={<AdminEvents />} />
                    <Route path="vouchers" element={<AdminVouchers />} />
                    <Route path="orders" element={<AdminOrders />} />
                </Route>

                <Route path="/super-admin" element={<SuperAdminLayout />}>
                    <Route index element={<Navigate to="events" replace />} />
                    <Route path="events" element={<AdminEvents />} />
                    <Route path="vouchers" element={<AdminVouchers />} />
                    <Route path="orders" element={<AdminOrders />} />
                    <Route path="users" element={<AdminUsers />} />
                    <Route path="organizer-applications" element={<AdminOrganizerApplications />} />
                </Route>
            </Routes>
        </div>
    );
}
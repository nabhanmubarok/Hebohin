import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

export default function HeroBanner({ events }) {
    const [index, setIndex] = useState(0);
    const withPoster = events.filter(e => e.poster_url);
    const scrollRef = useRef(null);
    const slideRefs = useRef([]);

    // Scroll slide aktif ke tengah
    useEffect(() => {
        const el = slideRefs.current[index];
        if (el && scrollRef.current) {
            el.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
        }
    }, [index]);

    useEffect(() => {
        if (withPoster.length <= 1) return;
        const timer = setInterval(() => {
            setIndex(prev => (prev + 1) % withPoster.length);
        }, 6000);
        return () => clearInterval(timer);
    }, [withPoster.length]);

    if (withPoster.length === 0) return null;

    function prev() {
        setIndex(i => (i - 1 + withPoster.length) % withPoster.length);
    }
    function next() {
        setIndex(i => (i + 1) % withPoster.length);
    }

    return (
        <div className="relative w-full">
            {/* Track dengan peek slide kiri/kanan: slide aktif 70% di tengah, slide tetangga ngintip dari sisi */}
            <div
                ref={scrollRef}
                className="flex gap-4 overflow-x-auto snap-x snap-mandatory scroll-smooth px-[7.5%] pb-6 pt-2 sm:px-[12.5%] lg:px-[15%] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
            >
                {withPoster.map((event, i) => {
                    const active = i === index;
                    return (
                        <div
                            key={event.id}
                            ref={el => { slideRefs.current[i] = el; }}
                            onClick={() => setIndex(i)}
                            className={`relative w-[85%] flex-shrink-0 snap-center overflow-hidden rounded-3xl border transition-all duration-500 sm:w-[75%] lg:w-[70%] ${active ? 'border-line opacity-100 shadow-glow' : 'border-line/50 opacity-50 grayscale-[0.2] hover:opacity-75'}`}
                        >
                            <Link to={`/events/${event.id}`} className="block">
                                <div className="relative h-[280px] w-full sm:h-[380px] lg:h-[460px]">
                                    <img src={event.poster_url} alt={event.name} className="h-full w-full object-cover" />
                                    <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
                                    <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8">
                                        <span className="rounded-full bg-flare px-3 py-1 text-[11px] font-semibold uppercase">
                                            {event.genre || 'Konser'}
                                        </span>
                                        <h2 className="mt-3 font-display text-2xl font-bold sm:text-4xl">{event.name}</h2>
                                        <p className="mt-2 text-sm text-muted">
                                            {new Date(event.event_date).toLocaleDateString('id-ID', {
                                                day: 'numeric', month: 'long', year: 'numeric'
                                            })} · {event.venue}, {event.city}
                                        </p>
                                    </div>
                                </div>
                            </Link>
                        </div>
                    );
                })}
            </div>

            {withPoster.length > 1 && (
                <>
                    <button
                        onClick={prev}
                        aria-label="Slide sebelumnya"
                        className="absolute left-2 top-1/2 z-10 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white text-ink shadow-lg transition hover:scale-105 sm:left-[6%] lg:left-[10%]"
                    >
                        ‹
                    </button>
                    <button
                        onClick={next}
                        aria-label="Slide berikutnya"
                        className="absolute right-2 top-1/2 z-10 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white text-ink shadow-lg transition hover:scale-105 sm:right-[6%] lg:right-[10%]"
                    >
                        ›
                    </button>
                    <div className="mt-1 flex items-center justify-center gap-2">
                        {withPoster.map((_, i) => (
                            <button
                                key={i}
                                aria-label={`Ke slide ${i + 1}`}
                                onClick={() => setIndex(i)}
                                className={`h-2 rounded-full transition-all ${i === index ? 'w-6 bg-flare' : 'w-2 bg-white/30 hover:bg-white/50'}`}
                            />
                        ))}
                    </div>
                </>
            )}
        </div>
    );
}

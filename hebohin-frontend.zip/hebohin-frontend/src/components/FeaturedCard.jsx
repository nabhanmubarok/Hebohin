import { Link } from 'react-router-dom';

function formatDate(dateStr) {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('id-ID', {
        day: '2-digit', month: 'long', year: 'numeric'
    });
}

function lowestPrice(ticketTypes) {
    if (!ticketTypes || ticketTypes.length === 0) return null;
    return Math.min(...ticketTypes.map(t => t.price));
}

function isEnded(dateStr) {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return d < today;
}

export default function FeaturedCard({ event }) {
    const price = lowestPrice(event?.ticket_types);
    const ended = isEnded(event?.event_date);

    return (
        <div className="group overflow-hidden rounded-2xl border border-line bg-panel transition hover:border-flare/60 hover:shadow-glow">
            <Link to={`/events/${event.id}`} className="relative block aspect-[16/10] w-full overflow-hidden bg-panel2">
                {event?.poster_url ? (
                    <img src={event.poster_url} alt={event.name} loading="lazy" className={`h-full w-full object-cover transition duration-500 group-hover:scale-105 ${ended ? 'brightness-[0.45] grayscale-[0.3]' : ''}`} />
                ) : (
                    <div className={`flex h-full w-full items-center justify-center bg-gradient-to-br from-flare/25 via-panel2 to-pulse/15 text-6xl font-display font-bold text-white/10 ${ended ? 'brightness-[0.45]' : ''}`}>
                        {event?.name?.[0] ?? '?'}
                    </div>
                )}
                {ended && (
                    <div className="absolute inset-0 flex items-center justify-center">
                        <span className="rounded-full bg-ink/80 px-4 py-1.5 text-xs font-semibold text-white backdrop-blur">Event Berakhir</span>
                    </div>
                )}
            </Link>

            <div className="p-4">
                <h3 className="line-clamp-2 font-display text-base font-bold leading-snug text-white group-hover:text-flare2">
                    {event?.name}
                </h3>
                <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted">
                    <span className="flex items-center gap-1.5">
                        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="4" width="18" height="18" rx="3" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>
                        {formatDate(event?.event_date)}
                    </span>
                    <span className="flex items-center gap-1.5">
                        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11z" /><circle cx="12" cy="10" r="2.5" /></svg>
                        {event?.city || event?.venue || '-'}
                    </span>
                    {(event?.artist || event?.venue) && (
                        <span className="flex items-center gap-1.5">
                            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 11 18-5v12L3 13v-2z" /><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" /></svg>
                            {event?.artist || event?.venue}
                        </span>
                    )}
                </p>

                <div className="mt-4 flex items-center gap-3">
                    <span className="flex-1 text-sm font-semibold text-white">
                        {price !== null ? `Mulai Dari Rp${price.toLocaleString('id-ID')}` : 'Harga belum diumumkan'}
                    </span>
                    <Link
                        to={`/events/${event.id}`}
                        className="flex-1 rounded-lg bg-flare py-2.5 text-center text-xs font-bold uppercase tracking-widest text-white shadow-glow transition hover:bg-flare2"
                    >
                        {ended ? 'Lihat Detail' : 'Beli Tiket'}
                    </Link>
                </div>
            </div>
        </div>
    );
}

import { QRCodeSVG } from 'qrcode.react';

// QR untuk e-tiket: isinya ticket_code unik, ditunjukkan ke petugas di pintu masuk.
export default function TicketQR({ value, size = 120, className = '' }) {
    if (!value) return null;
    return (
        <div className={`bg-white p-2 rounded-lg ${className}`}>
            <QRCodeSVG
                value={value}
                size={size}
                level="M"
                includeMargin={false}
                className="h-auto w-full max-w-full"
            />
        </div>
    );
}

// Peta lokasi venue dari latitude/longitude event.
// Tanpa API key: pakai embed OpenStreetMap + tombol rute ke Google Maps.
// Kalau koordinat belum diisi, tetap tampilkan alamat teks + tombol cari di Maps.
export default function LocationMap({ event }) {
    const lat = event?.latitude;
    const lng = event?.longitude;
    const hasCoords = lat !== null && lat !== undefined && lat !== '' && lng !== null && lng !== undefined && lng !== '' && Number.isFinite(Number(lat)) && Number.isFinite(Number(lng));

    const venue = event?.venue || '';
    const city = event?.city || '';
    const rawAddress = event?.address || '';
    const isAddressUrl = /^https?:\/\//i.test(rawAddress);

    const addressText = [isAddressUrl ? '' : rawAddress, venue, city].filter(Boolean).join(', ');

    if (!hasCoords && !addressText && !isAddressUrl) return null;

    const mapsQuery = hasCoords ? `${lat},${lng}` : (isAddressUrl ? rawAddress : addressText);
    const googleMapsUrl = isAddressUrl && !hasCoords
        ? rawAddress
        : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapsQuery)}`;

    const osmSrc = hasCoords
        ? `https://www.openstreetmap.org/export/embed.html?bbox=${Number(lng) - 0.01},${Number(lat) - 0.01},${Number(lng) + 0.01},${Number(lat) + 0.01}&layer=mapnik&marker=${lat},${lng}`
        : null;

    return (
        <div className="mt-8">
            <h2 className="font-display text-lg font-semibold">Lokasi Event</h2>
            {addressText && <p className="mt-1 text-sm text-muted">{addressText}</p>}

            {osmSrc ? (
                <div className="mt-4 overflow-hidden rounded-3xl border border-line bg-panel">
                    <iframe
                        title={`Peta ${event?.name || 'lokasi event'}`}
                        src={osmSrc}
                        className="h-80 w-full border-0"
                        loading="lazy"
                    />
                </div>
            ) : (
                <div className="mt-4 flex h-40 items-center justify-center rounded-3xl border border-dashed border-line bg-panel p-6 text-center text-sm text-muted">
                    Koordinat belum ditentukan — alamat di atas masih bisa dicari di peta.
                </div>
            )}

            <div className="mt-3 flex flex-wrap gap-2">
                <a
                    href={googleMapsUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full border border-line px-4 py-2 text-xs font-semibold text-muted transition hover:border-flare/60 hover:text-white"
                >
                    Buka di Google Maps
                </a>
                {hasCoords && (
                    <span className="rounded-full bg-white/5 px-3 py-2 font-mono text-[11px] text-muted">
                        {lat}, {lng}
                    </span>
                )}
            </div>
        </div>
    );
}

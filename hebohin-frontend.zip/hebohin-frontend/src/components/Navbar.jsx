import { useEffect, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { logoutUser, getActiveVouchers } from '../api/client';

function formatRemaining(validUntil) {
    if (!validUntil) return 'Tanpa batas waktu';
    const diffMs = new Date(validUntil).getTime() - Date.now();
    if (diffMs <= 0) return 'Sudah berakhir';
    const totalHours = Math.floor(diffMs / 3600000);
    const days = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    const mins = Math.floor((diffMs % 3600000) / 60000);
    if (days > 0) return `Sisa ${days} hari ${hours} jam`;
    if (totalHours > 0) return `Sisa ${totalHours} jam ${mins} menit`;
    return `Sisa ${mins} menit`;
}

function remainingStyle(validUntil) {
    if (!validUntil) return 'bg-pulse/15 text-pulse';
    const diffMs = new Date(validUntil).getTime() - Date.now();
    if (diffMs <= 0) return 'bg-red-500/15 text-red-400';
    if (diffMs <= 24 * 3600000) return 'bg-yellow-500/15 text-yellow-400';
    return 'bg-pulse/15 text-pulse';
}

export default function Navbar() {
    const { user, setUser } = useAuth();
    const navigate = useNavigate();
    const [notifs, setNotifs] = useState([]);
    const [open, setOpen] = useState(false);
    const [copied, setCopied] = useState('');

    useEffect(() => {
        if (!user) return;
        getActiveVouchers()
            .then(res => {
                const now = Date.now();
                const usable = (res.data || []).filter(v => {
                    if (v.valid_from && new Date(v.valid_from).getTime() > now) return false;
                    if (v.valid_until && new Date(v.valid_until).getTime() <= now) return false;
                    return true;
                });
                setNotifs(usable);
            })
            .catch(() => setNotifs([]));
    }, [user]);

    async function handleLogout() {
        await logoutUser();
        setUser(null);
        navigate('/login');
    }

    async function copyCode(code) {
        try {
            await navigator.clipboard.writeText(code);
            setCopied(code);
            setTimeout(() => setCopied(''), 1500);
        } catch {
            setCopied(code);
        }
    }

    const linkClass = ({ isActive }) =>
        `text-sm font-medium transition-colors ${isActive ? 'text-white' : 'text-muted hover:text-white'}`;

    return (
        <header className="sticky top-0 z-40 border-b border-line bg-ink/80 backdrop-blur-md">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
                <Link to="/" className="font-display text-xl font-bold tracking-tight">
                    Heboh<span className="text-flare">In</span>
                </Link>

                <nav className="hidden items-center gap-8 md:flex">
                    <NavLink to="/" end className={linkClass}>Beranda</NavLink>
                    <NavLink to="/explore" className={linkClass}>Jelajahi</NavLink>
                    <NavLink to="/my-tickets" className={linkClass}>Tiket Saya</NavLink>
                    <NavLink to="/favorites" className={linkClass}>Favorit</NavLink>
                    {user?.role === 'admin' && (
                        <NavLink to="/admin" className={linkClass}>Panel Admin</NavLink>
                    )}
                    {user?.role === 'super_admin' && (
                        <NavLink to="/super-admin" className={linkClass}>Panel Super Admin</NavLink>
                    )}
                    {user?.role === 'customer' && (
                        <NavLink to="/become-organizer" className={linkClass}>Jadi Organizer</NavLink>
                    )}
                    {user?.role === 'organizer' && (
                        <NavLink to="/admin" className={linkClass}>Panel Organizer</NavLink>
                    )}
                </nav>

                <div className="flex items-center gap-4">
                    {user && (
                        <div className="relative">
                            <button
                                onClick={() => setOpen(o => !o)}
                                aria-label="Notifikasi voucher"
                                className="relative flex h-9 w-9 items-center justify-center rounded-full border border-line text-muted transition hover:border-flare/60 hover:text-white"
                            >
                                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" /><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0" /></svg>
                                {notifs.length > 0 && (
                                    <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-flare px-1 text-[10px] font-bold text-white">
                                        {notifs.length}
                                    </span>
                                )}
                            </button>

                            {open && (
                                <div className="absolute right-0 top-12 z-50 w-80 overflow-hidden rounded-2xl border border-line bg-panel shadow-glow">
                                    <div className="border-b border-line px-4 py-3">
                                        <p className="text-sm font-semibold text-white">Notifikasi Voucher</p>
                                        <p className="text-[11px] text-muted">{notifs.length} promo aktif buat kamu</p>
                                    </div>
                                    <div className="max-h-80 overflow-y-auto">
                                        {notifs.length === 0 ? (
                                            <p className="p-4 text-xs text-muted">Belum ada voucher aktif. Nanti kalau ada promo, bakal muncul di sini.</p>
                                        ) : (
                                            notifs.map(v => (
                                                <div key={v.code} className="border-b border-line px-4 py-3 last:border-0">
                                                    <div className="flex items-center justify-between gap-2">
                                                        <span className="rounded-md bg-flare/15 px-2 py-1 font-mono text-xs font-bold text-flare2">{v.code}</span>
                                                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${remainingStyle(v.valid_until)}`}>
                                                            {formatRemaining(v.valid_until)}
                                                        </span>
                                                    </div>
                                                    <p className="mt-1.5 text-xs text-muted">
                                                        {v.discount_type === 'percentage'
                                                            ? `Diskon ${v.discount_value}%${v.max_discount ? ` maks Rp${v.max_discount.toLocaleString('id-ID')}` : ''}`
                                                            : `Potongan Rp${v.discount_value.toLocaleString('id-ID')}`}
                                                        {v.min_purchase ? ` · Min. Rp${v.min_purchase.toLocaleString('id-ID')}` : ''}
                                                    </p>
                                                    <p className="mt-0.5 text-[11px] text-muted">
                                                        {v.valid_until
                                                            ? `Berakhir ${new Date(v.valid_until).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })} · ${new Date(v.valid_until).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB`
                                                            : 'Tanpa batas waktu'}
                                                        {` · Sisa kuota ${(v.quota || 0) - (v.used_count || 0)}`}
                                                    </p>
                                                    <button
                                                        onClick={() => copyCode(v.code)}
                                                        className="mt-2 w-full rounded-full border border-line py-1.5 text-xs font-semibold text-white transition hover:border-flare/60"
                                                    >
                                                        {copied === v.code ? 'Kode tersalin ✓' : 'Salin Kode'}
                                                    </button>
                                                </div>
                                            ))
                                        )}
                                    </div>
                                    <Link to="/explore" onClick={() => setOpen(false)} className="block border-t border-line px-4 py-3 text-center text-xs font-semibold text-pulse hover:bg-panel2">
                                        Lihat Event & Gunakan →
                                    </Link>
                                </div>
                            )}
                        </div>
                    )}

                    {user ? (
                        <div className="flex items-center gap-3">
                            <div className="hidden text-right sm:block">
                                <p className="text-xs text-muted">Halo,</p>
                                <p className="text-sm font-semibold leading-none">{user.name?.split(' ')[0]}</p>
                            </div>
                            <button
                                onClick={handleLogout}
                                className="rounded-full border border-line px-4 py-2 text-xs font-semibold text-muted transition hover:border-flare/60 hover:text-white"
                            >
                                Keluar
                            </button>
                        </div>
                    ) : (
                        <Link
                            to="/login"
                            className="rounded-full bg-flare px-5 py-2 text-sm font-semibold text-white shadow-glow transition hover:bg-flare2"
                        >
                            Masuk
                        </Link>
                    )}
                </div>
            </div>
        </header>
    );
}

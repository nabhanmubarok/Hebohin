import { Link } from 'react-router-dom';

function formatDate(dateStr) {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('id-ID', {
        day: '2-digit', month: 'long', year: 'numeric'
    });
}

function lowestPrice(ticketTypes) {
    if (!ticketTypes || ticketTypes.length === 0) return null;
    return Math.min(...ticketTypes.map(t => t.price));
}

function isEnded(dateStr) {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return d < today;
}

function PinIcon() {
    return (
        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11z" /><circle cx="12" cy="10" r="2.5" /></svg>
    );
}

function CalendarIcon() {
    return (
        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="3" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>
    );
}

function SpeakerIcon() {
    return (
        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 11 18-5v12L3 13v-2z" /><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" /></svg>
    );
}

export default function ShowCard({ event }) {
    const price = lowestPrice(event.ticket_types);
    const ended = isEnded(event.event_date);
    const city = event.city || event.venue || '-';
    const presenter = event.artist || event.venue || '';

    return (
        <div className="group flex flex-col overflow-hidden rounded-2xl border border-line bg-panel transition hover:border-flare/60 hover:shadow-glow">
            <Link to={`/events/${event.id}`} className="relative block aspect-[4/5] w-full overflow-hidden bg-panel2">
                {event.poster_url ? (
                    <img src={event.poster_url} alt={event.name} loading="lazy" className={`h-full w-full object-cover transition duration-500 group-hover:scale-105 ${ended ? 'brightness-[0.45] grayscale-[0.3]' : ''}`} />
                ) : (
                    <div className={`flex h-full w-full items-center justify-center bg-gradient-to-br from-flare/25 via-panel2 to-pulse/15 text-5xl font-display font-bold text-white/10 ${ended ? 'brightness-[0.45]' : ''}`}>
                        {event.name?.[0] ?? '?'}
                    </div>
                )}
                {ended && (
                    <div className="absolute inset-0 flex items-center justify-center">
                        <span className="rounded-full bg-ink/80 px-4 py-1.5 text-xs font-semibold text-white backdrop-blur">Event Berakhir</span>
                    </div>
                )}
                <span className="absolute left-3 top-3 rounded-full bg-ink/70 px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-pulse backdrop-blur">
                    {event.genre || 'Konser'}
                </span>
            </Link>

            <div className="flex flex-1 flex-col p-4">
                <h3 className="line-clamp-2 min-h-[2.5rem] font-display text-sm font-bold leading-snug text-white group-hover:text-flare2">
                    {event.name}
                </h3>

                <div className="mt-3 space-y-1.5 text-xs text-muted">
                    <p className="flex items-center gap-1.5"><CalendarIcon /> {formatDate(event.event_date)}</p>
                    <p className="flex items-center gap-1.5"><PinIcon /> {city}</p>
                    {presenter && <p className="flex items-center gap-1.5 truncate"><SpeakerIcon /> <span className="truncate">{presenter}</span></p>}
                </div>

                <Link
                    to={`/events/${event.id}`}
                    className="mt-4 block w-full rounded-lg bg-flare py-2.5 text-center text-xs font-bold uppercase tracking-widest text-white shadow-glow transition hover:bg-flare2"
                >
                    {ended ? 'Lihat Detail' : 'Beli Tiket'}
                </Link>
                {price !== null && !ended && (
                    <p className="mt-2 text-center text-[11px] text-muted">Mulai Rp{price.toLocaleString('id-ID')}</p>
                )}
            </div>
        </div>
    );
}

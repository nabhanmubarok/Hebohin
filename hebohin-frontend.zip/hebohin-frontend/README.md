# HebohIn Frontend

Frontend React (Vite + Tailwind) untuk aplikasi pembelian tiket konser HebohIn, terhubung ke backend Express yang sudah dibuat sebelumnya.

## Desain

Mengikuti arah visual "Pulse" — dark theme dengan aksen pink (`#FF3D7A`) dan teal (`#2FE6D0`), font display **Space Grotesk** untuk judul dan **Inter** untuk teks. Kartu tiket memakai efek "notch" (lubang di sisi kiri-kanan) untuk memberi kesan tiket sungguhan.

## Struktur Folder

```
hebohin-frontend/
├── src/
│   ├── api/client.js        # koneksi ke backend Express
│   ├── context/AuthContext.jsx
│   ├── components/
│   │   ├── Navbar.jsx
│   │   └── EventCard.jsx
│   ├── pages/
│   │   ├── Dashboard.jsx    # halaman beranda (mirip referensi)
│   │   ├── Explore.jsx      # listing & pencarian event
│   │   ├── EventDetail.jsx  # detail event + checkout + voucher
│   │   ├── MyTickets.jsx    # riwayat pesanan & e-tiket
│   │   ├── Favorites.jsx    # event favorit (client-side only)
│   │   ├── Login.jsx
│   │   ├── Register.jsx
│   │   └── VerifyOtp.jsx
│   ├── App.jsx
│   └── main.jsx
├── tailwind.config.js
└── package.json
```

## Cara Menjalankan

1. Pastikan **backend Express sudah jalan** di `http://localhost:3000`
2. Install dependency:
   ```bash
   npm install
   ```
3. Copy `.env.example` jadi `.env`, sesuaikan `VITE_API_URL` kalau backend jalan di port/host lain
4. Jalankan:
   ```bash
   npm run dev
   ```
5. Buka `http://localhost:5173`

## Catatan Penting

- **Session Cookie**: frontend memakai `withCredentials: true` supaya cookie session dari backend ikut terkirim. Pastikan `FRONTEND_URL` di `.env` backend kamu diisi `http://localhost:5173` supaya CORS tidak diblokir.
- **Fitur Favorit**: backend belum punya endpoint untuk fitur ini, jadi sementara disimpan di `localStorage` browser (per-device, bukan per-akun). Kalau mau permanen di database, perlu tabel `favorites` baru di Supabase + endpoint terkait.
- **QR Code Tiket**: saat ini kode tiket (`ticket_code`) ditampilkan sebagai teks. Untuk menampilkan QR code visual asli, bisa tambahkan library seperti `qrcode.react` di halaman `MyTickets.jsx`.
- **Google Login**: tombol "Lanjutkan dengan Google" akan redirect ke backend (`/auth/google`), yang nanti redirect balik ke `FRONTEND_URL` setelah sukses.

## Alur Pengguna

1. Registrasi → verifikasi OTP → login (atau langsung login via Google)
2. Jelajahi event di halaman **Explore**
3. Klik event → pilih kategori tiket → (opsional) masukkan kode voucher → **Beli Tiket**
4. Diarahkan ke halaman pembayaran Midtrans Snap
5. Setelah bayar, tiket otomatis muncul di halaman **Tiket Saya** (setelah webhook diproses backend)

## Panel Admin & Super Admin

Setelah role user di Supabase diubah jadi `admin` atau `super_admin` (lihat `sql/add_super_admin_role.sql` di backend), link **"Panel Admin"** otomatis muncul di navbar setelah login.

**Admin** bisa akses:
- `/admin` — Ringkasan statistik (pendapatan, tiket terjual, grafik 7 hari)
- `/admin/events` — Tambah/ubah/hapus event & kategori tiket
- `/admin/vouchers` — Buat/ubah/hapus kode voucher
- `/admin/orders` — Lihat semua transaksi dari semua customer

**Super Admin** dapat tambahan:
- `/admin/users` — Naikkan customer jadi admin, turunkan admin, atau hapus akun

## Cara Bikin Akun Super Admin Pertama

1. Register akun biasa lewat aplikasi seperti biasa
2. Buka Supabase → Table Editor → tabel `users`
3. Ubah kolom `role` akun tersebut jadi `super_admin` secara manual
4. Login ulang di frontend — link "Panel Admin" akan muncul, dan menu "Kelola Admin" bisa dipakai untuk menaikkan admin lain lewat UI (tidak perlu ubah manual lagi setelah ini)


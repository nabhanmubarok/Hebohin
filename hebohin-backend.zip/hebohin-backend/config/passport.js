const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const supabase = require('./supabase');

passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: '/auth/google/callback'
  },
  async (accessToken, refreshToken, profile, done) => {
    try {
        const email = profile.emails[0].value;

        // Cek apakah user dengan email ini sudah ada
        const { data: existingUser } = await supabase
            .from('users')
            .select('*')
            .eq('email', email)
            .single();

        if (existingUser) {
            return done(null, existingUser);
        }

        // Kalau belum ada, buat user baru
        const { data: newUser, error } = await supabase
            .from('users')
            .insert({
                name: profile.displayName,
                email: email,
                google_id: profile.id,
                photo_url: profile.photos?.[0]?.value,
                is_verified: true, // email dari Google dianggap sudah terverifikasi
                role: 'customer'
            })
            .select()
            .single();

        if (error) return done(error, null);

        return done(null, newUser);
    } catch (error) {
        return done(error, null);
    }
  }
));

passport.serializeUser((user, done) => done(null, user.id));

passport.deserializeUser(async (id, done) => {
    try {
        const { data, error } = await supabase
            .from('users')
            .select('*')
            .eq('id', id)
            .single();

        if (error) return done(error, null);
        done(null, data);
    } catch (error) {
        done(error, null);
    }
});

module.exports = passport;

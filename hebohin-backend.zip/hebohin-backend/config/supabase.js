const { createClient } = require('@supabase/supabase-js');

// Service role key dipakai di backend supaya bisa bypass Row Level Security (RLS)
// JANGAN pernah expose service role key ini ke frontend/client
const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
);

module.exports = supabase;

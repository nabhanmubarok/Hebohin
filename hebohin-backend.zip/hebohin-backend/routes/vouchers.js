const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const { isAuthenticated, isAdmin } = require('../middleware/checkRole');

// Buat voucher baru (admin)
router.post('/', isAuthenticated, isAdmin, async (req, res) => {
    try {
        const {
            code, discountType, discountValue,
            maxDiscount, minPurchase, quota,
            validFrom, validUntil
        } = req.body;

        if (!code || !discountType || !discountValue) {
            return res.status(400).json({ message: 'Kode, tipe diskon, dan nilai diskon wajib diisi' });
        }

        if (discountType === 'percentage' && (discountValue < 1 || discountValue > 100)) {
            return res.status(400).json({ message: 'Diskon persentase harus antara 1-100' });
        }

        const { data, error } = await supabase
            .from('vouchers')
            .insert({
                code: code.toUpperCase(),
                discount_type: discountType,
                discount_value: discountValue,
                max_discount: maxDiscount || null,
                min_purchase: minPurchase || 0,
                quota: quota || 1,
                valid_from: validFrom || new Date(),
                valid_until: validUntil || null
            })
            .select()
            .single();

        if (error) {
            if (error.code === '23505') {
                return res.status(400).json({ message: 'Kode voucher sudah ada, gunakan kode lain' });
            }
            throw error;
        }

        res.status(201).json({ message: 'Voucher berhasil dibuat', voucher: data });
    } catch (error) {
        res.status(500).json({ message: 'Gagal membuat voucher', error: error.message });
    }
});

// Lihat semua voucher (admin)
router.get('/', isAuthenticated, isAdmin, async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('vouchers')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil data voucher', error: error.message });
    }
});

// Voucher aktif buat notifikasi user (semua user login bisa lihat, nanti tampil di bell Navbar)
// Yang tampil HARUS yang benar-benar bisa dipakai sekarang: sudah mulai (valid_from <= sekarang)
// dan belum berakhir (valid_until > sekarang). Kalau cuma filter valid_until, voucher yang
// valid_from-nya masih di depan akan muncul di bell tapi gagal di /validate ("belum berlaku").
router.get('/active', isAuthenticated, async (req, res) => {
    try {
        const nowDate = new Date();
        const now = nowDate.toISOString();
        const { data, error } = await supabase
            .from('vouchers')
            .select('code, discount_type, discount_value, max_discount, min_purchase, quota, used_count, is_active, valid_from, valid_until')
            .eq('is_active', true)
            .or(`valid_until.is.null,valid_until.gt.${now}`)
            .order('valid_until', { ascending: true, nullsFirst: false });

        if (error) throw error;
        const active = (data || []).filter(v => {
            if ((v.used_count || 0) >= (v.quota ?? 0)) return false;
            if (v.valid_from && new Date(v.valid_from) > nowDate) return false;
            if (v.valid_until && new Date(v.valid_until) <= nowDate) return false;
            return true;
        });
        res.json(active);
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil voucher aktif', error: error.message });
    }
});

// Update voucher (admin)
router.put('/:id', isAuthenticated, isAdmin, async (req, res) => {
    try {
        const {
            discountType, discountValue, maxDiscount,
            minPurchase, quota, isActive, validFrom, validUntil
        } = req.body;

        const { data, error } = await supabase
            .from('vouchers')
            .update({
                discount_type: discountType,
                discount_value: discountValue,
                max_discount: maxDiscount,
                min_purchase: minPurchase,
                quota,
                is_active: isActive,
                valid_from: validFrom,
                valid_until: validUntil
            })
            .eq('id', req.params.id)
            .select()
            .single();

        if (error) throw error;
        res.json({ message: 'Voucher berhasil diupdate', voucher: data });
    } catch (error) {
        res.status(500).json({ message: 'Gagal update voucher', error: error.message });
    }
});

// Hapus voucher (admin)
router.delete('/:id', isAuthenticated, isAdmin, async (req, res) => {
    try {
        const { error } = await supabase.from('vouchers').delete().eq('id', req.params.id);
        if (error) throw error;
        res.json({ message: 'Voucher berhasil dihapus' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal hapus voucher', error: error.message });
    }
});

// Cek validitas voucher (dipanggil customer sebelum checkout, untuk preview diskon)
router.post('/validate', isAuthenticated, async (req, res) => {
    try {
        const { code, totalAmount } = req.body;

        const { data: voucher, error } = await supabase
            .from('vouchers')
            .select('*')
            .eq('code', code.toUpperCase())
            .single();

        if (error || !voucher) {
            return res.status(404).json({ valid: false, message: 'Kode voucher tidak ditemukan' });
        }

        if (!voucher.is_active) {
            return res.status(400).json({ valid: false, message: 'Voucher sudah tidak aktif' });
        }

        if (voucher.used_count >= voucher.quota) {
            return res.status(400).json({ valid: false, message: 'Kuota voucher sudah habis' });
        }

        const now = new Date();
        if (voucher.valid_until && now > new Date(voucher.valid_until)) {
            return res.status(400).json({ valid: false, message: 'Voucher sudah kadaluarsa' });
        }
        if (now < new Date(voucher.valid_from)) {
            return res.status(400).json({ valid: false, message: 'Voucher belum berlaku' });
        }

        if (totalAmount < voucher.min_purchase) {
            return res.status(400).json({
                valid: false,
                message: `Minimal belanja Rp${voucher.min_purchase.toLocaleString('id-ID')} untuk pakai voucher ini`
            });
        }

        const discountAmount = calculateDiscount(voucher, totalAmount);

        res.json({
            valid: true,
            message: 'Voucher valid',
            discountAmount,
            finalAmount: totalAmount - discountAmount
        });
    } catch (error) {
        res.status(500).json({ message: 'Gagal validasi voucher', error: error.message });
    }
});

// Fungsi hitung nominal diskon berdasarkan tipe voucher
function calculateDiscount(voucher, totalAmount) {
    let discount = 0;

    if (voucher.discount_type === 'percentage') {
        discount = Math.floor(totalAmount * (voucher.discount_value / 100));
        if (voucher.max_discount && discount > voucher.max_discount) {
            discount = voucher.max_discount;
        }
    } else if (voucher.discount_type === 'fixed') {
        discount = voucher.discount_value;
    }

    // Diskon tidak boleh melebihi total belanja
    if (discount > totalAmount) discount = totalAmount;

    return discount;
}

module.exports = { router, calculateDiscount };
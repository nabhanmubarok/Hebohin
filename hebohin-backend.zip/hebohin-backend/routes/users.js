const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const { isAuthenticated, isSuperAdmin } = require('../middleware/checkRole');

// Lihat semua user (super admin)
router.get('/', isAuthenticated, isSuperAdmin, async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('users')
            .select('id, name, email, role, is_verified, created_at')
            .order('created_at', { ascending: false });

        if (error) throw error;
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil data user', error: error.message });
    }
});

// Ubah role user, misal customer -> admin, atau admin -> super_admin (super admin)
router.put('/:id/role', isAuthenticated, isSuperAdmin, async (req, res) => {
    try {
        const { role } = req.body;
        const allowedRoles = ['customer', 'admin', 'super_admin'];

        if (!allowedRoles.includes(role)) {
            return res.status(400).json({ message: 'Role tidak valid' });
        }

        if (req.params.id === req.user.id && role !== 'super_admin') {
            return res.status(400).json({ message: 'Tidak bisa mengubah role akun sendiri' });
        }

        const { data, error } = await supabase
            .from('users')
            .update({ role })
            .eq('id', req.params.id)
            .select('id, name, email, role')
            .single();

        if (error) throw error;
        res.json({ message: 'Role user berhasil diubah', user: data });
    } catch (error) {
        res.status(500).json({ message: 'Gagal ubah role user', error: error.message });
    }
});

// Hapus user (super admin)
router.delete('/:id', isAuthenticated, isSuperAdmin, async (req, res) => {
    try {
        if (req.params.id === req.user.id) {
            return res.status(400).json({ message: 'Tidak bisa menghapus akun sendiri' });
        }

        const { error } = await supabase.from('users').delete().eq('id', req.params.id);
        if (error) throw error;
        res.json({ message: 'User berhasil dihapus' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal hapus user', error: error.message });
    }
});

module.exports = router;
const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const { isAuthenticated, isEventManager } = require('../middleware/checkRole');

router.get('/summary', isAuthenticated, isEventManager, async (req, res) => {
    try {
        const isOrganizer = req.user.role === 'organizer';

        // Ambil daftar event, dibatasi ke milik sendiri kalau organizer
        let eventsQuery = supabase.from('events').select('id', { count: 'exact' });
        if (isOrganizer) eventsQuery = eventsQuery.eq('organizer_id', req.user.id);
        const { data: eventRows, count: totalEvents, error: eventsError } = await eventsQuery;
        if (eventsError) throw eventsError;

        const eventIds = eventRows.map(e => e.id);

        // Organizer yang belum punya event sama sekali, langsung balikin nol semua
        if (isOrganizer && eventIds.length === 0) {
            const emptyDays = [...Array(7)].map((_, i) => {
                const d = new Date();
                d.setDate(d.getDate() - (6 - i));
                return { date: d.toISOString().slice(0, 10), total: 0 };
            });
            return res.json({
                totalRevenue: 0, totalOrders: 0, totalEvents: 0,
                totalUsers: 0, totalTicketsSold: 0, revenueByDay: emptyDays
            });
        }

        // Ambil order, dibatasi ke event milik sendiri kalau organizer
        let ordersQuery = supabase.from('orders').select('id, total_amount, status, created_at, event_id');
        if (isOrganizer) ordersQuery = ordersQuery.in('event_id', eventIds);
        const { data: allOrders, error: ordersError } = await ordersQuery;
        if (ordersError) throw ordersError;

        const paid = allOrders.filter(o => o.status === 'paid');
        const totalRevenue = paid.reduce((sum, o) => sum + o.total_amount, 0);

        // Hitung tiket terjual, hanya dari order yang lunas dan sesuai scope
        let totalTicketsSold = 0;
        if (paid.length > 0) {
            const paidOrderIds = paid.map(o => o.id);
            const { count } = await supabase
                .from('tickets')
                .select('*', { count: 'exact', head: true })
                .in('order_id', paidOrderIds);
            totalTicketsSold = count || 0;
        }

        // Total customer cuma relevan untuk admin/super admin, organizer tidak perlu lihat ini
        let totalUsers = 0;
        if (!isOrganizer) {
            const { count } = await supabase
                .from('users')
                .select('*', { count: 'exact', head: true })
                .eq('role', 'customer');
            totalUsers = count || 0;
        }

        // Pendapatan 7 hari terakhir
        const last7Days = [...Array(7)].map((_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - (6 - i));
            return d.toISOString().slice(0, 10);
        });

        const revenueByDay = last7Days.map(date => {
            const total = paid
                .filter(o => o.created_at?.slice(0, 10) === date)
                .reduce((sum, o) => sum + o.total_amount, 0);
            return { date, total };
        });

        res.json({
            totalRevenue,
            totalOrders: paid.length,
            totalEvents: totalEvents || eventIds.length,
            totalUsers,
            totalTicketsSold,
            revenueByDay
        });
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil statistik', error: error.message });
    }
});

module.exports = router;
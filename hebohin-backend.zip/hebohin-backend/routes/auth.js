const express = require('express');
const bcrypt = require('bcrypt');
const passport = require('passport');
const router = express.Router();
const supabase = require('../config/supabase');
const { generateOTP, sendOTPEmail } = require('../utils/otp');

// Register manual (email + password)
router.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({ message: 'Nama, email, dan password wajib diisi' });
        }

        const { data: existing } = await supabase
            .from('users')
            .select('id')
            .eq('email', email)
            .single();

        if (existing) {
            return res.status(400).json({ message: 'Email sudah terdaftar' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const { data: newUser, error } = await supabase
            .from('users')
            .insert({
                name,
                email,
                password: hashedPassword,
                role: 'customer',
                is_verified: false
            })
            .select('id, name, email')
            .single();

        if (error) throw error;

        // Kirim OTP setelah register
        const otp = generateOTP();
        const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 menit

        await supabase
            .from('users')
            .update({ otp_code: otp, otp_expires_at: expiresAt })
            .eq('id', newUser.id);

        await sendOTPEmail(email, otp);

        res.status(201).json({
            message: 'Registrasi berhasil, cek email untuk kode OTP',
            user: newUser
        });
    } catch (error) {
        res.status(500).json({ message: 'Gagal registrasi', error: error.message });
    }
});

// Login manual (email + password)
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const { data: user, error } = await supabase
            .from('users')
            .select('*')
            .eq('email', email)
            .single();

        if (error || !user || !user.password) {
            return res.status(401).json({ message: 'Email atau password salah' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Email atau password salah' });
        }

        if (!user.is_verified) {
            return res.status(403).json({ message: 'Akun belum diverifikasi, cek OTP di email' });
        }

        req.login(user, (err) => {
            if (err) return res.status(500).json({ message: 'Gagal membuat sesi login' });
            res.json({
                message: 'Login berhasil',
                user: { id: user.id, name: user.name, email: user.email, role: user.role }
            });
        });
    } catch (error) {
        res.status(500).json({ message: 'Gagal login', error: error.message });
    }
});

// Kirim ulang OTP
router.post('/send-otp', async (req, res) => {
    try {
        const { email } = req.body;

        const { data: user } = await supabase
            .from('users')
            .select('id')
            .eq('email', email)
            .single();

        if (!user) {
            return res.status(404).json({ message: 'Email tidak ditemukan' });
        }

        const otp = generateOTP();
        const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

        await supabase
            .from('users')
            .update({ otp_code: otp, otp_expires_at: expiresAt })
            .eq('id', user.id);

        await sendOTPEmail(email, otp);

        res.json({ message: 'OTP terkirim ke email' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal kirim OTP', error: error.message });
    }
});

// Verifikasi OTP
router.post('/verify-otp', async (req, res) => {
    try {
        const { email, otp } = req.body;

        const { data: user, error } = await supabase
            .from('users')
            .select('id, otp_code, otp_expires_at')
            .eq('email', email)
            .single();

        if (error || !user) {
            return res.status(404).json({ message: 'Email tidak ditemukan' });
        }

        const isExpired = new Date() > new Date(user.otp_expires_at);

        if (user.otp_code !== otp || isExpired) {
            return res.status(400).json({ message: 'Kode OTP salah atau sudah kadaluarsa' });
        }

        await supabase
            .from('users')
            .update({ is_verified: true, otp_code: null, otp_expires_at: null })
            .eq('id', user.id);

        res.json({ message: 'Verifikasi berhasil, silakan login' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal verifikasi OTP', error: error.message });
    }
});

// Login via Google
router.get('/google',
    passport.authenticate('google', { scope: ['profile', 'email'] })
);

router.get('/google/callback',
    passport.authenticate('google', { failureRedirect: '/login-failed' }),
    (req, res) => {
        // Sukses login, redirect ke frontend
        res.redirect(process.env.FRONTEND_URL || 'http://localhost:5173');
    }
);

// Logout
router.post('/logout', (req, res) => {
    req.logout(() => res.json({ message: 'Logout berhasil' }));
});

// Ambil data user yang sedang login
router.get('/me', (req, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
        return res.status(401).json({ message: 'Belum login' });
    }
    const { id, name, email, role, photo_url } = req.user;
    res.json({ id, name, email, role, photo_url });
});

module.exports = router;

const express = require('express');
const multer = require('multer');
const router = express.Router();
const supabase = require('../config/supabase');
const { isAuthenticated, isEventManager } = require('../middleware/checkRole');

// Simpan file di memory dulu (bukan disk), langsung diteruskan ke Supabase Storage
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 }, // maks 5MB
    fileFilter: (req, file, cb) => {
        if (!file.mimetype.startsWith('image/')) {
            return cb(new Error('File harus berupa gambar'));
        }
        cb(null, true);
    }
});

router.post('/event-poster', isAuthenticated, isEventManager, upload.single('image'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ message: 'Tidak ada file yang diupload' });
        }

        const fileExt = req.file.originalname.split('.').pop();
        const fileName = `event-${Date.now()}.${fileExt}`;

        const { error } = await supabase.storage
            .from('event-posters')
            .upload(fileName, req.file.buffer, {
                contentType: req.file.mimetype
            });

        if (error) throw error;

        // Ambil URL publik dari file yang barusan diupload
        const { data: publicUrlData } = supabase.storage
            .from('event-posters')
            .getPublicUrl(fileName);

        res.json({ url: publicUrlData.publicUrl });
    } catch (error) {
        res.status(500).json({ message: 'Gagal upload gambar', error: error.message });
    }
});

module.exports = router;
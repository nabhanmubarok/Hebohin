const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const { isAuthenticated, isEventManager } = require('../middleware/checkRole');
const { validateLayout, buildSeatRows, insertSeats } = require('../utils/seats');

// ---------- Helper ----------

function toCoordinate(value) {
    if (value === undefined) return undefined;          // tidak dikirim -> jangan diubah
    if (value === null || value === '') return null;    // dikosongkan
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
}

// Deteksi error PostgREST "kolom tidak ada di schema" misal:
// "Could not find the 'address' column of 'events' in the schema cache"
function missingColumnFromError(error) {
    const msg = error?.message || '';
    const m = msg.match(/Could not find the '([^']+)' column/i);
    if (m) return m[1];
    if (/does not exist|schema cache/i.test(msg)) return '__unknown__';
    return null;
}

// Jalankan fn, dan kalau gagal karena kolom belum ada di DB (migrasi belum jalan),
// hapus kolom itu dari payload lalu coba lagi. Ditujukan supaya update/create event
// tetap jalan dengan skema lama (sesuai ERD), dan fitur maps/seat otomatis aktif
// setelah kolom ditambahkan di Supabase.
async function withMissingColumnFallback(payload, fn) {
    let current = { ...payload };
    for (let attempt = 0; attempt < 8; attempt++) {
        const result = await fn(current);
        if (!result.error) return result;
        const col = missingColumnFromError(result.error);
        if (!col || !(col in current)) return result; // bukan masalah kolom hilang -> balikin error apa adanya
        if (col === '__unknown__') {
            // Hapus semua kolom opsional yang belum tentu ada
            delete current.address;
            delete current.latitude;
            delete current.longitude;
            delete current.color;
            delete current.has_seating;
            delete current.seat_rows;
            delete current.seats_per_row;
            continue;
        }
        delete current[col];
    }
    return fn(current);
}

// Rapikan data kategori tiket dari frontend. Balikin { data } atau { error }
// Terima dua gaya penamaan: camelCase dari form (hasSeating/seatRows/seatsPerRow)
// dan snake_case mentah dari DB (has_seating/seat_rows/seats_per_row).
function normalizeTicketType(t) {
    const category = String(t.category || '').trim();
    if (!category) return { error: 'Nama kategori tiket tidak boleh kosong' };

    const price = Number(t.price);
    if (!Number.isFinite(price) || price < 0) {
        return { error: `Harga kategori ${category} tidak valid` };
    }

    const hasSeating = Boolean(t.hasSeating ?? t.has_seating);
    const color = t.color ? String(t.color).slice(0, 20) : null;

    if (hasSeating) {
        const rows = Number(t.seatRows ?? t.seat_rows);
        const perRow = Number(t.seatsPerRow ?? t.seats_per_row);
        const layoutError = validateLayout(rows, perRow);
        if (layoutError) return { error: `${category}: ${layoutError}` };
        return {
            data: {
                id: t.id,
                category, price, color, hasSeating,
                seatRows: rows, seatsPerRow: perRow, stock: rows * perRow
            }
        };
    }

    const stock = Number(t.stock);
    if (!Number.isInteger(stock) || stock < 0) {
        return { error: `Stok kategori ${category} tidak valid` };
    }
    return { data: { id: t.id, category, price, color, hasSeating, stock } };
}

// Simpan 1 kategori tiket baru, lalu buatkan kursinya kalau pakai kursi
async function insertTicketType(eventId, t) {
    const payload = {
        event_id: eventId,
        category: t.category,
        price: t.price,
        stock: t.stock,
        color: t.color,
        has_seating: t.hasSeating,
        seat_rows: t.hasSeating ? t.seatRows : null,
        seats_per_row: t.hasSeating ? t.seatsPerRow : null
    };
    const { data: created, error } = await withMissingColumnFallback(payload, (p) =>
        supabase.from('ticket_types').insert(p).select().single()
    );
    if (error) throw error;

    if (t.hasSeating) {
        try {
            const seatRows = buildSeatRows({
                eventId,
                ticketTypeId: created.id,
                rows: t.seatRows,
                perRow: t.seatsPerRow
            });
            await insertSeats(supabase, seatRows);
        } catch (seatErr) {
            // Kalau tabel seats belum dibuat (migrasi belum jalan), jangan gagalkan semuanya
            console.warn('[insertTicketType] seats tidak dibuat:', seatErr.message);
        }
    }
    return created;
}

async function assertOwnership(req, eventId) {
    if (req.user.role !== 'organizer') return true;
    const { data: existing } = await supabase
        .from('events').select('organizer_id').eq('id', eventId).single();
    return Boolean(existing && existing.organizer_id === req.user.id);
}

// ---------- Publik ----------

// Ambil semua event beserta kategori tiketnya
router.get('/', async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('events')
            .select('*, ticket_types(*)')
            .eq('is_active', true)
            .order('event_date', { ascending: true });

        if (error) throw error;
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil data event', error: error.message });
    }
});

// Daftar event milik organizer (admin/super admin lihat semuanya, termasuk yang nonaktif)
router.get('/my-events/list', isAuthenticated, isEventManager, async (req, res) => {
    try {
        let query = supabase.from('events').select('*, ticket_types(*)').order('created_at', { ascending: false });

        if (req.user.role === 'organizer') {
            query = query.eq('organizer_id', req.user.id);
        }

        const { data, error } = await query;
        if (error) throw error;
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil event', error: error.message });
    }
});

// Ambil detail 1 event
router.get('/:id', async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('events')
            .select('*, ticket_types(*)')
            .eq('id', req.params.id)
            .single();

        if (error) throw error;
        res.json(data);
    } catch (error) {
        res.status(404).json({ message: 'Event tidak ditemukan' });
    }
});

// Denah kursi 1 event. Kursi yang masa tahannya sudah lewat dihitung tersedia lagi.
router.get('/:id/seats', async (req, res) => {
    try {
        const now = Date.now();
        const all = [];
        // Supabase membatasi 1000 baris per request, jadi ambil bertahap
        for (let from = 0; ; from += 1000) {
            const { data, error } = await supabase
                .from('seats')
                .select('id, ticket_type_id, row_label, seat_number, label, status, reserved_until')
                .eq('event_id', req.params.id)
                .order('ticket_type_id')
                .order('row_label')
                .order('seat_number')
                .range(from, from + 999);
            if (error) {
                // Tabel seats belum dibuat (migrasi belum jalan) -> balikin kosong, bukan 500
                if (/does not exist|schema cache|Could not find/i.test(error.message || '')) {
                    return res.json([]);
                }
                throw error;
            }
            all.push(...data);
            if (data.length < 1000) break;
        }

        const seats = all.map(s => {
            const holdExpired = s.status === 'reserved' && s.reserved_until && new Date(s.reserved_until).getTime() < now;
            return {
                id: s.id,
                ticketTypeId: s.ticket_type_id,
                row: s.row_label,
                number: s.seat_number,
                label: s.label,
                status: holdExpired ? 'available' : s.status
            };
        });

        res.json(seats);
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil denah kursi', error: error.message });
    }
});

// ---------- Kelola event (organizer / admin) ----------

// Buat event baru
router.post('/', isAuthenticated, isEventManager, async (req, res) => {
    let createdEventId = null;
    try {
        const {
            name, artist, venue, city, address, latitude, longitude,
            eventDate, description, genre, posterUrl, isActive, is_active, ticketTypes
        } = req.body;

        // Validasi kategori tiket dulu sebelum ada data yang tersimpan
        const normalized = [];
        for (const t of ticketTypes || []) {
            const result = normalizeTicketType(t);
            if (result.error) return res.status(400).json({ message: result.error });
            normalized.push(result.data);
        }

        // Kalau yang buat organizer, catat sebagai pemilik event. Admin/super admin tidak terikat kepemilikan.
        const organizerId = req.user.role === 'organizer' ? req.user.id : null;

        const eventPayload = {
            name, artist, venue, city, address,
            latitude: toCoordinate(latitude) ?? null,
            longitude: toCoordinate(longitude) ?? null,
            event_date: eventDate,
            description, genre,
            poster_url: posterUrl,
            is_active: (isActive ?? is_active) !== undefined ? Boolean(isActive ?? is_active) : undefined,
            organizer_id: organizerId
        };
        // Bersihkan undefined di level atas? undefined memang sengaja untuk is_active/opsional
        // biar PostgREST nggak kirim null yang salah. Tapi address/lat/lng kita biarkan,
        // fallback akan buang kalau kolomnya belum ada di DB.
        if (eventPayload.is_active === undefined) delete eventPayload.is_active;

        const { data: event, error } = await withMissingColumnFallback(eventPayload, (p) =>
            supabase.from('events').insert(p).select().single()
        );

        if (error) throw error;
        createdEventId = event.id;

        for (const t of normalized) {
            await insertTicketType(event.id, t);
        }

        res.status(201).json({ message: 'Event berhasil dibuat', event });
    } catch (error) {
        // Jangan tinggalkan event setengah jadi kalau kategori/kursi gagal disimpan
        if (createdEventId) {
            await supabase.from('events').delete().eq('id', createdEventId);
        }
        res.status(500).json({ message: 'Gagal membuat event', error: error.message });
    }
});

// Update event
router.put('/:id', isAuthenticated, isEventManager, async (req, res) => {
    try {
        if (!(await assertOwnership(req, req.params.id))) {
            return res.status(403).json({ message: 'Kamu tidak punya akses ke event ini' });
        }

        const body = req.body || {};
        const {
            name, artist, venue, city, address, latitude, longitude,
            eventDate, description, genre, posterUrl, isActive, is_active, ticketTypes
        } = body;
        const isActiveValue = isActive !== undefined ? isActive : is_active;

        // Siapkan perubahan kategori tiket lebih dulu supaya error validasi tidak setengah jalan
        let toInsert = [], toUpdate = [], toDelete = [];
        if (Array.isArray(ticketTypes)) {
            const { data: existingRaw, error: existingError } = await supabase
                .from('ticket_types').select('*').eq('event_id', req.params.id);
            if (existingError) throw existingError;
            const existing = existingRaw || [];

            const existingMap = new Map(existing.map(t => [t.id, t]));
            const keptIds = new Set();

            for (const raw of ticketTypes) {
                const result = normalizeTicketType(raw);
                if (result.error) return res.status(400).json({ message: result.error });
                const t = result.data;

                if (t.id && existingMap.has(t.id)) {
                    keptIds.add(t.id);
                    const current = existingMap.get(t.id);
                    // Tata letak kursi tidak bisa diubah setelah dibuat, supaya kursi yang sudah terjual aman
                    const patch = { category: t.category, price: t.price, color: t.color };
                    if (!current.has_seating) {
                        if (t.hasSeating) {
                            return res.status(400).json({ message: `${t.category}: kategori yang sudah dibuat tidak bisa diubah jadi bernomor kursi` });
                        }
                        if (t.stock < (current.sold || 0)) {
                            return res.status(400).json({ message: `Stok ${t.category} tidak boleh kurang dari tiket yang sudah terjual (${current.sold})` });
                        }
                        patch.stock = t.stock;
                    }
                    toUpdate.push({ id: t.id, patch });
                } else {
                    toInsert.push(t);
                }
            }

            for (const current of existing) {
                if (keptIds.has(current.id)) continue;
                const { count } = await supabase
                    .from('seats')
                    .select('id', { count: 'exact', head: true })
                    .eq('ticket_type_id', current.id)
                    .neq('status', 'available');
                if ((current.sold || 0) > 0 || (count || 0) > 0) {
                    return res.status(400).json({
                        message: `Kategori ${current.category} sudah punya penjualan atau kursi yang ditahan, jadi tidak bisa dihapus`
                    });
                }
                toDelete.push(current.id);
            }
        }

        // Hanya update field yang memang dikirim, supaya update partial tidak menghapus nilai lama
        // dengan undefined. latitude/longitude pakai toCoordinate (undefined = jangan diubah).
        // Kolom address/latitude/longitude/color/dll mungkin belum ada di DB (sesuai ERD lama),
        // jadi pakai fallback: coba kirim, kalau kolomnya nggak ada langsung dibuang dan retry.
        const eventPatch = {};
        if (Object.prototype.hasOwnProperty.call(body, 'name')) eventPatch.name = name;
        if (Object.prototype.hasOwnProperty.call(body, 'artist')) eventPatch.artist = artist;
        if (Object.prototype.hasOwnProperty.call(body, 'venue')) eventPatch.venue = venue;
        if (Object.prototype.hasOwnProperty.call(body, 'city')) eventPatch.city = city;
        if (Object.prototype.hasOwnProperty.call(body, 'address')) eventPatch.address = address;
        if (Object.prototype.hasOwnProperty.call(body, 'latitude')) {
            const lat = toCoordinate(latitude);
            if (lat !== undefined) eventPatch.latitude = lat;
        }
        if (Object.prototype.hasOwnProperty.call(body, 'longitude')) {
            const lng = toCoordinate(longitude);
            if (lng !== undefined) eventPatch.longitude = lng;
        }
        if (Object.prototype.hasOwnProperty.call(body, 'eventDate')) eventPatch.event_date = eventDate;
        if (Object.prototype.hasOwnProperty.call(body, 'description')) eventPatch.description = description;
        if (Object.prototype.hasOwnProperty.call(body, 'genre')) eventPatch.genre = genre;
        if (Object.prototype.hasOwnProperty.call(body, 'posterUrl')) eventPatch.poster_url = posterUrl;
        if (isActiveValue !== undefined) eventPatch.is_active = Boolean(isActiveValue);
        // updated_at ada di ERD, tapi tetap pakai fallback supaya aman kalau skema berubah
        eventPatch.updated_at = new Date().toISOString();

        const updateResult = await withMissingColumnFallback(eventPatch, (p) =>
            supabase.from('events').update(p).eq('id', req.params.id).select().single()
        );
        const data = updateResult.data;
        const error = updateResult.error;

        if (error) throw error;

        for (const u of toUpdate) {
            const ticketResult = await withMissingColumnFallback(u.patch, (p) =>
                supabase.from('ticket_types').update(p).eq('id', u.id)
            );
            if (ticketResult.error) throw ticketResult.error;
        }
        for (const id of toDelete) {
            const { error: deleteError } = await supabase.from('ticket_types').delete().eq('id', id);
            if (deleteError) throw deleteError;
        }
        for (const t of toInsert) {
            await insertTicketType(req.params.id, t);
        }

        res.json({ message: 'Event berhasil diupdate', event: data });
    } catch (error) {
        console.error('[PUT /api/events/:id] gagal:', error.message, error);
        res.status(500).json({ message: 'Gagal update event', error: error.message });
    }
});

// Hapus event
router.delete('/:id', isAuthenticated, isEventManager, async (req, res) => {
    try {
        if (!(await assertOwnership(req, req.params.id))) {
            return res.status(403).json({ message: 'Kamu tidak punya akses ke event ini' });
        }

        const { error } = await supabase.from('events').delete().eq('id', req.params.id);
        if (error) throw error;
        res.json({ message: 'Event berhasil dihapus' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal hapus event', error: error.message });
    }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const { isAuthenticated, isSuperAdmin } = require('../middleware/checkRole');

// Customer ajukan diri jadi organizer
router.post('/apply', isAuthenticated, async (req, res) => {
    try {
        const { businessName, description, phone } = req.body;

        if (!businessName) {
            return res.status(400).json({ message: 'Nama penyelenggara wajib diisi' });
        }

        // Cek apakah sudah pernah mengajukan dan masih pending
        const { data: existing } = await supabase
            .from('organizer_applications')
            .select('id, status')
            .eq('user_id', req.user.id)
            .eq('status', 'pending')
            .single();

        if (existing) {
            return res.status(400).json({ message: 'Kamu sudah punya pengajuan yang masih diproses' });
        }

        const { data, error } = await supabase
            .from('organizer_applications')
            .insert({
                user_id: req.user.id,
                business_name: businessName,
                description,
                phone
            })
            .select()
            .single();

        if (error) throw error;
        res.status(201).json({ message: 'Pengajuan berhasil dikirim, tunggu persetujuan admin', application: data });
    } catch (error) {
        res.status(500).json({ message: 'Gagal mengirim pengajuan', error: error.message });
    }
});

// Cek status pengajuan milik sendiri
router.get('/my-application', isAuthenticated, async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('organizer_applications')
            .select('*')
            .eq('user_id', req.user.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .single();

        if (error) return res.json(null);
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: 'Gagal cek status pengajuan', error: error.message });
    }
});

// Super admin lihat semua pengajuan
router.get('/applications', isAuthenticated, isSuperAdmin, async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('organizer_applications')
            .select('*, users!user_id(name, email)')
            .order('created_at', { ascending: false });

        if (error) throw error;
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil data pengajuan', error: error.message });
    }
});

// Super admin approve pengajuan
router.put('/applications/:id/approve', isAuthenticated, isSuperAdmin, async (req, res) => {
    try {
        const { data: application, error: findError } = await supabase
            .from('organizer_applications')
            .select('*')
            .eq('id', req.params.id)
            .single();

        if (findError || !application) {
            return res.status(404).json({ message: 'Pengajuan tidak ditemukan' });
        }

        const { error: roleError } = await supabase
            .from('users')
            .update({ role: 'organizer' })
            .eq('id', application.user_id);

        if (roleError) {
            return res.status(500).json({ message: 'Gagal update role user', error: roleError.message });
        }

        await supabase
            .from('organizer_applications')
            .update({ status: 'approved', reviewed_by: req.user.id, reviewed_at: new Date() })
            .eq('id', req.params.id);

        res.json({ message: 'Pengajuan disetujui, user sekarang jadi organizer' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal menyetujui pengajuan', error: error.message });
    }
});

// Super admin reject pengajuan
router.put('/applications/:id/reject', isAuthenticated, isSuperAdmin, async (req, res) => {
    try {
        const { error } = await supabase
            .from('organizer_applications')
            .update({ status: 'rejected', reviewed_by: req.user.id, reviewed_at: new Date() })
            .eq('id', req.params.id);

        if (error) throw error;
        res.json({ message: 'Pengajuan ditolak' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal menolak pengajuan', error: error.message });
    }
});

module.exports = router;
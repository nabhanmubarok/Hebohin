const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const snap = require('../config/midtrans');
const { isAuthenticated } = require('../middleware/checkRole');

// Buat order baru + request transaksi ke Midtrans
router.post('/', isAuthenticated, async (req, res) => {
    try {
        const { eventId, items } = req.body;
        // items = [{ ticketTypeId, category, quantity, pricePerItem }]

        const totalAmount = items.reduce((sum, item) => sum + (item.quantity * item.pricePerItem), 0);
        const orderId = 'ORDER-' + Date.now() + '-' + req.user.id.slice(0, 6);

        // Simpan order dengan status pending
        const { data: order, error: orderError } = await supabase
            .from('orders')
            .insert({
                order_id: orderId,
                user_id: req.user.id,
                event_id: eventId,
                total_amount: totalAmount,
                status: 'pending'
            })
            .select()
            .single();

        if (orderError) throw orderError;

        // Simpan detail item per order
        const orderItemsData = items.map(item => ({
            order_id: order.id,
            ticket_type_id: item.ticketTypeId,
            quantity: item.quantity,
            price_per_item: item.pricePerItem
        }));

        const { error: itemsError } = await supabase.from('order_items').insert(orderItemsData);
        if (itemsError) throw itemsError;

        // Request transaksi ke Midtrans
        const transaction = await snap.createTransaction({
            transaction_details: {
                order_id: orderId,
                gross_amount: totalAmount
            },
            item_details: items.map(item => ({
                id: item.ticketTypeId,
                price: item.pricePerItem,
                quantity: item.quantity,
                name: `Tiket ${item.category}`
            })),
            customer_details: {
                first_name: req.user.name,
                email: req.user.email
            },
            callbacks: {
                finish: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/my-tickets?order_id=${orderId}`
            }
        });

        res.status(201).json({
            message: 'Order berhasil dibuat',
            orderId,
            token: transaction.token,
            redirectUrl: transaction.redirect_url
        });
    } catch (error) {
        res.status(500).json({ message: 'Gagal membuat order', error: error.message });
    }
});

// Ambil riwayat order milik user yang login
router.get('/my-orders', isAuthenticated, async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('orders')
            .select('*, events(name, venue, event_date), order_items(*), tickets(*)')
            .eq('user_id', req.user.id)
            .order('created_at', { ascending: false });

        if (error) throw error;
        res.json(data);
    } catch (error) {
        res.status(500).json({ message: 'Gagal ambil riwayat order', error: error.message });
    }
});

// ---------------------------------------------------------------
// Proses status transaksi Midtrans -> update order + buat tiket.
// Dipakai oleh webhook DAN endpoint sync, aman dipanggil berkali-kali.
// ---------------------------------------------------------------
async function processMidtransStatus(statusResponse) {
    const { order_id, transaction_status, fraud_status, payment_type } = statusResponse;

    const { data: order, error: orderErr } = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('order_id', order_id)
        .single();

    if (orderErr || !order) throw new Error('Order tidak ditemukan: ' + order_id);

    const isPaid = transaction_status === 'settlement' ||
        (transaction_status === 'capture' && fraud_status === 'accept');

    if (isPaid) {
        // Idempotent: kalau tiket sudah pernah dibuat, jangan dobel
        const { count } = await supabase
            .from('tickets')
            .select('id', { count: 'exact', head: true })
            .eq('order_id', order.id);
        if (count > 0) return { status: 'paid', alreadyProcessed: true };

        const { error: updErr } = await supabase
            .from('orders')
            .update({
                status: 'paid',
                payment_method: payment_type,
                gateway_transaction_id: statusResponse.transaction_id,
                paid_at: new Date().toISOString()
            })
            .eq('id', order.id);
        if (updErr) throw updErr;

        // Ambil kategori dari ticket_types (order_items tidak menyimpan kategori)
        const typeIds = order.order_items.map(i => i.ticket_type_id);
        const { data: types, error: typesErr } = await supabase
            .from('ticket_types')
            .select('id, category')
            .in('id', typeIds);
        if (typesErr) throw typesErr;
        const categoryById = Object.fromEntries((types || []).map(t => [t.id, t.category]));

        const ticketsData = [];
        for (const item of order.order_items) {
            for (let i = 0; i < item.quantity; i++) {
                ticketsData.push({
                    order_id: order.id,
                    ticket_code: `TIX-${order_id}-${String(item.ticket_type_id).slice(0, 6)}-${i}`,
                    category: categoryById[item.ticket_type_id] || 'Regular'
                });
            }
        }

        // Insert tiket DULU, supaya kalau gagal tidak ada yang terlewat diam-diam
        const { error: ticketErr } = await supabase.from('tickets').insert(ticketsData);
        if (ticketErr) throw ticketErr;

        for (const item of order.order_items) {
            const { error: rpcErr } = await supabase.rpc('increment_sold', {
                ticket_type_id_input: item.ticket_type_id,
                qty: item.quantity
            });
            if (rpcErr) console.error('increment_sold gagal:', rpcErr.message);
        }

        // TODO: kirim email berisi QR code tiket ke user
        return { status: 'paid' };
    }

    if (transaction_status === 'cancel' || transaction_status === 'deny') {
        await supabase.from('orders').update({ status: 'cancelled' }).eq('id', order.id);
        return { status: 'cancelled' };
    }
    if (transaction_status === 'expire') {
        await supabase.from('orders').update({ status: 'expired' }).eq('id', order.id);
        return { status: 'expired' };
    }
    return { status: 'pending' };
}

// Webhook notifikasi dari Midtrans
router.post('/midtrans-notification', async (req, res) => {
    try {
        console.log('[Midtrans webhook] masuk:', req.body.order_id, req.body.transaction_status);
        const statusResponse = await snap.transaction.notification(req.body);
        await processMidtransStatus(statusResponse);
        res.status(200).send('OK');
    } catch (error) {
        console.error('[Midtrans webhook] error:', error.message);
        res.status(500).json({ message: 'Gagal proses notifikasi', error: error.message });
    }
});

// Sinkronisasi manual: backend tanya langsung status ke Midtrans.
// Dipanggil frontend setelah user kembali dari halaman pembayaran,
// jadi tiket tetap muncul walaupun webhook tidak sampai.
router.post('/:orderId/sync', isAuthenticated, async (req, res) => {
    try {
        const { data: order } = await supabase
            .from('orders')
            .select('order_id, user_id')
            .eq('order_id', req.params.orderId)
            .single();

        if (!order || order.user_id !== req.user.id) {
            return res.status(404).json({ message: 'Order tidak ditemukan' });
        }

        const statusResponse = await snap.transaction.status(order.order_id);
        const result = await processMidtransStatus(statusResponse);
        res.json(result);
    } catch (error) {
        console.error('[sync] error:', error.message);
        res.status(500).json({ message: 'Gagal sinkron status', error: error.message });
    }
});

module.exports = router;
// Helper untuk membuat dan memvalidasi tata letak kursi

const MAX_ROWS = 40;
const MAX_SEATS_PER_ROW = 60;
const MAX_SEATS_PER_CATEGORY = 3000;

// 0 -> A, 25 -> Z, 26 -> AA, dst.
function rowLabel(index) {
    let label = '';
    let n = index;
    do {
        label = String.fromCharCode(65 + (n % 26)) + label;
        n = Math.floor(n / 26) - 1;
    } while (n >= 0);
    return label;
}

// Balikin pesan error (string) kalau tidak valid, atau null kalau aman
function validateLayout(rows, perRow) {
    if (!Number.isInteger(rows) || !Number.isInteger(perRow) || rows < 1 || perRow < 1) {
        return 'Jumlah baris dan kursi per baris harus berupa angka bulat minimal 1';
    }
    if (rows > MAX_ROWS) return `Maksimal ${MAX_ROWS} baris per kategori`;
    if (perRow > MAX_SEATS_PER_ROW) return `Maksimal ${MAX_SEATS_PER_ROW} kursi per baris`;
    if (rows * perRow > MAX_SEATS_PER_CATEGORY) {
        return `Maksimal ${MAX_SEATS_PER_CATEGORY} kursi per kategori`;
    }
    return null;
}

function buildSeatRows({ eventId, ticketTypeId, rows, perRow }) {
    const result = [];
    for (let r = 0; r < rows; r++) {
        const row = rowLabel(r);
        for (let n = 1; n <= perRow; n++) {
            result.push({
                event_id: eventId,
                ticket_type_id: ticketTypeId,
                row_label: row,
                seat_number: n,
                label: `${row}${n}`,
                status: 'available'
            });
        }
    }
    return result;
}

// Insert kursi per 1000 baris supaya tidak kena batas request
async function insertSeats(supabase, seatRows) {
    for (let i = 0; i < seatRows.length; i += 1000) {
        const { error } = await supabase.from('seats').insert(seatRows.slice(i, i + 1000));
        if (error) throw error;
    }
}

module.exports = { rowLabel, validateLayout, buildSeatRows, insertSeats };

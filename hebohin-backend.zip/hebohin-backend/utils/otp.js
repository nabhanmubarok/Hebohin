const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_APP_PASSWORD
    }
});

function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

async function sendOTPEmail(toEmail, otp) {
    await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: toEmail,
        subject: 'Kode OTP Verifikasi - HebohIn',
        text: `Kode OTP kamu adalah: ${otp}. Kode ini berlaku selama 5 menit. Jangan berikan kode ini ke siapapun.`
    });
}

module.exports = { generateOTP, sendOTPEmail };

-- Jalankan script ini di SQL Editor Supabase (satu kali saja)
-- Function ini dipakai backend untuk menambah jumlah tiket terjual (sold)
-- setiap kali ada pembayaran yang berhasil, dengan cara yang aman dari race condition

create or replace function increment_sold(ticket_type_id_input uuid, qty integer)
returns void as $$
begin
    update ticket_types
    set sold = sold + qty
    where id = ticket_type_id_input;
end;
$$ language plpgsql;

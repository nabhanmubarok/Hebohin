-- Jalankan script ini di SQL Editor Supabase (satu kali saja)
-- Menambah: lokasi peta pada event, pengaturan kursi pada kategori tiket,
-- tabel kursi, dan nomor kursi pada tiket.

-- 1. Lokasi event (untuk peta)
alter table events
    add column if not exists address   text,
    add column if not exists latitude  double precision,
    add column if not exists longitude double precision;

-- 2. Pengaturan kursi per kategori tiket
--    has_seating = true  -> pembeli memilih kursi, stok otomatis = seat_rows * seats_per_row
--    has_seating = false -> tiket berdiri / festival, stok diisi manual seperti sebelumnya
alter table ticket_types
    add column if not exists has_seating   boolean not null default false,
    add column if not exists seat_rows     integer,
    add column if not exists seats_per_row integer,
    add column if not exists color         text;

-- 3. Tabel kursi (satu baris = satu kursi)
create table if not exists seats (
    id              uuid primary key default gen_random_uuid(),
    event_id        uuid not null references events(id) on delete cascade,
    ticket_type_id  uuid not null references ticket_types(id) on delete cascade,
    row_label       text not null,
    seat_number     integer not null,
    label           text not null,
    status          text not null default 'available'
                    check (status in ('available', 'reserved', 'sold')),
    order_id        uuid references orders(id) on delete set null,
    reserved_until  timestamptz,
    created_at      timestamptz not null default now(),
    unique (ticket_type_id, label)
);

create index if not exists seats_event_idx      on seats (event_id);
create index if not exists seats_ticket_type_idx on seats (ticket_type_id);
create index if not exists seats_order_idx      on seats (order_id);

-- 4. Nomor kursi tercetak di e-tiket
alter table tickets
    add column if not exists seat_label text,
    add column if not exists seat_id    uuid references seats(id) on delete set null;

-- Catatan: backend memakai service role key, jadi tidak perlu policy RLS tambahan.
-- Kalau RLS aktif di tabel seats, tidak ada policy publik yang dibutuhkan.

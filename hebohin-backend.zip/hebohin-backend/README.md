# HebohIn Backend

Backend Express untuk aplikasi pembelian tiket konser, terhubung ke Supabase (PostgreSQL) dan Midtrans (payment gateway).

## Struktur folder

```
hebohin-backend/
├── config/
│   ├── supabase.js      # koneksi ke Supabase
│   ├── passport.js      # konfigurasi Google OAuth
│   └── midtrans.js      # konfigurasi Midtrans Snap
├── routes/
│   ├── auth.js          # register, login, OTP, Google login
│   ├── events.js        # CRUD event & kategori tiket
│   └── orders.js        # buat order, riwayat, webhook Midtrans
├── middleware/
│   └── checkRole.js     # cek login & cek role admin
├── utils/
│   └── otp.js           # generate & kirim OTP via email
├── sql/
│   └── increment_sold_function.sql   # function tambahan untuk Supabase
├── index.js              # entry point server
├── .env.example
└── package.json
```

## Cara Install

```bash
npm install
```

## Setup Environment Variable

1. Copy `.env.example` jadi `.env`
2. Isi semua value sesuai kredensial kamu:
   - **SUPABASE_URL** & **SUPABASE_SERVICE_ROLE_KEY**: dari dashboard Supabase → Project Settings → API
   - **MIDTRANS_SERVER_KEY** & **MIDTRANS_CLIENT_KEY**: dari dashboard Midtrans (sandbox)
   - **GOOGLE_CLIENT_ID** & **GOOGLE_CLIENT_SECRET**: dari Google Cloud Console
   - **EMAIL_USER** & **EMAIL_APP_PASSWORD**: akun Gmail + App Password (bukan password biasa)
   - **SESSION_SECRET**: string acak bebas, buat sendiri

## Setup Tambahan di Supabase

Buka **SQL Editor** di Supabase, jalankan isi file `sql/increment_sold_function.sql` — ini function untuk update stok tiket otomatis saat ada pembayaran sukses.

## Menjalankan Server

```bash
npm run dev
```

Server akan jalan di `http://localhost:3000`

## Testing Webhook Midtrans

Karena `localhost` tidak bisa diakses dari internet, kamu perlu tunnel seperti **ngrok**:

```bash
ngrok http 3000
```

Lalu masukkan URL ngrok + `/api/orders/midtrans-notification` sebagai **Payment Notification URL** di dashboard Midtrans (Settings → Configuration).

## Daftar Endpoint

| Method | Endpoint | Keterangan |
|---|---|---|
| POST | `/auth/register` | Daftar akun baru |
| POST | `/auth/login` | Login manual |
| POST | `/auth/send-otp` | Kirim ulang OTP |
| POST | `/auth/verify-otp` | Verifikasi OTP |
| GET | `/auth/google` | Trigger login Google |
| GET | `/auth/me` | Cek user yang sedang login |
| POST | `/auth/logout` | Logout |
| GET | `/api/events` | Daftar semua event |
| GET | `/api/events/:id` | Detail 1 event |
| POST | `/api/events` | Buat event (admin) |
| PUT | `/api/events/:id` | Update event (admin) |
| DELETE | `/api/events/:id` | Hapus event (admin) |
| POST | `/api/orders` | Buat order + request pembayaran |
| GET | `/api/orders/my-orders` | Riwayat order milik user login |
| POST | `/api/orders/midtrans-notification` | Webhook dari Midtrans |

## Catatan Penting

- Route yang butuh login pakai middleware `isAuthenticated`, route khusus admin tambahkan `isAdmin`
- Password di-hash pakai `bcrypt` sebelum disimpan
- Field QR code tiket (`ticket_code`) baru dibuat otomatis setelah pembayaran berhasil lewat webhook


## Pembaruan: peta lokasi & kursi bernomor

**Wajib dijalankan sekali di Supabase SQL Editor:** `sql/add_maps_and_seats.sql`
(menambah kolom lokasi di `events`, kolom kursi di `ticket_types`, tabel `seats`, dan `seat_label` di `tickets`).

Endpoint baru / berubah:
- `GET /api/events/:id/seats` — denah kursi satu event (kursi yang masa tahannya habis dihitung tersedia lagi).
- `POST /api/events` & `PUT /api/events/:id` — menerima `address`, `latitude`, `longitude`, dan per kategori tiket:
  `hasSeating`, `seatRows`, `seatsPerRow`, `color`. Kursi dibuat otomatis; stok = baris × kursi per baris.
  Saat edit, tata letak kursi tidak bisa diubah, dan kategori yang sudah terjual tidak bisa dihapus.
- `POST /api/orders` — item sekarang `{ ticketTypeId, quantity, seatIds? }`. **Harga diambil dari database**, bukan dari browser.
  Kursi ditahan 30 menit (sama dengan masa berlaku transaksi Midtrans). Kalau kursi sudah diambil orang lain, balasannya `409`.
- Webhook Midtrans: kursi jadi `sold` saat lunas dan dilepas saat batal/kedaluwarsa; nomor kursi tercetak di tiket.
- `GET /api/orders/all` — daftar semua pesanan (admin), dipakai halaman Pesanan di panel admin.

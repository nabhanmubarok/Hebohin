function isAuthenticated(req, res, next) {
    if (req.isAuthenticated && req.isAuthenticated()) {
        return next();
    }
    res.status(401).json({ message: 'Harus login terlebih dahulu' });
}

// Admin dan super admin (untuk fitur lintas semua event/data)
function isAdmin(req, res, next) {
    if (req.user && (req.user.role === 'admin' || req.user.role === 'super_admin')) {
        return next();
    }
    res.status(403).json({ message: 'Akses ditolak, khusus admin' });
}

// Khusus super admin saja
function isSuperAdmin(req, res, next) {
    if (req.user && req.user.role === 'super_admin') {
        return next();
    }
    res.status(403).json({ message: 'Akses ditolak, khusus super admin' });
}

// Organizer, admin, dan super admin boleh kelola event (tapi organizer dibatasi ke miliknya sendiri di level route)
function isEventManager(req, res, next) {
    const allowed = ['organizer', 'admin', 'super_admin'];
    if (req.user && allowed.includes(req.user.role)) {
        return next();
    }
    res.status(403).json({ message: 'Akses ditolak' });
}

module.exports = { isAuthenticated, isAdmin, isSuperAdmin, isEventManager };